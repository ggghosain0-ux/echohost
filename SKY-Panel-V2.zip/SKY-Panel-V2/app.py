from __future__ import annotations

import base64
import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import shutil
import socket
import sqlite3
import subprocess
import threading
import time
import urllib.parse
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import httpx
import psutil
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", BASE / "data")).resolve()
SERVERS_DIR = Path(os.getenv("SERVER_DATA_DIR", BASE / "server-data")).resolve()
LOG_DIR = Path(os.getenv("LOG_DIR", BASE / "logs")).resolve()
DB_PATH = DATA_DIR / "sky.db"
SECRET_FILE = DATA_DIR / "secret.key"
DATA_DIR.mkdir(parents=True, exist_ok=True)
SERVERS_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT = int(os.getenv("APP_PORT", "8080"))
APP_VERSION = "2.0.0"
DEFAULT_ADMIN_USER = os.getenv("SKY_ADMIN_USER", "admin")
DEFAULT_ADMIN_PASS = os.getenv("SKY_ADMIN_PASS", "admin")
SECRET_KEY = os.getenv("SECRET_KEY") or (SECRET_FILE.read_text(encoding="utf-8").strip() if SECRET_FILE.exists() else secrets.token_urlsafe(48))
SECRET_FILE.write_text(SECRET_KEY, encoding="utf-8")

app = FastAPI(title="SKY Panel", version=APP_VERSION)
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, same_site="lax", https_only=False, max_age=60 * 60 * 24 * 7)
templates = Jinja2Templates(directory=str(BASE / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
executor = ThreadPoolExecutor(max_workers=8)


def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    return c


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 260_000)
    return base64.urlsafe_b64encode(salt + digest).decode()


def verify_password(password: str, encoded: str) -> bool:
    try:
        raw = base64.urlsafe_b64decode(encoded.encode())
        salt, expected = raw[:16], raw[16:]
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 260_000)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def activity(action: str, user_id: int | None = None, server_id: int | None = None, detail: str = "") -> None:
    try:
        c = db()
        c.execute("INSERT INTO activity(action,user_id,server_id,detail) VALUES(?,?,?,?)", (action, user_id, server_id, detail[:1000]))
        c.commit(); c.close()
    except Exception:
        pass


def init_db() -> None:
    c = db()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          last_login TEXT
        );
        CREATE TABLE IF NOT EXISTS servers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uuid TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL,
          owner_id INTEGER NOT NULL,
          version TEXT NOT NULL,
          server_type TEXT NOT NULL DEFAULT 'paper',
          jar TEXT NOT NULL DEFAULT 'server.jar',
          java_major INTEGER NOT NULL DEFAULT 21,
          port INTEGER UNIQUE NOT NULL,
          rcon_port INTEGER UNIQUE NOT NULL,
          rcon_password TEXT NOT NULL,
          memory_mb INTEGER NOT NULL DEFAULT 2048,
          cpu_limit REAL NOT NULL DEFAULT 2.0,
          disk_limit_mb INTEGER NOT NULL DEFAULT 10240,
          status TEXT NOT NULL DEFAULT 'installing',
          container_name TEXT UNIQUE NOT NULL,
          suspended INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS backups (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          server_id INTEGER NOT NULL,
          filename TEXT NOT NULL,
          size_bytes INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(server_id) REFERENCES servers(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS schedules (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          server_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          interval_minutes INTEGER NOT NULL,
          action TEXT NOT NULL CHECK(action IN ('start','stop','restart','backup')),
          enabled INTEGER NOT NULL DEFAULT 1,
          last_run INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY(server_id) REFERENCES servers(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS subusers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          server_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          permissions TEXT NOT NULL DEFAULT 'console,files',
          FOREIGN KEY(server_id) REFERENCES servers(id) ON DELETE CASCADE,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
          UNIQUE(server_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS api_keys (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          key_hash TEXT UNIQUE NOT NULL,
          prefix TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          last_used TEXT,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS activity (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          action TEXT NOT NULL,
          user_id INTEGER,
          server_id INTEGER,
          detail TEXT,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS local_node (
          id INTEGER PRIMARY KEY CHECK(id=1),
          name TEXT NOT NULL,
          memory_limit INTEGER NOT NULL DEFAULT 0,
          cpu_limit REAL NOT NULL DEFAULT 0,
          disk_limit_mb INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    if not c.execute("SELECT id FROM users WHERE username=?", (DEFAULT_ADMIN_USER,)).fetchone():
        c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)", (DEFAULT_ADMIN_USER, hash_password(DEFAULT_ADMIN_PASS), "admin"))
    c.execute("INSERT OR IGNORE INTO local_node(id,name,memory_limit,cpu_limit,disk_limit_mb) VALUES(1,'Local Node',0,0,0)")
    defaults = {
        "site_name": "SKY Panel",
        "site_tagline": "Modern Minecraft hosting, powered by your own hardware.",
        "theme": "violet",
        "default_memory": "2048",
        "default_cpu": "2",
        "default_disk": "10240",
        "server_port_start": "25565",
        "timezone": "Asia/Kolkata",
    }
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    c.commit(); c.close()


def settings_dict() -> dict[str, str]:
    c = db(); rows = c.execute("SELECT key,value FROM settings").fetchall(); c.close()
    return {r["key"]: r["value"] for r in rows}


def user_from_request(request: Request) -> sqlite3.Row | None:
    uid = request.session.get("uid")
    if not uid:
        return None
    c = db(); user = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone(); c.close()
    return user


def require_user(request: Request) -> sqlite3.Row:
    u = user_from_request(request)
    if not u:
        raise HTTPException(401, "Authentication required")
    return u


def require_admin(request: Request) -> sqlite3.Row:
    u = require_user(request)
    if u["role"] != "admin":
        raise HTTPException(403, "Administrator access required")
    return u


def get_server(server_id: int) -> sqlite3.Row | None:
    c = db(); row = c.execute("SELECT s.*, u.username owner_name FROM servers s JOIN users u ON u.id=s.owner_id WHERE s.id=?", (server_id,)).fetchone(); c.close()
    return row


def access_server(request: Request, server_id: int) -> sqlite3.Row:
    u = require_user(request); s = get_server(server_id)
    if not s:
        raise HTTPException(404, "Server not found")
    if u["role"] == "admin" or s["owner_id"] == u["id"]:
        return s
    c = db(); sub = c.execute("SELECT 1 FROM subusers WHERE server_id=? AND user_id=?", (server_id, u["id"])).fetchone(); c.close()
    if not sub:
        raise HTTPException(403, "You do not have access to this server")
    return s


def server_root(server: sqlite3.Row | dict[str, Any]) -> Path:
    return SERVERS_DIR / server["uuid"]


def safe_path(root: Path, relative: str) -> Path:
    clean = urllib.parse.unquote(relative or "").replace("\\", "/").lstrip("/")
    target = (root / clean).resolve()
    if target != root and root not in target.parents:
        raise HTTPException(400, "Invalid path")
    return target


def shell(cmd: list[str], timeout: int = 60, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, timeout=timeout, capture_output=True, check=check)


def docker_cmd() -> list[str]:
    try:
        p = subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4)
        if p.returncode == 0:
            return ["docker"]
    except Exception:
        pass
    if shutil.which("sudo"):
        try:
            p = subprocess.run(["sudo", "-n", "docker", "info"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4)
            if p.returncode == 0:
                return ["sudo", "-n", "docker"]
        except Exception:
            pass
    return ["docker"]


def docker_ok() -> bool:
    try:
        return shell(docker_cmd() + ["info"], timeout=6, check=False).returncode == 0
    except Exception:
        return False


def host_stats() -> dict[str, Any]:
    vm = psutil.virtual_memory(); du = psutil.disk_usage(str(BASE)); cpu = psutil.cpu_percent(interval=None)
    return {
        "cpu_percent": cpu,
        "memory_total": vm.total,
        "memory_used": vm.used,
        "memory_percent": vm.percent,
        "disk_total": du.total,
        "disk_used": du.used,
        "disk_percent": du.percent,
    }


def http_json(url: str, params: dict[str, Any] | None = None) -> Any:
    headers = {"User-Agent": "SKY-Panel/2.0 (+self-hosted)", "Accept": "application/json"}
    with httpx.Client(timeout=35, follow_redirects=True, headers=headers) as client:
        r = client.get(url, params=params); r.raise_for_status(); return r.json()


def stream_download(url: str, destination: Path, expected_sha1: str | None = None) -> None:
    tmp = destination.with_suffix(destination.suffix + f".part-{secrets.token_hex(4)}")
    headers = {"User-Agent": "SKY-Panel/2.0 (+self-hosted)"}
    try:
        with httpx.stream("GET", url, timeout=180, follow_redirects=True, headers=headers) as r:
            r.raise_for_status()
            with tmp.open("wb") as fh:
                for chunk in r.iter_bytes(1024 * 1024):
                    if chunk:
                        fh.write(chunk)
        if tmp.stat().st_size < 50_000:
            raise RuntimeError("Downloaded file is too small to be a valid server JAR")
        if expected_sha1:
            digest = hashlib.sha1(tmp.read_bytes()).hexdigest()
            if digest.lower() != expected_sha1.lower():
                raise RuntimeError("Downloaded JAR failed SHA-1 verification")
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)


def java_for_minecraft(version: str) -> int:
    v = version.strip()
    if v.startswith("26."):
        return 25
    if v.startswith("1.21") or v in {"1.20.5", "1.20.6"} or (v.startswith("1.20.") and int(v.split(".")[2]) >= 5):
        return 21
    if v.startswith("1.19") or v.startswith("1.18") or v.startswith("1.20"):
        return 17
    return 17


def vanilla_release_versions() -> list[dict[str, Any]]:
    manifest = http_json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
    out = []
    for v in manifest.get("versions", []):
        vid = str(v.get("id", ""))
        if v.get("type") != "release":
            continue
        if vid.startswith("26."):
            out.append({"id": vid, "type": "release", "url": v.get("url")})
        elif vid.startswith("1."):
            try:
                minor = int(vid.split(".")[1])
            except Exception:
                continue
            if minor >= 19:
                out.append({"id": vid, "type": "release", "url": v.get("url")})
    return out


def vanilla_release_info(version: str) -> tuple[str, str]:
    versions = vanilla_release_versions()
    entry = next((v for v in versions if v["id"] == version), None)
    if not entry or not entry.get("url"):
        raise RuntimeError(f"Minecraft {version} is not an official release in Mojang's manifest")
    meta = http_json(entry["url"])
    server = meta.get("downloads", {}).get("server") or {}
    if not server.get("url"):
        raise RuntimeError(f"Minecraft {version} has no official server download entry")
    return server["url"], server.get("sha1", "")


def paper_release_info(version: str) -> tuple[str, str]:
    encoded = urllib.parse.quote(version, safe="")
    data = http_json(f"https://fill.papermc.io/v3/projects/paper/versions/{encoded}/builds")
    builds = data if isinstance(data, list) else data.get("builds", [])
    stable = [b for b in builds if str(b.get("channel", "")).upper() == "STABLE"]
    choices = stable or builds
    if not choices:
        raise RuntimeError(f"No Paper build is available for {version}")
    build = choices[0]
    download = (build.get("downloads") or {}).get("server:default") or {}
    if not download.get("url"):
        raise RuntimeError(f"Paper {version} did not return a server JAR URL")
    return download["url"], download.get("checksums", {}).get("sha256", "") if download.get("checksums") else ""


def purpur_release_info(version: str) -> tuple[str, None]:
    meta = http_json(f"https://api.purpurmc.org/v2/purpur/{urllib.parse.quote(version, safe='')}")
    builds = meta.get("builds", {}).get("all", []) if isinstance(meta, dict) else []
    build = meta.get("builds", {}).get("latest", builds[-1] if builds else None)
    if not build:
        raise RuntimeError(f"No Purpur build is available for {version}")
    return f"https://api.purpurmc.org/v2/purpur/{urllib.parse.quote(version, safe='')}/{build}/download", None


def fabric_server_url(version: str) -> str:
    loaders = http_json(f"https://meta.fabricmc.net/v2/versions/loader/{urllib.parse.quote(version, safe='')}")
    if not loaders:
        raise RuntimeError(f"Fabric has no server loader for Minecraft {version}")
    loader = next((x for x in loaders if x.get("loader", {}).get("stable")), loaders[0])
    installers = http_json("https://meta.fabricmc.net/v2/versions/installer")
    installer = next((x for x in installers if x.get("stable")), installers[0])
    return f"https://meta.fabricmc.net/v2/versions/loader/{urllib.parse.quote(version, safe='')}/{loader['loader']['version']}/{installer['version']}/server/jar"


def jar_source(server_type: str, version: str) -> tuple[str, str | None]:
    st = server_type.lower()
    if st == "vanilla":
        return vanilla_release_info(version)
    if st == "paper":
        return paper_release_info(version)
    if st == "purpur":
        return purpur_release_info(version)
    if st == "fabric":
        return fabric_server_url(version), None
    raise RuntimeError("Unsupported Minecraft software")


def write_server_properties(root: Path, s: sqlite3.Row) -> None:
    props = {
        "server-port": "25565",
        "server-ip": "",
        "enable-rcon": "true",
        "rcon.port": "25575",
        "rcon.password": s["rcon_password"],
        "rcon.ip": "0.0.0.0",
        "broadcast-rcon-to-ops": "false",
        "motd": s["name"].replace("\n", " ")[:59],
        "online-mode": "true",
        "enable-command-block": "true",
        "view-distance": "10",
        "simulation-distance": "10",
    }
    path = root / "server.properties"
    existing: dict[str, str] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1); existing[k] = v
    existing.update(props)
    path.write_text("".join(f"{k}={v}\n" for k, v in existing.items()), encoding="utf-8")


def docker_image(java_major: int) -> str:
    if java_major not in {17, 21, 25}:
        java_major = 21
    return f"eclipse-temurin:{java_major}-jre"


def create_container(s: sqlite3.Row) -> None:
    root = server_root(s); name = s["container_name"]
    shell(docker_cmd() + ["rm", "-f", name], timeout=30, check=False)
    cmd = docker_cmd() + [
        "run", "-d", "--name", name,
        "--restart", "unless-stopped",
        "--memory", f"{int(s['memory_mb'])}m",
        "--cpus", str(float(s["cpu_limit"])),
        "--pids-limit", "1024",
        "--security-opt", "no-new-privileges:true",
        "--cap-drop", "ALL",
        "--read-only", "false",
        "-p", f"{int(s['port'])}:25565/tcp",
        "-p", f"127.0.0.1:{int(s['rcon_port'])}:25575/tcp",
        "-v", f"{root}:/data",
        "-w", "/data",
        "--entrypoint", "/bin/bash",
        docker_image(int(s["java_major"])),
        "-lc", f"exec java -Xms128M -Xmx{int(s['memory_mb'])}M -jar {sh_quote(s['jar'])} --nogui",
    ]
    result = shell(cmd, timeout=90, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "Docker could not create the Minecraft container")


def sh_quote(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def provision_server(server_id: int) -> None:
    s = get_server(server_id)
    if not s:
        return
    root = server_root(s)
    root.mkdir(parents=True, exist_ok=True)
    for folder in ("plugins", "mods", "world", "backups", "config"):
        (root / folder).mkdir(exist_ok=True)
    try:
        if not docker_ok():
            raise RuntimeError("Docker daemon is unavailable. Start Docker and retry provisioning.")
        url, checksum = jar_source(s["server_type"], s["version"])
        jar = root / s["jar"]
        stream_download(url, jar, checksum if len(checksum) == 40 else None)
        os.chmod(jar, 0o644)
        write_server_properties(root, s)
        (root / "eula.txt").write_text("eula=true\n", encoding="utf-8")
        create_container(s)
        # Keep it stopped after installation; the UI controls when it starts.
        shell(docker_cmd() + ["stop", s["container_name"]], timeout=30, check=False)
        update_status(server_id, "stopped")
        activity("server.provisioned", s["owner_id"], server_id, f"{s['server_type']} {s['version']}")
    except Exception as exc:
        update_status(server_id, "error")
        (root / "provision-error.txt").write_text(str(exc), encoding="utf-8")
        activity("server.provision_failed", s["owner_id"], server_id, str(exc))


def container_state(s: sqlite3.Row) -> str:
    try:
        r = shell(docker_cmd() + ["inspect", "-f", "{{.State.Status}}", s["container_name"]], timeout=8, check=False)
        if r.returncode == 0:
            return r.stdout.strip() or "missing"
    except Exception:
        pass
    return "missing"


def update_status(server_id: int, status: str) -> None:
    c = db(); c.execute("UPDATE servers SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (status, server_id)); c.commit(); c.close()


def refresh_status(server_id: int) -> str:
    s = get_server(server_id)
    if not s:
        return "missing"
    state = container_state(s)
    if s["suspended"]:
        mapped = "suspended"
    else:
        mapped = {"running": "running", "exited": "stopped", "created": "stopped", "restarting": "starting", "paused": "stopped"}.get(state, "offline")
    if s["status"] not in {"installing", "error"}:
        update_status(server_id, mapped)
    return mapped


def rcon_packet(request_id: int, packet_type: int, payload: str) -> bytes:
    body = int(request_id).to_bytes(4, "little", signed=True) + int(packet_type).to_bytes(4, "little", signed=True) + payload.encode() + b"\x00\x00"
    return len(body).to_bytes(4, "little", signed=True) + body


def recv_exact(sock: socket.socket, count: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < count:
        chunk = sock.recv(count - len(chunks))
        if not chunk:
            raise RuntimeError("RCON connection closed unexpectedly")
        chunks.extend(chunk)
    return bytes(chunks)


def recv_rcon(sock: socket.socket) -> tuple[int, int, str]:
    length = int.from_bytes(recv_exact(sock, 4), "little", signed=True)
    if length < 10 or length > 8 * 1024 * 1024:
        raise RuntimeError("Invalid RCON packet length")
    body = recv_exact(sock, length)
    request_id = int.from_bytes(body[0:4], "little", signed=True)
    packet_type = int.from_bytes(body[4:8], "little", signed=True)
    payload = body[8:-2].decode("utf-8", errors="replace")
    return request_id, packet_type, payload


def rcon_command(s: sqlite3.Row, command: str) -> str:
    if not command.strip():
        return ""
    if len(command) > 2048:
        raise RuntimeError("RCON command is too long")
    with socket.create_connection(("127.0.0.1", int(s["rcon_port"])), timeout=5) as sock:
        sock.settimeout(5)
        auth_id = 100
        sock.sendall(rcon_packet(auth_id, 3, s["rcon_password"]))
        rid, _, _ = recv_rcon(sock)
        if rid == -1:
            raise RuntimeError("RCON authentication failed")
        cmd_id = 101
        sock.sendall(rcon_packet(cmd_id, 2, command.strip()))
        pieces: list[str] = []
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                rid, _, payload = recv_rcon(sock)
            except socket.timeout:
                break
            if rid in {cmd_id, 101}:
                pieces.append(payload)
                # Most commands return one response packet. A short timeout is enough to collect a second packet.
                sock.settimeout(0.15)
            else:
                pieces.append(payload)
        return "".join(pieces)


def docker_logs(s: sqlite3.Row, tail: int = 500) -> str:
    try:
        r = shell(docker_cmd() + ["logs", "--timestamps", "--tail", str(max(50, min(tail, 2000))), s["container_name"]], timeout=12, check=False)
        return (r.stdout or "") + (("\n" + r.stderr) if r.stderr else "")
    except FileNotFoundError:
        return "[SKY] Docker CLI is not installed or not available to the panel process."


def docker_action(s: sqlite3.Row, action: str) -> None:
    if s["suspended"] and action in {"start", "restart"}:
        raise RuntimeError("Server is suspended")
    cmd = {"start": "start", "stop": "stop", "restart": "restart", "kill": "kill"}.get(action)
    if not cmd:
        raise RuntimeError("Invalid server action")
    # Restart automatically recreates the container if the container has disappeared.
    if action in {"start", "restart"} and container_state(s) == "missing":
        create_container(s)
    r = shell(docker_cmd() + [cmd, s["container_name"]], timeout=45, check=False)
    if r.returncode:
        raise RuntimeError(r.stderr.strip() or f"Docker {action} failed")
    time.sleep(0.3)
    refresh_status(s["id"])


def docker_stats(s: sqlite3.Row) -> dict[str, Any]:
    fmt = '{{json .}}'
    try:
        r = shell(docker_cmd() + ["stats", "--no-stream", "--format", fmt, s["container_name"]], timeout=10, check=False)
    except FileNotFoundError:
        return {"cpu": 0, "memory": "Docker unavailable", "memory_limit": f"{s['memory_mb']}MiB", "net_rx": "0B", "net_tx": "0B"}
    if r.returncode:
        return {"cpu": 0, "memory": 0, "memory_limit": int(s["memory_mb"]) * 1024 * 1024, "net_rx": 0, "net_tx": 0}
    try:
        raw = json.loads(r.stdout.strip().splitlines()[-1])
        mem = raw.get("MemUsage", "0B / 0B").split("/")
        cpu = float(str(raw.get("CPUPerc", "0")).replace("%", "") or 0)
        return {"cpu": cpu, "memory": mem[0].strip(), "memory_limit": mem[1].strip() if len(mem)>1 else "", "net_rx": raw.get("NetIO", "").split("/")[0].strip(), "net_tx": raw.get("NetIO", "").split("/")[-1].strip()}
    except Exception:
        return {"cpu": 0, "memory": "0B", "memory_limit": f"{s['memory_mb']}MiB", "net_rx": "0B", "net_tx": "0B"}


def check_port_available(port: int) -> bool:
    c = db(); row = c.execute("SELECT 1 FROM servers WHERE port=?", (port,)).fetchone(); c.close()
    if row:
        return False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            return sock.connect_ex(("0.0.0.0", port)) != 0
    except OSError:
        return False


def next_free_port() -> int:
    c = db(); configured = int(settings_dict().get("server_port_start", "25565")); rows = c.execute("SELECT port FROM servers ORDER BY port").fetchall(); c.close()
    used = {int(r["port"]) for r in rows}
    port = configured
    while port in used or not check_port_available(port):
        port += 1
    return port


def next_rcon_port() -> int:
    c = db(); rows = c.execute("SELECT rcon_port FROM servers ORDER BY rcon_port").fetchall(); c.close()
    used = {int(r["rcon_port"]) for r in rows}
    port = 30000
    while port in used or not check_port_available(port):
        port += 1
    return port


def token_for_ws(user_id: int, server_id: int) -> str:
    stamp = int(time.time())
    payload = f"{user_id}:{server_id}:{stamp}"
    sig = hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}:{sig}".encode()).decode()


def verify_ws_token(token: str, user_id: int, server_id: int) -> bool:
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        uid, sid, stamp, sig = raw.split(":", 3)
        payload = f"{uid}:{sid}:{stamp}"
        if int(uid) != user_id or int(sid) != server_id or abs(int(time.time()) - int(stamp)) > 120:
            return False
        expected = hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, expected)
    except Exception:
        return False


def installed_files(server: sqlite3.Row, folder: str) -> list[dict[str, Any]]:
    root = safe_path(server_root(server), folder)
    root.mkdir(parents=True, exist_ok=True)
    out = []
    for p in sorted(root.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
        if p.name.startswith("."):
            continue
        out.append({"name": p.name, "is_dir": p.is_dir(), "size": p.stat().st_size if p.is_file() else 0})
    return out


def backup_server(server: sqlite3.Row) -> tuple[str, int]:
    root = server_root(server); bdir = root / "backups"; bdir.mkdir(exist_ok=True)
    filename = f"sky-{int(time.time())}-{secrets.token_hex(3)}.zip"; target = bdir / filename
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in root.rglob("*"):
            if p.is_file() and "backups" not in p.parts:
                z.write(p, p.relative_to(root))
    size = target.stat().st_size
    c = db(); c.execute("INSERT INTO backups(server_id,filename,size_bytes) VALUES(?,?,?)", (server["id"], filename, size)); c.commit(); c.close()
    activity("backup.created", server["owner_id"], server["id"], filename)
    return filename, size


def modrinth_search(q: str, kind: str, version: str, loader: str | None) -> Any:
    facets: list[list[str]] = []
    if kind in {"plugin", "mod"}:
        facets.append([f"project_type:{kind}"])
    if version:
        facets.append([f"versions:{version}"])
    if loader:
        facets.append([f"categories:{loader}"])
    params = {"query": q, "limit": 24, "facets": json.dumps(facets)}
    return http_json("https://api.modrinth.com/v2/search", params=params)


def modrinth_project_versions(project_id: str, minecraft_version: str, loader: str) -> list[dict[str, Any]]:
    params = {"game_versions": json.dumps([minecraft_version]), "loaders": json.dumps([loader]), "featured": "true"}
    data = http_json(f"https://api.modrinth.com/v2/project/{urllib.parse.quote(project_id, safe='')}/version", params=params)
    if not data:
        params.pop("featured", None)
        data = http_json(f"https://api.modrinth.com/v2/project/{urllib.parse.quote(project_id, safe='')}/version", params=params)
    return data


def install_modrinth(project_id: str, server: sqlite3.Row, kind: str) -> str:
    if kind not in {"plugin", "mod"}:
        raise RuntimeError("Invalid Modrinth type")
    loader = "paper" if kind == "plugin" else "fabric"
    expected_type = "paper" if kind == "plugin" else "fabric"
    if server["server_type"] not in {expected_type, "purpur" if kind == "plugin" else expected_type}:
        raise RuntimeError(f"{kind.title()} installation requires {expected_type.title()} server software")
    versions = modrinth_project_versions(project_id, server["version"], loader)
    if not versions:
        raise RuntimeError("Modrinth has no compatible version for this Minecraft version/loader")
    version = versions[0]
    files = version.get("files") or []
    primary = next((f for f in files if f.get("primary")), files[0] if files else None)
    if not primary or not primary.get("url"):
        raise RuntimeError("Modrinth version has no downloadable file")
    safe_name = Path(str(primary.get("filename", "download.jar"))).name
    if not safe_name.lower().endswith(".jar"):
        raise RuntimeError("Selected Modrinth file is not a JAR")
    folder = server_root(server) / ("plugins" if kind == "plugin" else "mods")
    folder.mkdir(exist_ok=True)
    destination = folder / safe_name
    if destination.exists():
        return safe_name
    stream_download(primary["url"], destination, None)
    activity(f"{kind}.installed", server["owner_id"], server["id"], safe_name)
    return safe_name


init_db()


def scheduler_loop() -> None:
    while True:
        try:
            now = int(time.time())
            c = db(); rows = c.execute("SELECT * FROM schedules WHERE enabled=1").fetchall()
            for row in rows:
                if now - int(row["last_run"]) < int(row["interval_minutes"]) * 60:
                    continue
                s = get_server(row["server_id"])
                if not s:
                    continue
                try:
                    if row["action"] in {"start", "stop", "restart"}:
                        docker_action(s, row["action"])
                    elif row["action"] == "backup":
                        backup_server(s)
                except Exception:
                    pass
                c.execute("UPDATE schedules SET last_run=? WHERE id=?", (now, row["id"]))
            c.commit(); c.close()
        except Exception:
            pass
        time.sleep(15)


threading.Thread(target=scheduler_loop, name="sky-scheduler", daemon=True).start()


# ---------- Common rendering ----------
def ctx(request: Request, **extra: Any) -> dict[str, Any]:
    user = user_from_request(request)
    return {"request": request, "user": user, "settings": settings_dict(), "app_version": APP_VERSION, **extra}


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return RedirectResponse("/dashboard" if user_from_request(request) else "/login")


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if user_from_request(request):
        return RedirectResponse("/dashboard")
    return templates.TemplateResponse("login.html", {**ctx(request), "error": request.session.pop("error", None)})


@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    c = db(); u = c.execute("SELECT * FROM users WHERE username=?", (username.strip(),)).fetchone()
    if not u or not verify_password(password, u["password_hash"]):
        c.close(); request.session["error"] = "Invalid username or password"; return RedirectResponse("/login", 303)
    c.execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?", (u["id"],)); c.commit(); c.close()
    request.session.clear(); request.session["uid"] = int(u["id"])
    activity("auth.login", int(u["id"]), detail="Web login")
    return RedirectResponse("/dashboard", 303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear(); return RedirectResponse("/login", 303)


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", ctx(request))


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    u = require_user(request); c = db()
    if u["role"] == "admin":
        rows = c.execute("SELECT s.*,u.username owner_name FROM servers s JOIN users u ON u.id=s.owner_id ORDER BY s.id DESC LIMIT 10").fetchall()
        counts = {
            "users": c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],
            "servers": c.execute("SELECT COUNT(*) n FROM servers").fetchone()["n"],
            "running": c.execute("SELECT COUNT(*) n FROM servers WHERE status='running'").fetchone()["n"],
            "backups": c.execute("SELECT COUNT(*) n FROM backups").fetchone()["n"],
        }
    else:
        rows = c.execute("SELECT s.*,u.username owner_name FROM servers s JOIN users u ON u.id=s.owner_id WHERE s.owner_id=? OR EXISTS(SELECT 1 FROM subusers su WHERE su.server_id=s.id AND su.user_id=?) ORDER BY s.id DESC LIMIT 10", (u["id"], u["id"])).fetchall()
        counts = {
            "users": None,
            "servers": c.execute("SELECT COUNT(*) n FROM servers WHERE owner_id=? OR EXISTS(SELECT 1 FROM subusers su WHERE su.server_id=servers.id AND su.user_id=?)", (u["id"], u["id"])).fetchone()["n"],
            "running": c.execute("SELECT COUNT(*) n FROM servers WHERE status='running' AND (owner_id=? OR EXISTS(SELECT 1 FROM subusers su WHERE su.server_id=servers.id AND su.user_id=?))", (u["id"], u["id"])).fetchone()["n"],
            "backups": c.execute("SELECT COUNT(*) n FROM backups b JOIN servers s ON s.id=b.server_id WHERE s.owner_id=?", (u["id"],)).fetchone()["n"],
        }
    c.close()
    for s in rows:
        refresh_status(s["id"])
    return templates.TemplateResponse("dashboard.html", ctx(request, servers=[dict(x) for x in rows], counts=counts, host=host_stats(), docker=docker_ok()))


@app.get("/servers", response_class=HTMLResponse)
def servers_page(request: Request):
    u = require_user(request); c = db()
    rows = c.execute("SELECT s.*,u.username owner_name FROM servers s JOIN users u ON u.id=s.owner_id WHERE s.owner_id=? OR ?='admin' OR EXISTS(SELECT 1 FROM subusers su WHERE su.server_id=s.id AND su.user_id=?) ORDER BY s.id DESC", (u["id"], u["role"], u["id"])).fetchall()
    users = c.execute("SELECT id,username,role FROM users ORDER BY username").fetchall() if u["role"] == "admin" else []
    c.close()
    for s in rows: refresh_status(s["id"])
    return templates.TemplateResponse("servers.html", ctx(request, servers=[dict(x) for x in rows], users=[dict(x) for x in users], docker=docker_ok()))


@app.get("/servers/create", response_class=HTMLResponse)
def create_server_page(request: Request):
    u = require_user(request); users = []
    if u["role"] == "admin":
        c = db(); users = [dict(x) for x in c.execute("SELECT id,username,role FROM users ORDER BY username").fetchall()]; c.close()
    try:
        versions = vanilla_release_versions()
    except Exception:
        fallback = ["1.19","1.19.1","1.19.2","1.19.3","1.19.4","1.20","1.20.1","1.20.2","1.20.3","1.20.4","1.20.5","1.20.6","1.21","1.21.1","1.21.2","1.21.3","1.21.4","1.21.5","1.21.6","1.21.7","1.21.8","1.21.9","1.21.10","1.21.11","26.1","26.2"]
        versions = [{"id":v,"type":"release","url":""} for v in fallback]
    return templates.TemplateResponse("create_server.html", ctx(request, users=users, versions=versions[:400], defaults=settings_dict(), error=request.session.pop("error", None)))


@app.post("/servers/create")
def create_server(request: Request, name: str = Form(...), version: str = Form(...), server_type: str = Form("paper"), memory_mb: int = Form(2048), cpu_limit: float = Form(2), disk_limit_mb: int = Form(10240), owner_id: int = Form(0), port: int = Form(0), agree_eula: str = Form("")):
    u = require_user(request)
    if agree_eula != "yes":
        request.session["error"] = "You must confirm the Minecraft EULA before creating a server."; return RedirectResponse("/servers/create", 303)
    if server_type not in {"vanilla", "paper", "purpur", "fabric"}:
        raise HTTPException(400, "Unsupported server software")
    if not name.strip() or len(name.strip()) > 64:
        raise HTTPException(400, "Server name must be 1-64 characters")
    if memory_mb < 512 or memory_mb > 1_048_576:
        raise HTTPException(400, "Memory must be between 512 MB and 1 TB")
    if not (0.25 <= cpu_limit <= 256):
        raise HTTPException(400, "CPU must be between 0.25 and 256 cores")
    if disk_limit_mb < 2048 or disk_limit_mb > 10_485_760:
        raise HTTPException(400, "Disk must be between 2 GB and 10 TB")
    owner = u["id"]
    if u["role"] == "admin" and owner_id:
        c = db(); exists = c.execute("SELECT id FROM users WHERE id=?", (owner_id,)).fetchone(); c.close()
        if not exists: raise HTTPException(400, "Selected owner does not exist")
        owner = owner_id
    selected_port = int(port) if port else next_free_port()
    if not 25565 <= selected_port <= 65535 or not check_port_available(selected_port):
        raise HTTPException(400, "Selected server port is unavailable")
    rcon_port = next_rcon_port()
    uuid = secrets.token_hex(16)
    container = f"sky-mc-{uuid[:20]}"
    jar = "server.jar"
    javamajor = java_for_minecraft(version.strip())
    if server_type == "fabric": jar = "server.jar"
    rcon_password = secrets.token_urlsafe(24)
    c = db()
    cur = c.execute("INSERT INTO servers(uuid,name,owner_id,version,server_type,jar,java_major,port,rcon_port,rcon_password,memory_mb,cpu_limit,disk_limit_mb,status,container_name) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (uuid, name.strip(), owner, version.strip(), server_type, jar, javamajor, selected_port, rcon_port, rcon_password, memory_mb, cpu_limit, disk_limit_mb, "installing", container))
    sid = int(cur.lastrowid); c.commit(); c.close()
    root = SERVERS_DIR / uuid; root.mkdir(parents=True, exist_ok=True)
    (root / "provisioning.json").write_text(json.dumps({"server_id": sid, "started_at": int(time.time())}, indent=2), encoding="utf-8")
    activity("server.created", int(u["id"]), sid, f"Created for user {owner}")
    executor.submit(provision_server, sid)
    return RedirectResponse(f"/server/{sid}", 303)


@app.get("/server/{server_id}", response_class=HTMLResponse)
def server_page(request: Request, server_id: int):
    s = access_server(request, server_id); refresh_status(server_id); s = get_server(server_id)
    c = db(); backups = c.execute("SELECT * FROM backups WHERE server_id=? ORDER BY id DESC LIMIT 10", (server_id,)).fetchall(); schedules = c.execute("SELECT * FROM schedules WHERE server_id=? ORDER BY id DESC", (server_id,)).fetchall(); subs = c.execute("SELECT su.*,u.username FROM subusers su JOIN users u ON u.id=su.user_id WHERE su.server_id=?", (server_id,)).fetchall(); c.close()
    return templates.TemplateResponse("server_detail.html", ctx(request, server=dict(s), stats=docker_stats(s), backups=[dict(x) for x in backups], schedules=[dict(x) for x in schedules], subusers=[dict(x) for x in subs], console_token=token_for_ws(int(request.session["uid"]), server_id)))


@app.post("/server/{server_id}/action/{action}")
def server_action(request: Request, server_id: int, action: str):
    s = access_server(request, server_id); u = require_user(request)
    try:
        docker_action(s, action); activity(f"server.{action}", u["id"], server_id)
        return JSONResponse({"ok": True, "status": refresh_status(server_id)})
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)


@app.get("/api/servers/{server_id}/status")
def api_server_status(request: Request, server_id: int):
    access_server(request, server_id); s = get_server(server_id); status = refresh_status(server_id); return {"status": status, "stats": docker_stats(s)}


@app.get("/api/servers/{server_id}/logs")
def api_server_logs(request: Request, server_id: int, tail: int = 500):
    access_server(request, server_id); s = get_server(server_id); return PlainTextResponse(docker_logs(s, tail))


@app.post("/api/servers/{server_id}/command")
def api_server_command(request: Request, server_id: int, command: str = Form(...)):
    s = access_server(request, server_id); u = require_user(request)
    try:
        output = rcon_command(s, command)
        activity("server.command", u["id"], server_id, command)
        return {"ok": True, "output": output}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)


@app.get("/api/servers/{server_id}/console-token")
def api_console_token(request: Request, server_id: int):
    access_server(request, server_id); return {"token": token_for_ws(int(request.session["uid"]), server_id)}


@app.websocket("/ws/server/{server_id}/console")
async def ws_console(websocket: WebSocket, server_id: int):
    token = websocket.query_params.get("token", "")
    uid = None
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode(); uid = int(raw.split(":", 1)[0])
    except Exception:
        pass
    if uid is None or not verify_ws_token(token, uid, server_id):
        await websocket.close(code=4401); return
    c = db(); allowed = c.execute("SELECT 1 FROM users u WHERE u.id=? AND (u.role='admin' OR u.id=(SELECT owner_id FROM servers WHERE id=?) OR EXISTS(SELECT 1 FROM subusers WHERE server_id=? AND user_id=u.id))", (uid, server_id, server_id)).fetchone(); c.close()
    if not allowed:
        await websocket.close(code=4403); return
    await websocket.accept()
    try:
        last = ""
        while True:
            s = get_server(server_id)
            if not s:
                break
            try:
                data = docker_logs(s, 350)
                if data != last:
                    await websocket.send_text(data); last = data
            except Exception as exc:
                await websocket.send_text(f"[SKY] Console unavailable: {exc}")
            await __import__("asyncio").sleep(1)
    except WebSocketDisconnect:
        pass


@app.get("/server/{server_id}/console", response_class=HTMLResponse)
def console_page(request: Request, server_id: int):
    s = access_server(request, server_id); return templates.TemplateResponse("console.html", ctx(request, server=dict(s), console_token=token_for_ws(int(request.session["uid"]), server_id)))


@app.get("/server/{server_id}/files", response_class=HTMLResponse)
def files_page(request: Request, server_id: int, path: str = ""):
    s = access_server(request, server_id); root = server_root(s); p = safe_path(root, path); p.mkdir(parents=True, exist_ok=True)
    items = []
    for x in sorted(p.iterdir(), key=lambda q: (not q.is_dir(), q.name.lower())):
        items.append({"name": x.name, "is_dir": x.is_dir(), "size": x.stat().st_size if x.is_file() else 0})
    rel = "" if p == root else str(p.relative_to(root)).replace(os.sep, "/")
    parent = "" if not rel else str(Path(rel).parent).replace(os.sep, "/")
    return templates.TemplateResponse("files.html", ctx(request, server=dict(s), items=items, path=rel, parent=parent, error=request.session.pop("error", None)))


@app.get("/server/{server_id}/files/download")
def file_download(request: Request, server_id: int, path: str):
    s = access_server(request, server_id); p = safe_path(server_root(s), path)
    if not p.is_file(): raise HTTPException(404, "File not found")
    return FileResponse(p, filename=p.name, media_type=mimetypes.guess_type(p.name)[0] or "application/octet-stream")


@app.post("/server/{server_id}/files/save")
async def file_save(request: Request, server_id: int):
    s = access_server(request, server_id); payload = await request.json(); path = str(payload.get("path", "")); content = str(payload.get("content", ""))
    if len(content.encode()) > 10 * 1024 * 1024: raise HTTPException(400, "File too large")
    p = safe_path(server_root(s), path)
    if p.is_dir() or not p.name: raise HTTPException(400, "Invalid file")
    p.parent.mkdir(parents=True, exist_ok=True); p.write_text(content, encoding="utf-8")
    activity("file.saved", int(request.session["uid"]), server_id, path)
    return {"ok": True}


@app.post("/server/{server_id}/files/mkdir")
def file_mkdir(request: Request, server_id: int, path: str = Form(""), name: str = Form(...)):
    s = access_server(request, server_id); safe_name = Path(name).name
    if safe_name != name or safe_name in {"", ".", ".."}: raise HTTPException(400, "Invalid directory name")
    target = safe_path(server_root(s), f"{path}/{safe_name}"); target.mkdir(parents=True, exist_ok=False)
    return RedirectResponse(f"/server/{server_id}/files?path={urllib.parse.quote(path)}", 303)


@app.post("/server/{server_id}/files/upload")
async def file_upload(request: Request, server_id: int, file: UploadFile = File(...), path: str = Form("")):
    s = access_server(request, server_id); root = server_root(s); destination_dir = safe_path(root, path); destination_dir.mkdir(parents=True, exist_ok=True)
    name = Path(file.filename or "upload.bin").name
    destination = safe_path(destination_dir, name)
    limit = int(s["disk_limit_mb"]) * 1024 * 1024
    existing = sum(p.stat().st_size for p in root.rglob("*") if p.is_file())
    if existing >= limit:
        raise HTTPException(413, "Server disk quota has been reached")
    written = 0
    with destination.open("wb") as fh:
        while chunk := await file.read(1024 * 1024):
            written += len(chunk)
            if existing + written > limit:
                fh.close(); destination.unlink(missing_ok=True); raise HTTPException(413, "Upload would exceed the server disk quota")
            fh.write(chunk)
    return RedirectResponse(f"/server/{server_id}/files?path={urllib.parse.quote(path)}", 303)


@app.post("/server/{server_id}/files/delete")
def file_delete(request: Request, server_id: int, path: str = Form(...)):
    s = access_server(request, server_id); p = safe_path(server_root(s), path)
    if p == server_root(s): raise HTTPException(400, "Cannot delete server root")
    if p.is_dir(): shutil.rmtree(p)
    elif p.exists(): p.unlink()
    return RedirectResponse(f"/server/{server_id}/files?path={urllib.parse.quote(str(p.parent.relative_to(server_root(s)) if p.parent != server_root(s) else ''))}", 303)


@app.post("/server/{server_id}/files/rename")
async def file_rename(request: Request, server_id: int):
    s = access_server(request, server_id); payload = await request.json(); source = safe_path(server_root(s), str(payload.get("path", ""))); new_name = Path(str(payload.get("name", ""))).name
    if not source.exists() or not new_name or new_name != payload.get("name"): raise HTTPException(400, "Invalid rename")
    source.rename(source.with_name(new_name)); return {"ok": True}


@app.get("/server/{server_id}/editor", response_class=HTMLResponse)
def editor_page(request: Request, server_id: int, path: str = "server.properties"):
    s = access_server(request, server_id); p = safe_path(server_root(s), path)
    content = p.read_text(encoding="utf-8", errors="replace") if p.is_file() and p.stat().st_size <= 5*1024*1024 else ""
    return templates.TemplateResponse("editor.html", ctx(request, server=dict(s), file_path=str(p.relative_to(server_root(s))), content=content))


@app.get("/server/{server_id}/plugins", response_class=HTMLResponse)
def plugins_page(request: Request, server_id: int):
    s = access_server(request, server_id); return templates.TemplateResponse("plugins.html", ctx(request, server=dict(s), installed=installed_files(s, "plugins"), kind="plugin"))


@app.post("/server/{server_id}/plugins/install")
def plugins_install(request: Request, server_id: int, project_id: str = Form(...)):
    s = access_server(request, server_id)
    try:
        filename = install_modrinth(project_id, s, "plugin")
        return {"ok": True, "filename": filename}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/server/{server_id}/mods", response_class=HTMLResponse)
def mods_page(request: Request, server_id: int):
    s = access_server(request, server_id); return templates.TemplateResponse("mods.html", ctx(request, server=dict(s), installed=installed_files(s, "mods"), kind="mod"))


@app.post("/server/{server_id}/mods/install")
def mods_install(request: Request, server_id: int, project_id: str = Form(...)):
    s = access_server(request, server_id)
    try:
        filename = install_modrinth(project_id, s, "mod")
        return {"ok": True, "filename": filename}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/modrinth/search")
def api_modrinth_search(request: Request, q: str = "", kind: str = "plugin", version: str = "", loader: str = ""):
    require_user(request)
    if not q.strip(): return {"hits": []}
    try:
        return modrinth_search(q.strip(), kind, version.strip(), loader.strip() or None)
    except Exception as exc:
        raise HTTPException(502, f"Modrinth request failed: {exc}")


@app.get("/api/modrinth/project/{project_id}/versions")
def api_modrinth_versions(request: Request, project_id: str, version: str, loader: str):
    require_user(request)
    return modrinth_project_versions(project_id, version, loader)


@app.get("/server/{server_id}/backups", response_class=HTMLResponse)
def backups_page(request: Request, server_id: int):
    s = access_server(request, server_id); c = db(); rows = c.execute("SELECT * FROM backups WHERE server_id=? ORDER BY id DESC", (server_id,)).fetchall(); c.close()
    return templates.TemplateResponse("backups.html", ctx(request, server=dict(s), backups=[dict(x) for x in rows]))


@app.post("/server/{server_id}/backups/create")
def backup_create(request: Request, server_id: int):
    s = access_server(request, server_id)
    try:
        name, size = backup_server(s); return {"ok": True, "filename": name, "size": size}
    except Exception as exc: raise HTTPException(500, str(exc))


@app.get("/server/{server_id}/backups/{filename}")
def backup_download(request: Request, server_id: int, filename: str):
    s = access_server(request, server_id); p = safe_path(server_root(s) / "backups", filename)
    if not p.is_file(): raise HTTPException(404)
    return FileResponse(p, filename=p.name, media_type="application/zip")


@app.post("/server/{server_id}/backups/{filename}/restore")
def backup_restore(request: Request, server_id: int, filename: str):
    s = access_server(request, server_id); p = safe_path(server_root(s) / "backups", filename)
    if not p.is_file(): raise HTTPException(404)
    docker_action(s, "stop")
    root = server_root(s)
    with zipfile.ZipFile(p) as z:
        for info in z.infolist():
            target = safe_path(root, info.filename)
            if info.is_dir(): target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, target.open("wb") as dst: shutil.copyfileobj(src, dst)
    return {"ok": True}


@app.get("/server/{server_id}/schedules", response_class=HTMLResponse)
def schedules_page(request: Request, server_id: int):
    s = access_server(request, server_id); c = db(); rows = c.execute("SELECT * FROM schedules WHERE server_id=? ORDER BY id DESC", (server_id,)).fetchall(); c.close()
    return templates.TemplateResponse("schedules.html", ctx(request, server=dict(s), schedules=[dict(x) for x in rows]))


@app.post("/server/{server_id}/schedules")
def schedule_create(request: Request, server_id: int, name: str = Form(...), interval_minutes: int = Form(...), action: str = Form(...)):
    s = access_server(request, server_id)
    if action not in {"start", "stop", "restart", "backup"} or not 1 <= interval_minutes <= 10080: raise HTTPException(400, "Invalid schedule")
    c = db(); c.execute("INSERT INTO schedules(server_id,name,interval_minutes,action) VALUES(?,?,?,?)", (server_id, name.strip()[:80], interval_minutes, action)); c.commit(); c.close()
    return RedirectResponse(f"/server/{server_id}/schedules", 303)


@app.post("/server/{server_id}/schedules/{schedule_id}/delete")
def schedule_delete(request: Request, server_id: int, schedule_id: int):
    access_server(request, server_id); c=db(); c.execute("DELETE FROM schedules WHERE id=? AND server_id=?", (schedule_id, server_id)); c.commit(); c.close(); return RedirectResponse(f"/server/{server_id}/schedules",303)


@app.get("/server/{server_id}/players", response_class=HTMLResponse)
def players_page(request: Request, server_id: int):
    s = access_server(request, server_id); players=[]; output=""
    if refresh_status(server_id) == "running":
        try:
            output = rcon_command(s, "list")
            tail = output.split(":", 1)[-1].strip() if ":" in output else ""
            players = [x.strip() for x in tail.split(",") if x.strip()]
        except Exception as exc: output = str(exc)
    return templates.TemplateResponse("players.html", ctx(request, server=dict(s), players=players, rcon_output=output))


@app.get("/server/{server_id}/properties", response_class=HTMLResponse)
def properties_page(request: Request, server_id: int):
    s = access_server(request, server_id); p=server_root(s)/"server.properties"; lines=p.read_text(encoding="utf-8",errors="replace") if p.exists() else ""
    return templates.TemplateResponse("properties.html",ctx(request,server=dict(s),content=lines))


@app.post("/server/{server_id}/properties")
async def properties_save(request: Request, server_id: int):
    s=access_server(request,server_id); payload=await request.json(); content=str(payload.get("content",""))
    if len(content.encode()) > 1_000_000: raise HTTPException(400,"Properties too large")
    (server_root(s)/"server.properties").write_text(content,encoding="utf-8"); return {"ok":True}


@app.get("/server/{server_id}/startup", response_class=HTMLResponse)
def startup_page(request: Request, server_id: int):
    s=access_server(request,server_id); return templates.TemplateResponse("startup.html",ctx(request,server=dict(s),java_major=s["java_major"]))


@app.post("/server/{server_id}/startup")
def startup_save(request: Request, server_id:int, memory_mb:int=Form(...),cpu_limit:float=Form(...)):
    s=access_server(request,server_id)
    if memory_mb<512 or memory_mb>1_048_576 or cpu_limit<0.25 or cpu_limit>256: raise HTTPException(400,"Invalid resource settings")
    c=db(); c.execute("UPDATE servers SET memory_mb=?,cpu_limit=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(memory_mb,cpu_limit,server_id)); c.commit(); c.close(); s=get_server(server_id)
    shell(docker_cmd()+["update","--memory",f"{memory_mb}m","--cpus",str(cpu_limit),s["container_name"]],timeout=30,check=False)
    return RedirectResponse(f"/server/{server_id}/startup",303)


@app.get("/server/{server_id}/world", response_class=HTMLResponse)
def world_page(request: Request, server_id: int):
    s=access_server(request,server_id); root=server_root(s); worlds=[]
    for name in ("world","world_nether","world_the_end"):
        p=root/name; worlds.append({"name":name,"exists":p.exists(),"size":sum(x.stat().st_size for x in p.rglob("*") if x.is_file()) if p.exists() else 0})
    return templates.TemplateResponse("world.html",ctx(request,server=dict(s),worlds=worlds))


@app.post("/server/{server_id}/world/reset")
def world_reset(request:Request,server_id:int,world:str=Form(...)):
    s=access_server(request,server_id)
    if world not in {"world","world_nether","world_the_end"}: raise HTTPException(400,"Invalid world")
    docker_action(s,"stop")
    p=server_root(s)/world
    if p.exists(): p.rename(server_root(s)/(world+f".reset-{int(time.time())}"))
    return RedirectResponse(f"/server/{server_id}/world",303)


@app.get("/server/{server_id}/subusers", response_class=HTMLResponse)
def subusers_page(request:Request,server_id:int):
    s=access_server(request,server_id); require_admin(request) if user_from_request(request)["role"]=="admin" else None
    c=db(); users=c.execute("SELECT id,username FROM users WHERE id<>? ORDER BY username",(s["owner_id"],)).fetchall(); subs=c.execute("SELECT su.*,u.username FROM subusers su JOIN users u ON u.id=su.user_id WHERE su.server_id=?",(server_id,)).fetchall(); c.close()
    return templates.TemplateResponse("subusers.html",ctx(request,server=dict(s),users=[dict(x) for x in users],subusers=[dict(x) for x in subs]))


@app.post("/server/{server_id}/subusers")
def subuser_add(request:Request,server_id:int,user_id:int=Form(...),permissions:str=Form("console,files")):
    s=access_server(request,server_id); u=require_user(request)
    if u["role"]!="admin" and s["owner_id"]!=u["id"]: raise HTTPException(403)
    c=db(); c.execute("INSERT OR REPLACE INTO subusers(server_id,user_id,permissions) VALUES(?,?,?)",(server_id,user_id,permissions[:500])); c.commit(); c.close(); return RedirectResponse(f"/server/{server_id}/subusers",303)


@app.post("/server/{server_id}/subusers/{sub_id}/delete")
def subuser_delete(request:Request,server_id:int,sub_id:int):
    s=access_server(request,server_id); u=require_user(request)
    if u["role"]!="admin" and s["owner_id"]!=u["id"]: raise HTTPException(403)
    c=db(); c.execute("DELETE FROM subusers WHERE id=? AND server_id=?",(sub_id,server_id)); c.commit(); c.close(); return RedirectResponse(f"/server/{server_id}/subusers",303)


@app.get("/server/{server_id}/network", response_class=HTMLResponse)
def network_page(request:Request,server_id:int):
    s=access_server(request,server_id)
    local_ip="127.0.0.1"
    try:
        local_ip=socket.gethostbyname(socket.gethostname())
    except Exception: pass
    public_ip="Unavailable"
    try: public_ip=httpx.get("https://api.ipify.org",timeout=5).text.strip()
    except Exception: pass
    return templates.TemplateResponse("network.html",ctx(request,server=dict(s),local_ip=local_ip,public_ip=public_ip))


@app.get("/server/{server_id}/tunnel", response_class=HTMLResponse)
def tunnel_page(request:Request,server_id:int):
    s=access_server(request,server_id)
    playit = shutil.which("playit") or shutil.which("playit-linux-amd64")
    return templates.TemplateResponse("tunnel.html",ctx(request,server=dict(s),playit=bool(playit),playit_path=playit or ""))


@app.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request):
    u=require_user(request); return templates.TemplateResponse("settings.html",ctx(request,user=u))


@app.get("/server/{server_id}/settings", response_class=HTMLResponse)
def server_settings_page(request: Request, server_id: int):
    s=access_server(request,server_id); return templates.TemplateResponse("server_settings.html",ctx(request,server=dict(s)))


@app.get("/server/{server_id}/sftp", response_class=HTMLResponse)
def sftp_page(request: Request, server_id: int):
    s=access_server(request,server_id); return templates.TemplateResponse("sftp.html",ctx(request,server=dict(s)))


@app.get("/account", response_class=HTMLResponse)
def account_page(request:Request):
    u=require_user(request); return templates.TemplateResponse("account.html",ctx(request,user=u,error=request.session.pop("error",None)))


@app.post("/account/password")
def account_password(request:Request,current_password:str=Form(...),new_password:str=Form(...)):
    u=require_user(request)
    if len(new_password)<8 or not verify_password(current_password,u["password_hash"]):
        request.session["error"]="Current password is incorrect or new password is too short"; return RedirectResponse("/account",303)
    c=db(); c.execute("UPDATE users SET password_hash=? WHERE id=?",(hash_password(new_password),u["id"])); c.commit(); c.close(); request.session.clear(); return RedirectResponse("/login",303)


@app.get("/activity", response_class=HTMLResponse)
def activity_page(request:Request):
    u=require_user(request); c=db(); rows=c.execute("SELECT a.*,u.username,s.name server_name FROM activity a LEFT JOIN users u ON u.id=a.user_id LEFT JOIN servers s ON s.id=a.server_id ORDER BY a.id DESC LIMIT 200").fetchall(); c.close(); return templates.TemplateResponse("activity.html",ctx(request,rows=[dict(x) for x in rows]))


@app.get("/api-keys", response_class=HTMLResponse)
def api_keys_page(request:Request):
    u=require_user(request); c=db(); rows=c.execute("SELECT id,name,prefix,created_at,last_used FROM api_keys WHERE user_id=? ORDER BY id DESC",(u["id"],)).fetchall(); c.close(); return templates.TemplateResponse("api_keys.html",ctx(request,keys=[dict(x) for x in rows],new_key=request.session.pop("new_api_key",None)))


@app.post("/api-keys")
def create_api_key(request:Request,name:str=Form(...)):
    u=require_user(request); raw="sky_"+secrets.token_urlsafe(32); digest=hashlib.sha256(raw.encode()).hexdigest(); c=db(); c.execute("INSERT INTO api_keys(user_id,name,key_hash,prefix) VALUES(?,?,?,?)",(u["id"],name.strip()[:64],digest,raw[:12])); c.commit(); c.close(); request.session["new_api_key"]=raw; return RedirectResponse("/api-keys",303)


@app.post("/api-keys/{key_id}/delete")
def delete_api_key(request:Request,key_id:int):
    u=require_user(request); c=db(); c.execute("DELETE FROM api_keys WHERE id=? AND user_id=?",(key_id,u["id"])); c.commit(); c.close(); return RedirectResponse("/api-keys",303)


# ---------- Admin ----------
@app.get("/admin", response_class=HTMLResponse)
def admin_dashboard(request:Request):
    require_admin(request); c=db(); counts={"users":c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],"servers":c.execute("SELECT COUNT(*) n FROM servers").fetchone()["n"],"running":c.execute("SELECT COUNT(*) n FROM servers WHERE status='running'").fetchone()["n"],"backups":c.execute("SELECT COUNT(*) n FROM backups").fetchone()["n"]}; c.close(); return templates.TemplateResponse("admin_dashboard.html",ctx(request,counts=counts,host=host_stats(),docker=docker_ok()))


@app.get("/admin/users", response_class=HTMLResponse)
def admin_users(request:Request):
    require_admin(request); c=db(); rows=c.execute("SELECT id,username,role,created_at,last_login FROM users ORDER BY id").fetchall(); c.close(); return templates.TemplateResponse("admin_users.html",ctx(request,users=[dict(x) for x in rows]))


@app.post("/admin/users/create")
def admin_create_user(request:Request,username:str=Form(...),password:str=Form(...),role:str=Form("user")):
    require_admin(request)
    if not username.strip() or len(password)<6 or role not in {"admin","user"}: raise HTTPException(400,"Invalid user data")
    c=db()
    try: c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",(username.strip()[:32],hash_password(password),role)); c.commit()
    except sqlite3.IntegrityError: request.session["error"]="Username already exists"
    c.close(); return RedirectResponse("/admin/users",303)


@app.post("/admin/users/{user_id}/delete")
def admin_delete_user(request:Request,user_id:int):
    u=require_admin(request)
    if user_id==u["id"]: raise HTTPException(400,"You cannot delete yourself")
    c=db(); c.execute("DELETE FROM users WHERE id=?",(user_id,)); c.commit(); c.close(); return RedirectResponse("/admin/users",303)


@app.post("/admin/users/{user_id}/role")
def admin_role(request:Request,user_id:int,role:str=Form(...)):
    u=require_admin(request)
    if user_id==u["id"]: raise HTTPException(400,"You cannot change your own role")
    if role not in {"admin","user"}: raise HTTPException(400,"Invalid role")
    c=db(); c.execute("UPDATE users SET role=? WHERE id=?",(role,user_id)); c.commit(); c.close(); return RedirectResponse("/admin/users",303)


@app.get("/admin/servers", response_class=HTMLResponse)
def admin_servers(request:Request):
    require_admin(request); c=db(); rows=c.execute("SELECT s.*,u.username owner_name FROM servers s JOIN users u ON u.id=s.owner_id ORDER BY s.id DESC").fetchall(); users=c.execute("SELECT id,username FROM users ORDER BY username").fetchall(); c.close(); return templates.TemplateResponse("admin_servers.html",ctx(request,servers=[dict(x) for x in rows],users=[dict(x) for x in users]))


@app.post("/admin/servers/{server_id}/owner")
def admin_server_owner(request:Request,server_id:int,owner_id:int=Form(...)):
    require_admin(request); c=db(); c.execute("UPDATE servers SET owner_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(owner_id,server_id)); c.commit(); c.close(); return RedirectResponse("/admin/servers",303)


@app.post("/admin/servers/{server_id}/suspend")
def admin_suspend(request:Request,server_id:int,suspended:int=Form(...)):
    require_admin(request); c=db(); c.execute("UPDATE servers SET suspended=? WHERE id=?",(1 if suspended else 0,server_id)); c.commit(); c.close();
    s=get_server(server_id)
    if suspended: shell(docker_cmd()+["stop",s["container_name"]],timeout=30,check=False)
    return RedirectResponse("/admin/servers",303)


@app.post("/admin/servers/{server_id}/delete")
def admin_delete_server(request:Request,server_id:int):
    require_admin(request); s=get_server(server_id)
    if s:
        shell(docker_cmd()+["rm","-f",s["container_name"]],timeout=30,check=False)
        shutil.rmtree(server_root(s),ignore_errors=True)
        c=db(); c.execute("DELETE FROM servers WHERE id=?",(server_id,)); c.commit(); c.close()
    return RedirectResponse("/admin/servers",303)


@app.get("/admin/settings", response_class=HTMLResponse)
def admin_settings(request:Request):
    require_admin(request); return templates.TemplateResponse("admin_settings.html",ctx(request,values=settings_dict()))


@app.post("/admin/settings")
def admin_settings_save(request:Request,site_name:str=Form(...),site_tagline:str=Form(...),default_memory:str=Form(...),default_cpu:str=Form(...),default_disk:str=Form(...),server_port_start:str=Form(...)):
    require_admin(request); data={"site_name":site_name,"site_tagline":site_tagline,"default_memory":default_memory,"default_cpu":default_cpu,"default_disk":default_disk,"server_port_start":server_port_start}; c=db()
    for k,v in data.items(): c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,str(v)))
    c.commit(); c.close(); return RedirectResponse("/admin/settings",303)


@app.get("/admin/system", response_class=HTMLResponse)
def admin_system(request:Request):
    require_admin(request); node=db().execute("SELECT * FROM local_node WHERE id=1").fetchone(); return templates.TemplateResponse("admin_system.html",ctx(request,node=dict(node),host=host_stats(),docker=docker_ok()))


@app.get("/admin/api-keys", response_class=HTMLResponse)
def admin_api_keys(request:Request):
    require_admin(request); c=db(); rows=c.execute("SELECT k.*,u.username FROM api_keys k JOIN users u ON u.id=k.user_id ORDER BY k.id DESC").fetchall(); c.close(); return templates.TemplateResponse("admin_api_keys.html",ctx(request,keys=[dict(x) for x in rows]))


@app.get("/health")
def health():
    return {"ok": True, "panel": APP_VERSION, "docker": docker_ok(), "database": DB_PATH.exists(), "local_node": True}


@app.get("/api/versions")
def api_versions(request:Request,software:str="vanilla"):
    require_user(request)
    versions=vanilla_release_versions()
    if software in {"vanilla","paper","purpur","fabric"}:
        return {"versions": versions}
    raise HTTPException(400,"Unsupported software")


@app.get("/api/system")
def api_system(request:Request):
    require_admin(request); return {"host":host_stats(),"docker":docker_ok(),"node":{"id":1,"name":"Local Node","capacity":"unlimited*"}}


@app.get("/robots.txt")
def robots():
    return PlainTextResponse("User-agent: *\nDisallow: /admin\n")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host=APP_HOST, port=APP_PORT, reload=False)
