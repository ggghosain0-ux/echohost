import importlib.util, os, shutil, subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parents[1]
checks=[]
checks.append(("python", sys.version.split()[0]))
checks.append(("docker-cli", shutil.which("docker") or "missing"))
try:
    p=subprocess.run(["docker","info"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)
    checks.append(("docker-daemon","ok" if p.returncode==0 else "unreachable"))
except Exception as e: checks.append(("docker-daemon",f"error: {e}"))
for mod in ("fastapi","uvicorn","jinja2","httpx","psutil"):
    checks.append((mod,"installed" if importlib.util.find_spec(mod) else "missing"))
checks.append(("database","ok" if (base/'data'/'sky.db').exists() else "not initialized"))
for k,v in checks: print(f"{k:16} {v}")
