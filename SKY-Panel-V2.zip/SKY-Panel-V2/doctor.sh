#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
.venv/bin/python scripts/doctor.py
