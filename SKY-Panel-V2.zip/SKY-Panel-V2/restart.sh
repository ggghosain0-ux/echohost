#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
./stop.sh
./start.sh
