#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ -f sky-panel.pid ]]; then
  pid="$(cat sky-panel.pid)"
  if kill -0 "$pid" 2>/dev/null; then kill "$pid" || true; fi
  for _ in {1..20}; do kill -0 "$pid" 2>/dev/null || break; sleep 0.2; done
  kill -9 "$pid" 2>/dev/null || true
  rm -f sky-panel.pid
fi
echo "SKY Panel stopped."
