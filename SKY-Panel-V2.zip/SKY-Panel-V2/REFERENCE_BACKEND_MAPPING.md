# Backend reference mapping

The supplied JTG project was inspected for reusable backend architecture and feature behavior. SKY Panel V2 reimplements these ideas in a new Python/FastAPI backend and does not reuse the supplied React frontend.

| JTG backend area | SKY V2 implementation |
|---|---|
| Docker lifecycle service | `app.py` Docker helpers and server runtime actions |
| JAR downloader | Mojang/Paper/Purpur/Fabric upstream downloader |
| Runtime provider concept | Single automatic local-node runtime |
| Server controllers | FastAPI server routes |
| File manager | Safe path resolver + upload/download/editor |
| Backups | ZIP backup/restore subsystem |
| Mod/plugin managers | Modrinth API search + compatible JAR install |
| World manager | World directory inspection/reset |
| Server console | Docker log stream + real RCON command path |
| Admin settings/users | Admin pages and SQLite tables |
| API keys | Hashed API-key records and one-time display |

The Nodes UI is intentionally omitted as requested; the installation creates one local node automatically.
