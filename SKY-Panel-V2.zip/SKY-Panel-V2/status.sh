#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ -f .env ]]; then set -a; source .env; set +a; fi
printf 'SKY Panel: '
if [[ -f sky-panel.pid ]] && kill -0 "$(cat sky-panel.pid)" 2>/dev/null; then echo "RUNNING (PID $(cat sky-panel.pid))"; else echo "STOPPED"; fi
printf 'HTTP health: '
if command -v curl >/dev/null 2>&1 && curl -fsS "http://127.0.0.1:${APP_PORT:-8080}/health" >/dev/null 2>&1; then echo "OK"; else echo "UNAVAILABLE"; fi
printf 'Docker: '
if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then echo "OK"; else echo "UNAVAILABLE"; fi
