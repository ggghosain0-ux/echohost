Runtime database and secret storage live here. Do not delete this directory after installation.
