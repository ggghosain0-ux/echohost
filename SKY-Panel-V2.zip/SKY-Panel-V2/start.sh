#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
mkdir -p logs data server-data
if [[ -f .env ]]; then set -a; source .env; set +a; fi
if [[ -f sky-panel.pid ]] && kill -0 "$(cat sky-panel.pid)" 2>/dev/null; then echo "SKY Panel is already running (PID $(cat sky-panel.pid))."; exit 0; fi
if [[ ! -x .venv/bin/uvicorn ]]; then echo "Virtual environment missing. Run ./install.sh first."; exit 1; fi
nohup .venv/bin/uvicorn app:app --host "${APP_HOST:-0.0.0.0}" --port "${APP_PORT:-8080}" > logs/panel.log 2>&1 &
echo $! > sky-panel.pid
sleep 2
if ! kill -0 "$(cat sky-panel.pid)" 2>/dev/null; then echo "Panel failed to start. See logs/panel.log"; exit 1; fi
echo "SKY Panel started on port ${APP_PORT:-8080} (PID $(cat sky-panel.pid))."
