#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo; echo "[SKY] Installation failed at line $LINENO. See logs and rerun install.sh after fixing the reported issue."' ERR
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
log(){ echo -e "${CYAN}[SKY]${NC} $*"; }
ok(){ echo -e "${GREEN}[OK]${NC} $*"; }
warn(){ echo -e "${YELLOW}[WARN]${NC} $*"; }

as_root(){ if [[ $(id -u) -eq 0 ]]; then "$@"; else sudo "$@"; fi; }


if command -v apt-get >/dev/null 2>&1; then
  log "Installing required Debian/Ubuntu packages..."
  as_root apt-get update -y
  as_root apt-get install -y python3 python3-venv python3-pip curl ca-certificates git unzip sqlite3 docker.io
elif command -v dnf >/dev/null 2>&1; then
  log "Installing required RPM packages..."
  as_root dnf install -y python3 python3-pip curl ca-certificates git unzip docker
elif command -v yum >/dev/null 2>&1; then
  log "Installing required RPM packages..."
  as_root yum install -y python3 python3-pip curl ca-certificates git unzip docker
else
  echo -e "${RED}Unsupported package manager. Install Python 3.10+, Docker, curl and unzip manually.${NC}"; exit 1
fi

if ! command -v docker >/dev/null 2>&1; then echo "Docker CLI installation failed."; exit 1; fi

# Start Docker directly with dockerd; no system service is invoked.
if ! docker info >/dev/null 2>&1 && ! sudo -n docker info >/dev/null 2>&1; then
  if command -v dockerd >/dev/null 2>&1; then
    log "Docker daemon is not running; launching dockerd directly..."
    as_root mkdir -p /run/docker "$APP_DIR/logs"
    as_root sh -c "nohup dockerd > '$APP_DIR/logs/dockerd.log' 2>&1 < /dev/null & echo \$! > '$APP_DIR/data/dockerd.pid'"
    for i in $(seq 1 45); do
      if docker info >/dev/null 2>&1 || sudo -n docker info >/dev/null 2>&1; then break; fi
      sleep 1
    done
  fi
fi

if ! docker info >/dev/null 2>&1 && ! sudo -n docker info >/dev/null 2>&1; then
  echo -e "${RED}Docker daemon is not reachable.${NC} Read logs/dockerd.log, then run ./install.sh again."
  exit 1
fi

# Give the current login a docker-group path where possible. The panel can also use sudo -n docker.
if command -v usermod >/dev/null 2>&1 && [[ $(id -u) -ne 0 ]]; then as_root usermod -aG docker "$USER" || true; fi

log "Creating Python virtual environment..."
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel
.venv/bin/pip install -r requirements.txt

if [[ ! -f .env ]]; then
  umask 077
  secret="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
)"
  cat > .env <<EOF
APP_HOST=0.0.0.0
APP_PORT=${APP_PORT:-8080}
DATA_DIR=$APP_DIR/data
SERVER_DATA_DIR=$APP_DIR/server-data
LOG_DIR=$APP_DIR/logs
SECRET_KEY=$secret
SKY_ADMIN_USER=admin
SKY_ADMIN_PASS=admin
EOF
else
  warn ".env already exists; preserving it."
fi

log "Initializing database..."
.venv/bin/python - <<'PY'
import app
print('database ready')
PY

chmod +x start.sh stop.sh restart.sh logs.sh doctor.sh
./start.sh
sleep 2
curl -fsS "http://127.0.0.1:${APP_PORT:-8080}/health" >/dev/null
ok "SKY Panel is running."
echo
printf 'URL: http://SERVER-IP:%s\n' "${APP_PORT:-8080}"
echo 'Default admin: admin / admin'
echo 'Panel log: logs/panel.log'
echo 'Docker log: logs/dockerd.log (only if dockerd was started by this installer)'
echo
warn 'Change the admin password before public deployment.'
warn 'The local node has no artificial panel quota; hardware and Docker remain the real limits.'
