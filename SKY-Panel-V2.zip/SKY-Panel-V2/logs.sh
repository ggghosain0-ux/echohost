#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
tail -n 200 -f logs/panel.log
