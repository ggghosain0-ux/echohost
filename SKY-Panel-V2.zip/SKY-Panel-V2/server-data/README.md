Minecraft server data is created here as one directory per server UUID. Each directory contains the real server.jar and generated Minecraft data after provisioning.
