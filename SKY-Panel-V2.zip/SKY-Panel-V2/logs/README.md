Runtime logs are written here by start.sh and the direct dockerd launcher.
