# SKY Panel V2

SKY Panel V2 is a new, self-hosted Minecraft hosting control panel inspired by the workflow of Pterodactyl. The implementation uses the JTG reference ZIP for backend ideas and working patterns (Docker lifecycle, JAR downloading, server file operations, backups, Modrinth integration, SFTP/world concepts), but this project has a new backend layout and a completely original frontend.

## What is real

- Docker-backed Minecraft server containers.
- Per-server RAM/CPU limits.
- Real server JAR download on provisioning.
- Mojang official version manifest for Vanilla releases from 1.19.x onward, including 26.2 when present in the live manifest.
- Paper, Purpur and Fabric upstream JAR acquisition.
- Real RCON commands for server console operations.
- Live console log stream over WebSocket.
- File manager, uploads, downloads, editing and safe path checks.
- Backups and restore.
- Schedules for start/stop/restart/backup.
- Modrinth search and compatible plugin/mod downloads.
- Admin user management and server ownership assignment.
- API key page.
- Network and optional Playit information pages.
- One automatically-created local node; no node management UI.

## Local node capacity

The local node is intentionally not given an artificial panel quota (`0` means unlimited in the panel). Real capacity is still limited by the VPS/host hardware, filesystem and Docker runtime.

## Installer

`install.sh` installs dependencies, creates a virtual environment, starts `dockerd` directly when necessary, initializes the database, and starts the panel with `nohup`. It does not call `systemctl` or `systemd` commands.

```bash
chmod +x install.sh
./install.sh
```

Panel: `http://SERVER-IP:8080`

Default admin: `admin / admin`

## Minecraft JARs

Minecraft server binaries are not bundled into the ZIP. SKY Panel downloads the requested JAR at provisioning time from upstream sources. This keeps the project lightweight and allows the supported-version selector to follow upstream releases instead of shipping a stale binary.

The official Minecraft server download page states that the Java Edition server software is free to download, and the 26.2 release page currently exposes the official server JAR. See the sources listed below.

## Notes

- Opening the allocated Minecraft TCP port in your VPS/cloud firewall is still required for public access.
- Docker bind-mounted disk limits are filesystem-dependent; SKY Panel also enforces the configured quota for panel uploads, but cannot guarantee a hard block quota on every storage driver.
- Paper's current documentation lists Java 17 for 1.17-1.19, Java 21 for 1.20-1.21.11, and Java 25 for 26.1+; SKY Panel selects those Java images automatically.
- Modrinth compatibility uses the official API's project-version and file metadata.

## Reference sources

- Mojang server download: https://www.minecraft.net/en-us/download/server
- Mojang 26.2 release: https://feedback.minecraft.net/hc/en-us/articles/46690753273997-Minecraft-Java-Edition-26-2
- Paper docs: https://docs.papermc.io/paper/getting-started/
- Modrinth API docs: https://docs.modrinth.com/api/
