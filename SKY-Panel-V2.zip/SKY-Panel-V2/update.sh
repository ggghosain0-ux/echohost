#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
./stop.sh || true
.venv/bin/pip install -r requirements.txt
./start.sh
