#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "ECHO CLOUD — CodeSandbox installer"
command -v node >/dev/null || { echo "Node.js is required"; exit 1; }
node -e 'process.exit(+process.versions.node.split(".")[0] < 20)' || { echo "Node.js 20+ required"; exit 1; }
[ -f .env ] || cp .env.example .env
node - <<'NODE'
const fs=require('fs');let p='.env',s=fs.readFileSync(p,'utf8');if(/JWT_SECRET=replace/.test(s))s=s.replace(/JWT_SECRET=.*/,`JWT_SECRET=${require('crypto').randomBytes(32).toString('hex')}`);if(/ECHO_NODE_TOKEN=replace/.test(s))s=s.replace(/ECHO_NODE_TOKEN=.*/,`ECHO_NODE_TOKEN=${require('crypto').randomBytes(32).toString('hex')}`);fs.writeFileSync(p,s);
NODE
npm install
echo "Installed. Start with: npm run dev"
echo "The API auto-creates the Local Node because ECHO_AUTO_NODE=true."
