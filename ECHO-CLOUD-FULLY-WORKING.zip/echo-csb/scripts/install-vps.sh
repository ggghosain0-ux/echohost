#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "ECHO CLOUD — VPS installer"
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
command -v node >/dev/null || { echo "Node.js 20+ is required. Install Node.js first."; exit 1; }
node -e 'process.exit(+process.versions.node.split(".")[0] < 20)' || { echo "Node.js 20+ required"; exit 1; }
if ! command -v docker >/dev/null; then
  echo "Docker not found. Installing Docker Engine..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable --now docker || true
fi
[ -f .env ] || cp .env.example .env
node - <<'NODE'
const fs=require('fs'),crypto=require('crypto');let p='.env',s=fs.readFileSync(p,'utf8');const set=(k,v)=>{const r=new RegExp('^'+k+'=.*$','m');s=r.test(s)?s.replace(r,`${k}=${v}`):s+`\n${k}=${v}`};set('NODE_ENV','production');set('JWT_SECRET',crypto.randomBytes(48).toString('hex'));set('ECHO_NODE_TOKEN',crypto.randomBytes(48).toString('hex'));set('ECHO_AUTO_NODE','true');set('ECHO_API_URL','http://127.0.0.1:4000');fs.writeFileSync(p,s);
NODE
npm install
npm run build:all
mkdir -p /var/lib/echo-cloud
cat >/etc/systemd/system/echo-cloud-api.service <<EOF
[Unit]
Description=ECHO CLOUD API
After=network.target docker.service
[Service]
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=/usr/bin/npm run start:api
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
cat >/etc/systemd/system/echo-cloud-agent.service <<EOF
[Unit]
Description=ECHO CLOUD Local Node Agent
After=network.target docker.service echo-cloud-api.service
[Service]
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=/usr/bin/npm run start:agent
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now echo-cloud-api.service echo-cloud-agent.service
echo "ECHO CLOUD API and local node agent are installed and enabled."
echo "API: http://SERVER_IP:4000"
