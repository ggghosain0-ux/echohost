# ECHO CLOUD

**One Panel. Every Server.**

ECHO CLOUD is a multi-service hosting control-plane monorepo designed for Minecraft, websites, Node/Python bots, Docker apps and VPS infrastructure.

## What is implemented
- Real authentication with password hashing, JWTs, roles and scoped resource access.
- Persistent CodeSandbox development store (`apps/api/.echo-data/store.json`).
- Service creation and lifecycle API with provider boundaries.
- Node registration/heartbeat API and live-metrics model.
- Admin overview and user controls.
- Domain + DNS abstraction and backup abstraction.
- Audit activity and notifications models.
- File-path traversal protection and resource/port validation primitives.
- Separate worker and ECHO AGENT processes.
- React/Vite responsive control panel with real API data and no fabricated metrics.
- Prisma PostgreSQL schema retained for production deployment.

## Production architecture
Internet → Reverse Proxy → Web/API → PostgreSQL + Redis/Queue → Worker → ECHO AGENTS → Docker/Hypervisor/Storage/DNS providers.

The public API must not receive unrestricted host access or a Docker socket. ECHO AGENT is the trust boundary for node operations. In production, replace the local provider adapters with authenticated agent calls using mTLS/signed requests.

## CodeSandbox
CodeSandbox is suitable for UI/API development, but it is not a safe or durable environment for provisioning arbitrary Docker containers or real VPS hypervisors. The included local provider therefore records and validates requests without pretending that infrastructure was created.

```bash
npm install
cp .env.example .env
npm run dev
```

Open the Vite preview on port **5173**. The API listens on **4000**.

## Production prerequisites
- PostgreSQL
- Redis or a durable job queue
- HTTPS reverse proxy
- One or more ECHO AGENT nodes
- Docker and/or Proxmox/Libvirt on nodes
- Object storage for backups
- DNS provider credentials kept server-side
- Strong `JWT_SECRET` and agent authentication

Do not expose the development JWT secret or local JSON store in production.


## Installers

### CodeSandbox
Run `bash scripts/install-codesandbox.sh`, then `npm run dev`. The API automatically registers a local logical node. CodeSandbox cannot provide privileged Docker/VPS infrastructure reliably, so actual containers/VMs require an external node.

### Linux VPS
Run `sudo bash scripts/install-vps.sh`. The installer installs Docker when needed, generates secrets, builds the API and agent, and registers the VPS itself as the local ECHO node.

### Important production boundary
The local node is real as a control-plane node and reports host resources. Actual VPS provisioning requires a hypervisor provider (Proxmox/Libvirt) and actual Docker workloads require Docker Engine. The panel never fabricates infrastructure metrics.
