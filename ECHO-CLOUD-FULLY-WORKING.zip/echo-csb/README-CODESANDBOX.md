# ECHO CLOUD — CodeSandbox Edition

This package is configured for a CodeSandbox Node/Devbox workspace.

## Run

```bash
npm install
npm run dev
```

The root `dev` script starts the Fastify API on port 4000 and the Vite panel on port 5173. CodeSandbox previews port 5173.

## Development adapter

CodeSandbox does not provide the privileged infrastructure required to run production Docker/Minecraft/VPS nodes. Therefore this edition uses a small file-backed local adapter at `apps/api/.echo-data` (created at runtime). It provides real HTTP authentication, password hashing, JWT sessions, service creation, service lifecycle state changes, activity records, validation and rate limiting without inventing infrastructure metrics.

For production, connect the existing provider/agent architecture to PostgreSQL, Redis, real ECHO Agents, Docker hosts and a VPS provider. Do not reuse the local adapter as a production database.

## First login

There is no hard-coded demo account. Click **Create an account**; the first registered account receives the OWNER role.
