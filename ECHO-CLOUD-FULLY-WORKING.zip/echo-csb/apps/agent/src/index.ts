import os from 'node:os';

const api=process.env.ECHO_API_URL;
const token=process.env.ECHO_NODE_TOKEN;
const port=Number(process.env.AGENT_PORT||8080);

async function post(path:string,body:unknown){
  if(!api||!token) return null;
  const r=await fetch(api.replace(/\/$/,'')+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
  if(!r.ok) throw new Error(`API ${r.status}`);
  return r.json() as Promise<any>;
}

async function main(){
  console.log(`ECHO AGENT listening on ${port}`);
  if(!api||!token){console.log('Agent is in standalone mode. Set ECHO_API_URL and ECHO_NODE_TOKEN to auto-register.');return;}
  const hostname=process.env.ECHO_NODE_HOSTNAME||os.hostname();
  let reg=await post('/api/agent/register',{token,name:process.env.ECHO_NODE_NAME||hostname,hostname,ip:process.env.ECHO_NODE_IP,cpuTotal:os.cpus().length,ramTotalMb:Math.floor(os.totalmem()/1048576)});
  const nodeId=reg.data.nodeId;
  console.log(`Registered local node ${nodeId}`);
  setInterval(async()=>{try{await post('/api/agent/heartbeat',{nodeId,token,cpuUsed:os.loadavg()[0],ramUsedMb:Math.floor((os.totalmem()-os.freem())/1048576)})}catch(e){console.error('Heartbeat failed:',e instanceof Error?e.message:e)}},30000);
}
main().catch(e=>{console.error(e);process.exit(1)});
