import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import {z} from 'zod';
import {randomUUID} from 'node:crypto';
import os from 'node:os';
import {initStore} from './store';
import {authRoutes,serviceRoutes,nodeRoutes,adminRoutes,domainRoutes,backupRoutes,activityRoutes} from './routes';

async function main(){
  await initStore();
  if(process.env.ECHO_AUTO_NODE==='true'){
    const {db,transaction}=await import('./store');
    const hostname=process.env.ECHO_NODE_HOSTNAME||os.hostname();
    const token=process.env.ECHO_NODE_TOKEN||randomUUID()+randomUUID();
    if(!db().nodes.some(n=>n.hostname===hostname)){
      await transaction(s=>s.nodes.push({id:randomUUID(),name:process.env.ECHO_NODE_NAME||'Local Node',hostname,ip:process.env.ECHO_NODE_IP,status:'ONLINE',token,cpuTotal:os.cpus().length,ramTotalMb:Math.floor(os.totalmem()/1048576),diskTotalMb:undefined,lastHeartbeat:new Date().toISOString()}));
    }
  }
  const app=Fastify({logger:true});
  await app.register(cors,{origin:true,credentials:true});
  await app.register(helmet);
  await app.register(rateLimit,{max:120,timeWindow:'1 minute'});
  await app.register(jwt,{secret:process.env.JWT_SECRET||'codesandbox-dev-secret-change-in-production'});
  app.get('/health',async()=>({ok:true,service:'echo-api',mode:'codesandbox-development',time:new Date().toISOString()}));
  await authRoutes(app); await serviceRoutes(app); await nodeRoutes(app); await adminRoutes(app); await domainRoutes(app); await backupRoutes(app); await activityRoutes(app);
  app.setErrorHandler((err,req,reply)=>{req.log.error({err},'request failed');if(err instanceof z.ZodError)return reply.code(400).send({success:false,error:{code:'VALIDATION_ERROR',message:'Invalid request data',details:err.issues}});return reply.code((err as any).statusCode||500).send({success:false,error:{code:'INTERNAL_ERROR',message:'Request could not be completed'}})});
  await app.listen({host:'0.0.0.0',port:Number(process.env.API_PORT||4000)});
}
main().catch(err=>{console.error(err);process.exit(1)});
