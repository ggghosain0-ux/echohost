import {ServiceType} from '../types';
import {LocalServiceProvider,LocalVPSProvider,LocalDNSProvider,LocalBackupProvider} from './local';
import {ServiceProvider,VPSProvider,DNSProvider,BackupProvider} from './types';
const generic=new LocalServiceProvider();
export function providerFor(type:ServiceType):ServiceProvider { return type==='VIRTUAL_MACHINE'?new LocalVPSProvider():generic; }
export const vpsProvider:VPSProvider=new LocalVPSProvider();
export const dnsProvider:DNSProvider=new LocalDNSProvider();
export const backupProvider:BackupProvider=new LocalBackupProvider();
