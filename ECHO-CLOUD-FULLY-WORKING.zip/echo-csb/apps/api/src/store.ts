import {promises as fs} from 'node:fs'; import path from 'node:path'; import {Store} from './types';
const dir=path.resolve(process.cwd(),'.echo-data'); const file=path.join(dir,'store.json');
const empty:Store={users:[],services:[],nodes:[],activities:[],notifications:[],domains:[],backups:[]};
let store:Store=structuredClone(empty); let writing=Promise.resolve();
export async function initStore(){await fs.mkdir(dir,{recursive:true});try{store=JSON.parse(await fs.readFile(file,'utf8'));}catch{await saveStore(store);}}
export function db(){return store} export async function saveStore(next=store){store=next;writing=writing.then(()=>fs.writeFile(file,JSON.stringify(store,null,2),'utf8'));await writing}
export async function transaction(fn:(s:Store)=>unknown|Promise<unknown>){await fn(store);await saveStore()}
