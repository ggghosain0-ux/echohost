#!/usr/bin/env python3
"""
SKVM — node.py  (the "node agent")

This is the file the admin copies to a node VPS and runs there. It:
  1. Talks to the local Docker daemon to create/start/stop/delete "VM"
     containers on behalf of the panel.
  2. Bind-mounts the host's lxcfs virtual /proc files into each container
     (scaled to that container's own cgroup limits) so commands like
     `free -m` / `nproc` report the VM's *own* allocation instead of the
     bare-metal host's — this is what "install the lxcfs for accurate
     allocation" means in practice.
  3. Boots a tmate session inside the container and hands back the SSH
     connection string so the panel can display it on the VM's detail page.
  4. Exposes a small authenticated HTTP API (Flask) on <hostname>:<port> —
     exactly the hostname/port the admin entered when creating the Node in
     the panel — so the panel can call back into this agent.

Requirements on the node VPS: Docker Engine, lxcfs (`apt install lxcfs`),
and Python packages in requirements.txt (docker, flask, requests).

Usage:
    python3 node.py --token <API_TOKEN_FROM_PANEL> --panel-url https://panel.example.com --port 8642

The token is the one shown in the panel's "Create Node" dialog — the node
only becomes usable once this script is running with a token that matches
what's stored against that Node record in the panel's database.
"""
import argparse
import os
import subprocess
import threading
import time
import traceback
from datetime import datetime

import requests
from flask import Flask, request, jsonify, abort

try:
    import docker
    from docker.types import Mount
except ImportError:
    docker = None
    Mount = None

app = Flask(__name__)

CONFIG = {
    "token": None,
    "panel_url": None,
    "port": 8642,
    "lxcfs_root": "/var/lib/lxcfs",
}

LXCFS_PROC_FILES = [
    "cpuinfo", "diskstats", "meminfo", "stat", "swaps", "uptime", "loadavg",
]


def docker_client():
    if docker is None:
        raise RuntimeError("The 'docker' python package is not installed (pip install docker).")
    return docker.from_env()


def require_token():
    token = request.headers.get("X-Node-Token", "")
    if not token or token != CONFIG["token"]:
        abort(401)


@app.before_request
def _auth_guard():
    if request.path.startswith("/agent/"):
        require_token()


# --------------------------------------------------------------------- #
# lxcfs bind mounts — accurate resource reporting inside the container
# --------------------------------------------------------------------- #
def lxcfs_mounts():
    mounts = []
    root = CONFIG["lxcfs_root"]
    proc_dir = os.path.join(root, "proc")
    if not os.path.isdir(proc_dir):
        # lxcfs isn't installed/mounted on this host — skip gracefully,
        # the container will still work, just without cgroup-aware /proc.
        return mounts
    for f in LXCFS_PROC_FILES:
        src = os.path.join(proc_dir, f)
        if os.path.exists(src):
            mounts.append(Mount(target=f"/proc/{f}", source=src, type="bind"))
    sys_cpu = os.path.join(root, "sys", "devices", "system", "cpu", "online")
    if os.path.exists(sys_cpu):
        mounts.append(Mount(target="/sys/devices/system/cpu/online", source=sys_cpu, type="bind"))
    return mounts


# --------------------------------------------------------------------- #
# tmate — SSH access key for the VM
# --------------------------------------------------------------------- #
def bootstrap_tmate(client, container):
    """
    Starts a detached tmate session inside the container (installing it
    first if the image doesn't already bundle it) and returns the ssh /
    web connection strings.
    """
    def ex(cmd):
        return client.api.exec_start(client.api.exec_create(container.id, cmd)["Id"])

    ex(["sh", "-c", "command -v tmate >/dev/null 2>&1 || "
        "(apt-get update -qq && apt-get install -y -qq tmate openssh-client) "
        "|| (apk add --no-cache tmate 2>/dev/null) || true"])

    ex(["sh", "-c", "tmate -S /tmp/tmate.sock new-session -d || true"])

    ssh_line, web_line = "", ""
    for _ in range(20):
        time.sleep(1)
        out = ex(["sh", "-c", "tmate -S /tmp/tmate.sock wait tmate-ready 2>/dev/null; "
                  "tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}' 2>/dev/null"])
        text = out.decode(errors="ignore").strip() if isinstance(out, (bytes, bytearray)) else str(out).strip()
        if text.startswith("ssh "):
            ssh_line = text
            web_out = ex(["sh", "-c", "tmate -S /tmp/tmate.sock display -p '#{tmate_web}' 2>/dev/null"])
            web_line = web_out.decode(errors="ignore").strip() if isinstance(web_out, (bytes, bytearray)) else str(web_out).strip()
            break
    return ssh_line, web_line


# --------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------- #
@app.route("/agent/ping")
def ping():
    version = ""
    try:
        version = docker_client().version().get("Version", "")
    except Exception:
        pass
    return jsonify({"ok": True, "docker_version": version})


@app.route("/agent/stats")
def stats():
    client = docker_client()
    containers_out = []
    try:
        for c in client.containers.list(all=True):
            if not c.name.startswith("skvm-vm"):
                continue
            vm_id = None
            try:
                vm_id = int(c.name.replace("skvm-vm", ""))
            except ValueError:
                pass
            cpu_pct, mem_mb = 0, 0
            try:
                s = c.stats(stream=False)
                cpu_delta = s["cpu_stats"]["cpu_usage"]["total_usage"] - s["precpu_stats"]["cpu_usage"]["total_usage"]
                sys_delta = s["cpu_stats"]["system_cpu_usage"] - s["precpu_stats"]["system_cpu_usage"]
                ncpu = s["cpu_stats"].get("online_cpus") or 1
                if sys_delta > 0:
                    cpu_pct = round((cpu_delta / sys_delta) * ncpu * 100, 1)
                mem_mb = round(s["memory_stats"].get("usage", 0) / (1024 * 1024), 1)
            except Exception:
                pass
            containers_out.append({
                "vm_id": vm_id, "container": c.name, "status": c.status,
                "cpu_pct": cpu_pct, "mem_used_mb": mem_mb,
            })
    except Exception:
        pass

    host_cpu_pct, host_mem_pct = 0, 0
    try:
        load1 = os.getloadavg()[0]
        host_cpu_pct = round(min(load1 * 100 / max(os.cpu_count() or 1, 1), 100), 1)
    except Exception:
        pass
    try:
        with open("/proc/meminfo") as f:
            meminfo = {}
            for line in f:
                k, v = line.split(":")
                meminfo[k.strip()] = int(v.strip().split()[0])
        total = meminfo.get("MemTotal", 1)
        avail = meminfo.get("MemAvailable", total)
        host_mem_pct = round((1 - avail / total) * 100, 1)
    except Exception:
        pass

    return jsonify({
        "docker_version": docker_client().version().get("Version", ""),
        "host_cpu_pct": host_cpu_pct,
        "host_mem_pct": host_mem_pct,
        "containers": containers_out,
    })


@app.route("/agent/vms", methods=["POST"])
def create_vm():
    body = request.get_json(force=True)
    name = body["name"]
    image = body["image"]
    ram_mb = int(body.get("ram_mb", 1024))
    disk_gb = int(body.get("disk_gb", 10))
    cpu_cores = float(body.get("cpu_cores", 1))
    vm_id = body.get("vm_id")

    client = docker_client()

    # idempotent: remove any previous container with this name (covers reinstall)
    try:
        old = client.containers.get(name)
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    try:
        client.images.pull(image)
    except Exception:
        pass  # image may already be present locally / pull may be restricted; continue

    run_kwargs = dict(
        name=name,
        detach=True,
        tty=True,
        stdin_open=True,
        hostname=name,
        mem_limit=f"{ram_mb}m",
        memswap_limit=f"{ram_mb}m",
        nano_cpus=int(cpu_cores * 1_000_000_000),
        cap_add=["SYS_ADMIN", "NET_ADMIN"],
        devices=["/dev/fuse"],
        security_opt=["apparmor:unconfined"],
        restart_policy={"Name": "unless-stopped"},
        mounts=lxcfs_mounts(),
        environment={"SKVM_VM_ID": str(vm_id), "SKVM_RAM_MB": str(ram_mb), "SKVM_CPU_CORES": str(cpu_cores)},
    )
    try:
        run_kwargs["storage_opt"] = {"size": f"{disk_gb}G"}
        container = client.containers.run(image, **run_kwargs)
    except Exception:
        run_kwargs.pop("storage_opt", None)
        container = client.containers.run(image, **run_kwargs)

    ssh_line, web_line = "", ""
    try:
        ssh_line, web_line = bootstrap_tmate(client, container)
    except Exception:
        traceback.print_exc()

    return jsonify({
        "container_id": container.id,
        "tmate_ssh": ssh_line,
        "tmate_web": web_line,
    })


def _get_container(name):
    client = docker_client()
    try:
        return client, client.containers.get(name)
    except docker.errors.NotFound:
        abort(404)


@app.route("/agent/vms/<name>/start", methods=["POST"])
def start_vm(name):
    _, c = _get_container(name)
    c.start()
    return jsonify({"ok": True, "status": "running"})


@app.route("/agent/vms/<name>/stop", methods=["POST"])
def stop_vm(name):
    _, c = _get_container(name)
    c.stop(timeout=10)
    return jsonify({"ok": True, "status": "stopped"})


@app.route("/agent/vms/<name>/restart", methods=["POST"])
def restart_vm(name):
    _, c = _get_container(name)
    c.restart(timeout=10)
    return jsonify({"ok": True, "status": "running"})


@app.route("/agent/vms/<name>", methods=["DELETE"])
def delete_vm(name):
    client = docker_client()
    try:
        c = client.containers.get(name)
        c.remove(force=True)
    except docker.errors.NotFound:
        pass
    return jsonify({"ok": True})


# --------------------------------------------------------------------- #
# Heartbeat thread: tells the panel this node is alive even if the
# panel's own poller can't reach us directly (e.g. NAT/firewall).
# --------------------------------------------------------------------- #
def heartbeat_loop():
    while True:
        try:
            version = docker_client().version().get("Version", "")
            requests.post(
                f"{CONFIG['panel_url'].rstrip('/')}/api/agent/heartbeat",
                headers={"X-Node-Token": CONFIG["token"]},
                json={"docker_version": version},
                timeout=6,
            )
        except Exception as exc:
            print(f"[node.py] heartbeat failed: {exc}")
        time.sleep(30)


def main():
    parser = argparse.ArgumentParser(description="SKVM node agent")
    parser.add_argument("--token", required=True, help="API token shown in the panel's Create Node dialog")
    parser.add_argument("--panel-url", required=True, help="e.g. https://panel.example.com")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8642, help="Must match the port configured for this Node in the panel")
    parser.add_argument("--lxcfs-root", default="/var/lib/lxcfs")
    args = parser.parse_args()

    CONFIG["token"] = args.token
    CONFIG["panel_url"] = args.panel_url
    CONFIG["port"] = args.port
    CONFIG["lxcfs_root"] = args.lxcfs_root

    if docker is None:
        print("ERROR: the 'docker' python package is required: pip install -r requirements.txt")
        raise SystemExit(1)

    threading.Thread(target=heartbeat_loop, daemon=True).start()
    print(f"SKVM node agent listening on {args.host}:{args.port}")
    app.run(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
