# SKVM — Docker-based VPS Panel

A self-hosted panel for creating and managing lightweight "VPS" instances
that are actually Docker containers under the hood, with per-container
resource accounting via **lxcfs** and instant SSH access via **tmate**.

## How it fits together

```
┌─────────────────────┐        HTTP (X-Node-Token auth)        ┌─────────────────────┐
│   Panel  (api.py)    │ ─────────────────────────────────────▶│  Node agent (node.py)│
│  Flask + SQLite       │        POST /agent/vms                │   runs on each        │
│  admin + user panels  │        POST /agent/vms/<n>/start...   │   node VPS, drives     │
│  live_stats_manager   │◀───────────────────────────────────── │   the Docker daemon    │
│  polls GET /agent/stats                                        └─────────────────────┘
└─────────────────────┘
```

- **api.py** — the Flask app: auth, the user panel, the admin panel, and
  the small JSON surface the node agent is driven through.
- **models.py** — SQLAlchemy models (`User`, `Node`, `OSImage`, `VM`,
  `Setting`, `NodeTask`, `Notification`).
- **live_stats_manager.py** — background thread that polls every node's
  `/agent/stats` endpoint every few seconds and caches the results for the
  dashboard and the `/api/live-stats/stream` SSE feed.
- **node.py** — the agent you copy onto *each node VPS*. It talks to the
  local Docker daemon to create/start/stop/delete VM containers, bind-mounts
  the host's lxcfs `/proc` views into each container (so `free -m` / `nproc`
  inside the VM report *its own* limits, not the host's), boots a `tmate`
  session inside the freshly created container, and hands the SSH connection
  string back to the panel.
- **skvm.py** — management CLI (`init-db`, `create-admin`, `run`).
- **install.sh** — one-shot installer; also installs just the node agent
  with `install.sh --node`.

## Quick start (panel)

```bash
sudo bash install.sh
```

This installs Docker, lxcfs, Python, Node.js/PM2, creates a virtualenv,
installs `requirements.txt`, initialises the SQLite database, optionally
walks you through creating the first admin account, and starts the panel
under PM2 on port 5000.

Manual equivalent:
```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python3 skvm.py init-db
python3 skvm.py create-admin --username admin --email you@example.com
python3 skvm.py run --debug          # dev server
# or, in production:
gunicorn -w 4 -b 0.0.0.0:5000 api:app
# or via PM2:
pm2 start ecosystem.config.js --only skvm-panel
```

## Adding a node

1. In the panel: **Admin → Nodes → Add node**. Fill in its name, location,
   RAM/disk/vCPU *budget*, VM capacity, and the hostname/port the panel
   should reach its agent on.
2. Copy the API token shown on the node's page.
3. On that node VPS:
   ```bash
   bash install.sh --node
   ./venv/bin/python3 node.py --token <TOKEN> --panel-url https://your-panel --port 8642
   ```
   (or edit `ecosystem.config.js`'s `skvm-node` entry and `pm2 start
   ecosystem.config.js --only skvm-node` to keep it running permanently).
4. The node shows **online** in the panel within a few seconds.

## Creating a VM

Admin → Create VM → name → RAM/disk/vCPU + node → operating system → user
→ Create. The panel then, in the background: tells the node agent to pull
the image, creates the container with the requested cgroup limits and the
lxcfs bind-mounts, boots tmate inside it, and stores the SSH key — the
VM's page auto-refreshes from "installing" to "running" once that's done.

## Notes on this build

- Default OS images point at `skvm/ubuntu:22.04`, `skvm/ubuntu:20.04`,
  `skvm/debian:11`, `skvm/debian:12` — build/push these yourself (or point
  the OS image's Docker tag at any image reachable from your nodes) before
  creating VMs; ordinary base images work but bundling `tmate` and an SSH
  server into the image makes provisioning faster.
- VM creation runs in a background thread inside `api.py` for simplicity.
  For heavier load, swap that for a real task queue (Celery/RQ) — the
  `NodeTask` model is already there to support that migration.
- Forms in this build don't carry CSRF tokens and passwords aren't rate
  limited — add `Flask-WTF`/`Flask-Limiter` before exposing this beyond a
  trusted network.
