"""
SKVM — database models
"""
import secrets
import string
from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


def gen_token(length=48):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


class Setting(db.Model):
    """Simple key/value store for admin-configurable panel settings."""
    __tablename__ = "settings"
    key = db.Column(db.String(64), primary_key=True)
    value = db.Column(db.Text, nullable=True)

    DEFAULTS = {
        "panel_name": "SKVM",
        "logo_url": "/static/img/logo.png",
        "theme": "dark",
        "discord_link": "",
        "website_link": "",
        "maintenance_mode": "0",
    }

    @classmethod
    def get(cls, key, default=None):
        row = cls.query.get(key)
        if row is not None and row.value is not None:
            return row.value
        return cls.DEFAULTS.get(key, default)

    @classmethod
    def set(cls, key, value):
        row = cls.query.get(key)
        if row is None:
            row = cls(key=key, value=value)
            db.session.add(row)
        else:
            row.value = value
        db.session.commit()

    @classmethod
    def all_settings(cls):
        out = dict(cls.DEFAULTS)
        for row in cls.query.all():
            if row.value is not None:
                out[row.key] = row.value
        return out


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_suspended = db.Column(db.Boolean, default=False)
    otp_secret = db.Column(db.String(32), nullable=True)
    is_2fa_enabled = db.Column(db.Boolean, default=False)
    avatar_url = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reset_token = db.Column(db.String(64), nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)

    vms = db.relationship("VM", backref="owner", lazy=True, foreign_keys="VM.user_id")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def vm_count(self):
        return len(self.vms)


class Node(db.Model):
    __tablename__ = "nodes"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    location = db.Column(db.String(120), nullable=False)
    ram_mb = db.Column(db.Integer, nullable=False)          # total ram allocation budget (MB)
    disk_gb = db.Column(db.Integer, nullable=False)          # total disk allocation budget (GB)
    cpu_cores = db.Column(db.Integer, nullable=False)         # total vCPU budget
    vm_capacity = db.Column(db.Integer, nullable=False)       # max number of VMs
    hostname = db.Column(db.String(255), nullable=False)      # FQDN or IP
    port = db.Column(db.Integer, nullable=False, default=8642)
    api_token = db.Column(db.String(64), unique=True, nullable=False, default=gen_token)
    status = db.Column(db.String(20), default="offline")      # offline / online
    last_seen = db.Column(db.DateTime, nullable=True)
    docker_version = db.Column(db.String(40), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    vms = db.relationship("VM", backref="node", lazy=True)

    def used_ram(self):
        return sum(v.ram_mb for v in self.vms if v.status != "deleted")

    def used_disk(self):
        return sum(v.disk_gb for v in self.vms if v.status != "deleted")

    def used_cpu(self):
        return sum(v.cpu_cores for v in self.vms if v.status != "deleted")

    def used_slots(self):
        return len([v for v in self.vms if v.status != "deleted"])

    def is_online(self):
        if not self.last_seen:
            return False
        return (datetime.utcnow() - self.last_seen).total_seconds() < 90


class OSImage(db.Model):
    __tablename__ = "os_images"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)          # e.g. "Ubuntu"
    version = db.Column(db.String(40), nullable=False)        # e.g. "22.04"
    docker_image = db.Column(db.String(160), nullable=False)  # e.g. "skvm/ubuntu:22.04"
    icon = db.Column(db.String(255), default="")
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def label(self):
        return f"{self.name} {self.version}"


class VM(db.Model):
    __tablename__ = "vms"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    os_id = db.Column(db.Integer, db.ForeignKey("os_images.id"), nullable=False)

    ram_mb = db.Column(db.Integer, nullable=False)
    disk_gb = db.Column(db.Integer, nullable=False)
    cpu_cores = db.Column(db.Integer, nullable=False)

    container_id = db.Column(db.String(80), nullable=True)
    container_name = db.Column(db.String(120), nullable=True)

    ssh_tmate_key = db.Column(db.Text, nullable=True)
    ssh_tmate_web = db.Column(db.Text, nullable=True)

    # status: queued / installing / running / stopped / suspended / reinstalling / migrating / error / deleted
    status = db.Column(db.String(20), default="queued")
    install_log = db.Column(db.Text, default="")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)

    os_image = db.relationship("OSImage")

    def usage_pct(self, node_field, vm_field):
        node_total = getattr(self.node, node_field)
        if not node_total:
            return 0
        return round((getattr(self, vm_field) / node_total) * 100)


class NodeTask(db.Model):
    """
    Work queue consumed by node.py (the lightweight agent that runs on each
    node VPS). The panel enqueues a task, node.py polls for pending tasks
    addressed to it, executes them with the Docker SDK, then reports back.
    """
    __tablename__ = "node_tasks"
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=True)
    # action: create_vm / delete_vm / start_vm / stop_vm / restart_vm / reinstall_vm / suspend_vm / unsuspend_vm
    action = db.Column(db.String(30), nullable=False)
    payload = db.Column(db.Text, default="{}")
    # status: pending / running / done / failed
    status = db.Column(db.String(20), default="pending")
    result = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(160), nullable=False)
    body = db.Column(db.String(500), default="")
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
