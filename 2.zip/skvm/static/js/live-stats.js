/**
 * SKVM — live-stats.js
 *
 * Connects to /api/live-stats/stream (Server-Sent Events, fed by
 * live_stats_manager.py) and pushes live numbers into any element on the
 * page carrying the right data attributes:
 *
 *   data-live-vm="<id>" data-live-field="cpu_pct|mem_used_mb|status"
 *   data-live-node="<id>" data-live-field="status|host_cpu_pct|host_mem_pct"
 *
 * Also drives any element with class ".meter > span" whose parent has
 * data-live-vm + data-live-meter="cpu|mem" to animate its width.
 */
(function () {
  "use strict";

  function setText(el, value) {
    if (el.textContent !== String(value)) el.textContent = value;
  }

  function applyVm(vmId, data) {
    document
      .querySelectorAll(`[data-live-vm="${vmId}"]`)
      .forEach((el) => {
        const field = el.getAttribute("data-live-field");
        const meter = el.getAttribute("data-live-meter");
        if (field && data[field] !== undefined) {
          if (field === "cpu_pct") setText(el, `${data.cpu_pct ?? 0}%`);
          else if (field === "mem_used_mb") setText(el, `${data.mem_used_mb ?? 0} MB`);
          else setText(el, data[field]);
        }
        if (meter) {
          const bar = el.querySelector("span");
          if (bar) {
            const pct = meter === "cpu" ? (data.cpu_pct ?? 0) : Math.min((data.mem_used_mb ?? 0) / 10, 100);
            bar.style.width = `${Math.max(0, Math.min(100, pct))}%`;
          }
        }
      });
  }

  function applyNode(nodeId, data) {
    document
      .querySelectorAll(`[data-live-node="${nodeId}"]`)
      .forEach((el) => {
        const field = el.getAttribute("data-live-field");
        if (!field) return;
        if (field === "status") {
          el.textContent = data.status || "offline";
          el.classList.remove("badge-ok", "badge-err");
          el.classList.add(data.status === "online" ? "badge-ok" : "badge-err");
        } else if (data[field] !== undefined) {
          setText(el, `${data[field]}%`);
        }
      });
  }

  function connect() {
    if (!window.EventSource) return;
    const src = new EventSource("/api/live-stats/stream");
    src.onmessage = (evt) => {
      try {
        const payload = JSON.parse(evt.data);
        Object.entries(payload.vms || {}).forEach(([vmId, data]) => applyVm(vmId, data));
        Object.entries(payload.nodes || {}).forEach(([nodeId, data]) => applyNode(nodeId, data));
      } catch (e) {
        /* ignore malformed frame */
      }
    };
    src.onerror = () => {
      src.close();
      setTimeout(connect, 5000);
    };
  }

  document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector("[data-live-vm], [data-live-node]")) connect();
  });
})();
