(function () {
  "use strict";

  // mobile sidebar toggle
  const toggle = document.getElementById("sidebar-toggle");
  const sidebar = document.querySelector(".sidebar");
  if (toggle && sidebar) {
    toggle.addEventListener("click", () => sidebar.classList.toggle("open"));
  }

  // auto-dismiss flash messages
  document.querySelectorAll(".flash").forEach((el) => {
    setTimeout(() => {
      el.style.transition = "opacity .4s ease";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 450);
    }, 5000);
  });

  // confirm before any destructive action
  document.querySelectorAll("[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (e) => {
      if (!window.confirm(form.getAttribute("data-confirm"))) e.preventDefault();
    });
  });

  // copy-to-clipboard buttons
  document.querySelectorAll("[data-copy]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = document.querySelector(btn.getAttribute("data-copy"));
      if (!target) return;
      navigator.clipboard.writeText(target.innerText || target.value || "").then(() => {
        const original = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(() => (btn.textContent = original), 1500);
      });
    });
  });

  // --- VM create wizard (4 client-side steps, one POST at the end) ---
  const wizard = document.getElementById("vm-wizard");
  if (wizard) {
    const steps = Array.from(wizard.querySelectorAll(".wizard-step"));
    const stepPills = Array.from(document.querySelectorAll(".step"));
    let current = 0;

    function render() {
      steps.forEach((s, i) => (s.style.display = i === current ? "block" : "none"));
      stepPills.forEach((p, i) => {
        p.classList.toggle("active", i === current);
        p.classList.toggle("done", i < current);
      });
      wizard.querySelector('[data-action="back"]').style.visibility = current === 0 ? "hidden" : "visible";
      const nextBtn = wizard.querySelector('[data-action="next"]');
      const submitBtn = wizard.querySelector('[data-action="submit"]');
      const isLast = current === steps.length - 1;
      nextBtn.style.display = isLast ? "none" : "inline-flex";
      submitBtn.style.display = isLast ? "inline-flex" : "none";
    }

    wizard.querySelector('[data-action="next"]').addEventListener("click", () => {
      const inputs = steps[current].querySelectorAll("input[required], select[required]");
      for (const inp of inputs) {
        if (!inp.value) {
          inp.reportValidity();
          return;
        }
      }
      current = Math.min(current + 1, steps.length - 1);
      render();
    });
    wizard.querySelector('[data-action="back"]').addEventListener("click", () => {
      current = Math.max(current - 1, 0);
      render();
    });
    render();
  }

  // --- installing screen: poll status until running ---
  const installEl = document.getElementById("install-status");
  if (installEl) {
    const url = installEl.getAttribute("data-status-url");
    const redirectUrl = installEl.getAttribute("data-redirect-url");
    const logEl = document.getElementById("install-log");
    async function poll() {
      try {
        const res = await fetch(url);
        const data = await res.json();
        if (logEl) logEl.textContent = data.log || "";
        if (logEl) logEl.scrollTop = logEl.scrollHeight;
        if (data.status === "running") {
          window.location.href = redirectUrl;
          return;
        }
        if (data.status === "error") {
          installEl.querySelector(".status-label").textContent = "Installation failed";
          return;
        }
      } catch (e) {
        /* keep trying */
      }
      setTimeout(poll, 2500);
    }
    poll();
  }
})();
