#!/usr/bin/env bash
#
# SKVM — install.sh
# Installs the SKVM panel (api.py) — works on a real Ubuntu/Debian VPS
# (full production setup: Docker, lxcfs, PM2, systemd) and also degrades
# gracefully on sandboxes like CodeSandbox / GitHub Codespaces / plain
# containers where you don't have root, apt, or systemd — in that case it
# just sets up the Python env and runs the panel directly so you can still
# click through the UI.
#
#   sudo bash install.sh                 # full VPS install (panel)
#   sudo bash install.sh --node          # node-agent-only install
#   bash install.sh                      # best-effort install, no root needed
#
# Safe to re-run: every step checks whether it's already done first.

set -uo pipefail

# ------------------------------------------------------------------ #
# 0. helpers
# ------------------------------------------------------------------ #
C_RESET="\033[0m"; C_GREEN="\033[32m"; C_RED="\033[31m"; C_CYAN="\033[36m"; C_YEL="\033[33m"
log()  { echo -e "${C_CYAN}==>${C_RESET} $*"; }
ok()   { echo -e "${C_GREEN}  ok${C_RESET} $*"; }
warn() { echo -e "${C_YEL}  !${C_RESET} $*"; }
die()  { echo -e "${C_RED}ERROR:${C_RESET} $*" >&2; exit 1; }

IS_ROOT=false; [ "$(id -u)" -eq 0 ] && IS_ROOT=true
HAS_APT=false; command -v apt-get >/dev/null 2>&1 && HAS_APT=true
HAS_SYSTEMD=false; [ -d /run/systemd/system ] && HAS_SYSTEMD=true

INSTALL_DIR="${SKVM_INSTALL_DIR:-$(pwd)}"
PANEL_PORT="${SKVM_PORT:-5000}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="panel"        # panel | node
NON_INTERACTIVE=false
[ -t 0 ] || NON_INTERACTIVE=true

for arg in "$@"; do
  case "$arg" in
    --node) MODE="node" ;;
    --dir=*) INSTALL_DIR="${arg#*=}" ;;
    --port=*) PANEL_PORT="${arg#*=}" ;;
    --yes|-y) NON_INTERACTIVE=true ;;
    -h|--help)
      echo "Usage: install.sh [--node] [--dir=/opt/skvm] [--port=5000] [--yes]"
      echo "  (no flags)  Install the panel (web UI + database)"
      echo "  --node      Install only the node agent (node.py) on a node VPS"
      echo "  --dir=PATH  Where to install (default: current directory when not root, /opt/skvm when root)"
      echo "  --port=N    Port the panel listens on (default 5000)"
      exit 0
      ;;
  esac
done
if [ "$INSTALL_DIR" = "$(pwd)" ] && [ "$IS_ROOT" = true ] && [ "$SCRIPT_DIR" != "$(pwd)" ]; then
  INSTALL_DIR="/opt/skvm"
fi

echo -e "${C_CYAN}SKVM installer${C_RESET} -- mode: ${MODE}, target: ${INSTALL_DIR}"
$IS_ROOT   || warn "Not running as root -- will skip system package/Docker/systemd steps and just set up + run the panel with Python. Re-run with sudo on a real VPS for the full production setup."
$HAS_APT   || warn "apt-get not found -- assuming this isn't Debian/Ubuntu. Skipping OS package installation (Docker/lxcfs/Node.js must already be present, or the panel will run in UI-only/demo mode)."
$HAS_SYSTEMD || warn "No systemd detected (common in CodeSandbox/containers) -- will run the panel with plain nohup instead of a system service."
echo

# ------------------------------------------------------------------ #
# 1. system packages (best-effort -- only if root + apt)
# ------------------------------------------------------------------ #
if $IS_ROOT && $HAS_APT; then
  export DEBIAN_FRONTEND=noninteractive
  log "Updating package index..."
  if apt-get update -qq; then
    log "Installing base packages (python3, venv, pip, git, curl, lxcfs)..."
    if apt-get install -y -qq python3 python3-venv python3-pip git curl ca-certificates gnupg lsb-release lxcfs fuse3; then
      ok "Base packages installed."
    else
      warn "Some base packages failed to install -- continuing anyway."
    fi
  else
    warn "apt-get update failed (no network / restricted sandbox?) -- skipping system package installation."
  fi
else
  warn "Skipping apt package installation (need root + apt-get)."
fi

# ------------------------------------------------------------------ #
# 2. Docker (best-effort -- panel works without it; node agent needs it)
# ------------------------------------------------------------------ #
if command -v docker >/dev/null 2>&1; then
  ok "Docker already installed, skipping."
elif $IS_ROOT && $HAS_APT; then
  log "Installing Docker Engine..."
  install -m 0755 -d /etc/apt/keyrings
  if [ -f /etc/os-release ]; then . /etc/os-release; fi
  if curl -fsSL "https://download.docker.com/linux/${ID:-ubuntu}/gpg" 2>/dev/null | gpg --dearmor -o /etc/apt/keyrings/docker.gpg 2>/dev/null; then
    chmod a+r /etc/apt/keyrings/docker.gpg
    ARCH="$(dpkg --print-architecture)"
    echo "deb [arch=${ARCH} signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${ID:-ubuntu} ${VERSION_CODENAME:-jammy} stable" \
      > /etc/apt/sources.list.d/docker.list
    if apt-get update -qq && apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin; then
      $HAS_SYSTEMD && systemctl enable --now docker >/dev/null 2>&1
      ok "Docker installed."
    else
      warn "Docker package installation failed -- the panel will still run, but you won't be able to run a node agent here."
    fi
  else
    warn "Could not reach download.docker.com (no network?) -- skipping Docker install."
  fi
else
  warn "Skipping Docker installation (not root, or apt unavailable, or sandboxed environment with no Docker-in-Docker support)."
fi

if $HAS_SYSTEMD && $IS_ROOT; then
  systemctl enable --now lxcfs >/dev/null 2>&1 || true
fi
if [ -d /var/lib/lxcfs/proc ]; then
  ok "lxcfs is mounted at /var/lib/lxcfs."
else
  warn "/var/lib/lxcfs/proc not present -- fine for the panel itself; only matters on a node VPS actually running containers."
fi

# ------------------------------------------------------------------ #
# 3. Node.js + PM2 (panel mode only, best-effort)
# ------------------------------------------------------------------ #
USE_PM2=false
if [ "$MODE" = "panel" ]; then
  if command -v pm2 >/dev/null 2>&1; then
    USE_PM2=true; ok "PM2 already installed."
  elif $IS_ROOT && $HAS_APT; then
    if ! command -v node >/dev/null 2>&1; then
      log "Installing Node.js (for PM2)..."
      if curl -fsSL https://deb.nodesource.com/setup_20.x 2>/dev/null | bash - >/dev/null 2>&1 && apt-get install -y -qq nodejs; then
        ok "Node.js installed."
      else
        warn "Node.js installation failed -- will run the panel without PM2."
      fi
    fi
    if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then
      log "Installing PM2..."
      if npm install -g pm2 --silent >/dev/null 2>&1; then
        USE_PM2=true; ok "PM2 installed."
      else
        warn "PM2 installation failed -- will run the panel with nohup instead."
      fi
    fi
  else
    warn "Skipping Node.js/PM2 (not root, or apt unavailable) -- will run the panel with nohup instead."
  fi
fi

# ------------------------------------------------------------------ #
# 4. copy application files
# ------------------------------------------------------------------ #
log "Placing application files in ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}" || die "Could not create ${INSTALL_DIR} -- check permissions or pass --dir=<writable path>."
if [ "${SCRIPT_DIR}" != "${INSTALL_DIR}" ]; then
  cp -r "${SCRIPT_DIR}/." "${INSTALL_DIR}/" || die "Could not copy files into ${INSTALL_DIR}."
fi
mkdir -p "${INSTALL_DIR}/instance" "${INSTALL_DIR}/logs" "${INSTALL_DIR}/static/uploads"
ok "Files in place."
cd "${INSTALL_DIR}" || die "Could not cd into ${INSTALL_DIR}."

# ------------------------------------------------------------------ #
# 5. Python virtualenv + dependencies (required -- this must succeed)
# ------------------------------------------------------------------ #
PYBIN="$(command -v python3 || true)"
[ -n "$PYBIN" ] || die "python3 was not found. Install Python 3.9+ and re-run this script."

if [ ! -d venv ]; then
  log "Creating Python virtual environment..."
  "$PYBIN" -m venv venv 2>/tmp/skvm_venv_err.log || {
    warn "python3-venv seems unavailable, trying to install it..."
    if $IS_ROOT && $HAS_APT; then apt-get install -y -qq python3-venv >/dev/null 2>&1; fi
    "$PYBIN" -m venv venv || die "Could not create a virtualenv. Install python3-venv manually and re-run."
  }
fi
log "Installing Python dependencies (this can take a minute)..."
./venv/bin/pip install --upgrade pip -q || warn "pip upgrade failed, continuing with existing pip."
./venv/bin/pip install -r requirements.txt -q || die "Failed installing requirements.txt -- check your network connection and re-run."
ok "Python dependencies installed."

# ------------------------------------------------------------------ #
# 6. node-agent-only path stops here
# ------------------------------------------------------------------ #
if [ "$MODE" = "node" ]; then
  echo
  ok "Node agent files are ready at ${INSTALL_DIR}."
  command -v docker >/dev/null 2>&1 || warn "Docker isn't installed here -- node.py needs a working Docker daemon to create containers."
  echo -e "${C_CYAN}Next step:${C_RESET} run it with the token from the panel's 'Create Node' screen:"
  echo
  echo "  cd ${INSTALL_DIR} && ./venv/bin/python3 node.py --token <API_TOKEN> --panel-url https://your-panel-domain --port 8642"
  echo
  echo "To keep it running permanently: edit ecosystem.config.js's 'skvm-node' app with your token/URL, then"
  echo "  pm2 start ecosystem.config.js --only skvm-node && pm2 save   (if PM2 is available)"
  exit 0
fi

# ------------------------------------------------------------------ #
# 7. environment / secret key
# ------------------------------------------------------------------ #
if [ ! -f .env ]; then
  log "Generating .env with a random secret key..."
  SECRET_KEY="$(./venv/bin/python3 -c 'import secrets; print(secrets.token_hex(32))')"
  cat > .env <<EOF_ENV
SKVM_SECRET_KEY=${SECRET_KEY}
SKVM_DATABASE_URL=sqlite:///${INSTALL_DIR}/instance/skvm.db
EOF_ENV
  ok ".env created."
else
  ok ".env already exists, leaving it alone."
fi
set -a; source .env; set +a

# ------------------------------------------------------------------ #
# 8. database
# ------------------------------------------------------------------ #
log "Initialising the database..."
./venv/bin/python3 skvm.py init-db || die "Database initialisation failed."
ok "Database ready."

# ------------------------------------------------------------------ #
# 9. first admin account
# ------------------------------------------------------------------ #
if ! $NON_INTERACTIVE; then
  echo
  read -rp "Create your first admin account now? [Y/n] " CREATE_ADMIN
  CREATE_ADMIN="${CREATE_ADMIN:-Y}"
  if [[ "$CREATE_ADMIN" =~ ^[Yy] ]]; then
    read -rp "  Admin username: " ADMIN_USER
    read -rp "  Admin email: " ADMIN_EMAIL
    read -rsp "  Admin password: " ADMIN_PASS; echo
    if [ -n "$ADMIN_USER" ] && [ -n "$ADMIN_EMAIL" ] && [ -n "$ADMIN_PASS" ]; then
      ./venv/bin/python3 skvm.py create-admin --username "$ADMIN_USER" --email "$ADMIN_EMAIL" --password "$ADMIN_PASS" \
        && ok "Admin account '${ADMIN_USER}' created." \
        || warn "Could not create the admin account -- you can retry later with skvm.py create-admin."
    else
      warn "Skipped -- one or more fields were empty. Registering the very first account through the web UI also becomes an admin automatically."
    fi
  fi
else
  echo "  (non-interactive -- skipping admin prompt; the very first account created via /register is made an admin automatically, or run: ./venv/bin/python3 skvm.py create-admin --username ... --email ... --password ...)"
fi

# ------------------------------------------------------------------ #
# 10. start the panel -- PM2 > systemd-free nohup, whichever is available
# ------------------------------------------------------------------ #
if $USE_PM2; then
  log "Starting the panel with PM2..."
  sed -i.bak "s/0.0.0.0:5000/0.0.0.0:${PANEL_PORT}/" ecosystem.config.js && rm -f ecosystem.config.js.bak
  pm2 delete skvm-panel >/dev/null 2>&1 || true
  if pm2 start ecosystem.config.js --only skvm-panel; then
    pm2 save >/dev/null 2>&1 || true
    $HAS_SYSTEMD && $IS_ROOT && pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true
    ok "Panel started under PM2."
  else
    warn "PM2 failed to start the panel -- falling back to nohup."
    USE_PM2=false
  fi
fi

if ! $USE_PM2; then
  log "Starting the panel directly (nohup + gunicorn if available, else the dev server)..."
  pkill -f "skvm.py run" >/dev/null 2>&1 || true
  if ./venv/bin/python3 -c "import gunicorn" >/dev/null 2>&1; then
    nohup ./venv/bin/gunicorn -w 2 -b "0.0.0.0:${PANEL_PORT}" api:app > logs/panel.out.log 2>&1 &
  else
    nohup ./venv/bin/python3 skvm.py run --host 0.0.0.0 --port "${PANEL_PORT}" > logs/panel.out.log 2>&1 &
  fi
  disown || true
  sleep 1
  ok "Panel started in the background (logs: ${INSTALL_DIR}/logs/panel.out.log)."
fi

IP_ADDR="$(curl -fsSL -4 --max-time 3 ifconfig.me 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')"
[ -z "$IP_ADDR" ] && IP_ADDR="localhost"

echo
echo -e "${C_GREEN}SKVM is installed.${C_RESET}"
echo "  Panel:      http://${IP_ADDR}:${PANEL_PORT}   (CodeSandbox/Codespaces: use the forwarded-port preview URL instead)"
echo "  Files:      ${INSTALL_DIR}"
if $USE_PM2; then
  echo "  Logs:       pm2 logs skvm-panel"
  echo "  Restart:    pm2 restart skvm-panel"
else
  echo "  Logs:       ${INSTALL_DIR}/logs/panel.out.log"
  echo "  Restart:    pkill -f 'api:app|skvm.py run'; then re-run this script (or the nohup command above)"
fi
echo
echo "To add a node server, go to Admin -> Nodes -> Add node in the panel, then on that"
echo "node VPS (needs real Docker -- won't work in most browser sandboxes) run:  bash install.sh --node"
