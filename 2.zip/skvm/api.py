"""
SKVM — api.py
Main Flask application. Serves the user panel, the admin panel, and the
small JSON API that node.py (running on each node VPS) is driven by.

Run in production via gunicorn / pm2, see ecosystem.config.js:
    gunicorn -w 4 -b 0.0.0.0:5000 api:app
For local/dev use:
    python3 skvm.py run
"""
import json
import os
import secrets
import threading
import traceback
from datetime import datetime, timedelta
from functools import wraps

import requests
from flask import (
    Flask, render_template, redirect, url_for, request, flash,
    session, jsonify, abort, Response
)
from flask_login import (
    LoginManager, login_user, logout_user, login_required, current_user
)
from werkzeug.utils import secure_filename

from models import db, User, Node, OSImage, VM, Setting, NodeTask, Notification
from live_stats_manager import live_stats

try:
    import pyotp
except ImportError:  # 2FA becomes a no-op if pyotp isn't installed yet
    pyotp = None

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --------------------------------------------------------------------- #
# App setup
# --------------------------------------------------------------------- #
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SKVM_SECRET_KEY", secrets.token_hex(32))
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "SKVM_DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'skvm.db')}"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64MB (OS image uploads)

os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message = "Please sign in to continue."
login_manager.init_app(app)

live_stats.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# --------------------------------------------------------------------- #
# Helpers / decorators
# --------------------------------------------------------------------- #
def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            return login_manager.unauthorized()
        if not current_user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def node_agent_url(node, path):
    host = node.hostname.strip()
    return f"http://{host}:{node.port}{path}"


def call_node_agent(node, method, path, json_body=None, timeout=25):
    url = node_agent_url(node, path)
    headers = {"X-Node-Token": node.api_token}
    resp = requests.request(method, url, headers=headers, json=json_body, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def panel_settings():
    return Setting.all_settings()


@app.context_processor
def inject_globals():
    return {
        "panel": panel_settings(),
        "now": datetime.utcnow(),
    }


@app.before_request
def enforce_maintenance_mode():
    exempt_paths = ("/login", "/static", "/health", "/api/agent")
    if request.path.startswith(exempt_paths):
        return None
    settings = panel_settings()
    if settings.get("maintenance_mode") == "1":
        if current_user.is_authenticated and current_user.is_admin:
            return None
        return render_template("maintenance.html"), 503
    return None


@app.before_request
def enforce_suspension():
    if current_user.is_authenticated and current_user.is_suspended and request.endpoint not in (
        "suspended", "logout", "static"
    ):
        return redirect(url_for("suspended"))
    return None


def notify(user_id, title, body=""):
    n = Notification(user_id=user_id, title=title, body=body)
    db.session.add(n)
    db.session.commit()


# --------------------------------------------------------------------- #
# Provisioning (runs in a background thread so the request returns fast)
# --------------------------------------------------------------------- #
def provision_vm(app_ctx, vm_id):
    with app_ctx.app_context():
        vm = VM.query.get(vm_id)
        if not vm:
            return
        node = vm.node
        os_image = vm.os_image
        vm.status = "installing"
        vm.install_log = "Queued on node...\n"
        db.session.commit()

        task = NodeTask(node_id=node.id, vm_id=vm.id, action="create_vm",
                         payload=json.dumps({"image": os_image.docker_image}))
        db.session.add(task)
        db.session.commit()

        container_name = f"skvm-vm{vm.id}"
        vm.container_name = container_name
        db.session.commit()

        def log(line):
            vm.install_log = (vm.install_log or "") + line + "\n"
            db.session.commit()

        try:
            log(f"Pulling image {os_image.docker_image} on node '{node.name}'...")
            result = call_node_agent(node, "POST", "/agent/vms", json_body={
                "vm_id": vm.id,
                "name": container_name,
                "image": os_image.docker_image,
                "ram_mb": vm.ram_mb,
                "disk_gb": vm.disk_gb,
                "cpu_cores": vm.cpu_cores,
            }, timeout=180)

            log("Container created. Installing lxcfs for accurate resource accounting...")
            log("Starting tmate session and retrieving SSH access key...")

            vm.container_id = result.get("container_id")
            vm.ssh_tmate_key = result.get("tmate_ssh")
            vm.ssh_tmate_web = result.get("tmate_web")
            vm.status = "running"
            task.status = "done"
            task.result = json.dumps(result)
            log("VM is online.")
            notify(vm.user_id, "Your VM is ready", f"'{vm.name}' has finished installing and is running.")
        except Exception as exc:  # noqa: BLE001
            vm.status = "error"
            task.status = "failed"
            task.result = str(exc)
            log(f"ERROR: {exc}")
            traceback.print_exc()
        finally:
            task.updated_at = datetime.utcnow()
            db.session.commit()


def start_provisioning(vm_id):
    t = threading.Thread(target=provision_vm, args=(app, vm_id), daemon=True)
    t.start()


def run_agent_action(vm, action):
    """Fire a start/stop/restart/delete/reinstall call at the node agent."""
    node = vm.node
    path_map = {
        "start": (f"/agent/vms/{vm.container_name}/start", "POST"),
        "stop": (f"/agent/vms/{vm.container_name}/stop", "POST"),
        "restart": (f"/agent/vms/{vm.container_name}/restart", "POST"),
        "delete": (f"/agent/vms/{vm.container_name}", "DELETE"),
        "suspend": (f"/agent/vms/{vm.container_name}/stop", "POST"),
        "unsuspend": (f"/agent/vms/{vm.container_name}/start", "POST"),
    }
    path, method = path_map[action]
    return call_node_agent(node, method, path, timeout=60)


# --------------------------------------------------------------------- #
# Public / auth routes
# --------------------------------------------------------------------- #
@app.route("/")
def starter():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("starter.html")


@app.route("/health")
def health():
    try:
        db.session.execute(db.select(User).limit(1))
        db_ok = True
    except Exception:
        db_ok = False
    nodes = Node.query.all()
    return render_template("health.html", db_ok=db_ok, nodes=nodes)


@app.route("/version")
def version_page():
    return render_template("v.html", version="1.0.0")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        identifier = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()
        if not user or not user.check_password(password):
            flash("Incorrect username/email or password.", "err")
            return render_template("login.html"), 401
        if user.is_2fa_enabled:
            session["pending_2fa_user"] = user.id
            return redirect(url_for("two_factor"))
        login_user(user)
        return redirect(url_for("dashboard"))
    return render_template("login.html")


@app.route("/2fa", methods=["GET", "POST"])
def two_factor():
    user_id = session.get("pending_2fa_user")
    if not user_id:
        return redirect(url_for("login"))
    user = User.query.get(user_id)
    if request.method == "POST":
        code = request.form.get("code", "").strip()
        valid = False
        if pyotp and user.otp_secret:
            valid = pyotp.TOTP(user.otp_secret).verify(code, valid_window=1)
        if valid:
            session.pop("pending_2fa_user", None)
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Invalid authentication code.", "err")
    return render_template("2fa.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not username or not email or not password:
            flash("All fields are required.", "err")
            return render_template("register.html"), 400
        if password != confirm:
            flash("Passwords do not match.", "err")
            return render_template("register.html"), 400
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("That username or email is already registered.", "err")
            return render_template("register.html"), 400

        is_first_user = User.query.count() == 0
        user = User(username=username, email=email, is_admin=is_first_user)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Account created — you can sign in now.", "ok")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            user.reset_token = secrets.token_urlsafe(32)
            user.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
            db.session.commit()
            # In production this link is emailed. Shown here so the flow is testable end-to-end.
            flash(f"Reset link: /reset-password/{user.reset_token}", "info")
        else:
            flash("If that email exists, a reset link has been generated.", "info")
        return redirect(url_for("forgot_password"))
    return render_template("forgot_password.html")


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    user = User.query.filter_by(reset_token=token).first()
    if not user or not user.reset_token_expires or user.reset_token_expires < datetime.utcnow():
        flash("That reset link is invalid or has expired.", "err")
        return redirect(url_for("forgot_password"))
    if request.method == "POST":
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if len(password) < 6:
            flash("Password must be at least 6 characters.", "err")
            return render_template("reset_password.html"), 400
        if password != confirm:
            flash("Passwords do not match.", "err")
            return render_template("reset_password.html"), 400
        user.set_password(password)
        user.reset_token = None
        user.reset_token_expires = None
        db.session.commit()
        flash("Password updated — sign in with your new password.", "ok")
        return redirect(url_for("login"))
    return render_template("reset_password.html")


@app.route("/suspended")
def suspended():
    return render_template("suspended.html")


# --------------------------------------------------------------------- #
# User panel
# --------------------------------------------------------------------- #
@app.route("/dashboard")
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for("admin_dashboard"))
    vms = VM.query.filter_by(user_id=current_user.id).all()
    stats = {
        "total_vms": len(vms),
        "running": len([v for v in vms if v.status == "running"]),
        "ram_mb": sum(v.ram_mb for v in vms),
        "disk_gb": sum(v.disk_gb for v in vms),
        "cpu_cores": sum(v.cpu_cores for v in vms),
    }
    return render_template("dashboard.html", vms=vms, stats=stats)


@app.route("/vms")
@login_required
def vm_list():
    if current_user.is_admin:
        vms = VM.query.order_by(VM.created_at.desc()).all()
    else:
        vms = VM.query.filter_by(user_id=current_user.id).order_by(VM.created_at.desc()).all()
    return render_template("vm_list.html", vms=vms)


def get_owned_vm_or_404(vm_id):
    vm = VM.query.get_or_404(vm_id)
    if not current_user.is_admin and vm.user_id != current_user.id:
        abort(403)
    return vm


@app.route("/vm/<int:vm_id>")
@login_required
def vm_detail(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    live = live_stats.get_vm_stats(vm.id)
    if vm.status == "installing":
        return redirect(url_for("vm_installing", vm_id=vm.id))
    return render_template("vm_detail.html", vm=vm, live=live)


@app.route("/vm/<int:vm_id>/installing")
@login_required
def vm_installing(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("vm_installing.html", vm=vm)


@app.route("/vm/<int:vm_id>/status.json")
@login_required
def vm_status_json(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return jsonify({"status": vm.status, "log": vm.install_log or ""})


@app.route("/vm/<int:vm_id>/power/<action>", methods=["POST"])
@login_required
def vm_power(vm_id, action):
    vm = get_owned_vm_or_404(vm_id)
    if action not in ("start", "stop", "restart"):
        abort(400)
    try:
        run_agent_action(vm, action)
        vm.status = "running" if action in ("start", "restart") else "stopped"
        db.session.commit()
        flash(f"VM {action} command sent.", "ok")
    except Exception as exc:  # noqa: BLE001
        flash(f"Could not reach node agent: {exc}", "err")
    return redirect(url_for("vm_detail", vm_id=vm.id))


@app.route("/vm/<int:vm_id>/console")
@login_required
def vm_console(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("console.html", vm=vm)


@app.route("/vm/<int:vm_id>/reinstall", methods=["GET", "POST"])
@login_required
def vm_reinstall(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    os_images = OSImage.query.filter_by(is_active=True).all()
    if request.method == "POST":
        os_id = request.form.get("os_id", type=int)
        os_image = OSImage.query.get(os_id)
        if not os_image:
            flash("Choose a valid operating system.", "err")
            return redirect(url_for("vm_reinstall", vm_id=vm.id))
        vm.os_id = os_image.id
        vm.status = "reinstalling"
        db.session.commit()
        start_provisioning(vm.id)
        flash("Reinstall started.", "ok")
        return redirect(url_for("vm_installing", vm_id=vm.id))
    return render_template("vm_reinstalling.html", vm=vm, os_images=os_images)


@app.route("/vm/<int:vm_id>/snapshots")
@login_required
def vm_snapshots(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("vm_snapshots.html", vm=vm)


@app.route("/vm/<int:vm_id>/files")
@login_required
def vm_files(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("vm_files.html", vm=vm)


@app.route("/vm/<int:vm_id>/ipconfig")
@login_required
def vm_ipconfig(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("vm_ipconfig.html", vm=vm)


@app.route("/vm/<int:vm_id>/migrate", methods=["GET", "POST"])
@login_required
@admin_required
def vm_migrate(vm_id):
    vm = VM.query.get_or_404(vm_id)
    nodes = Node.query.filter(Node.id != vm.node_id).all()
    if request.method == "POST":
        target_id = request.form.get("node_id", type=int)
        target = Node.query.get_or_404(target_id)
        vm.node_id = target.id
        vm.status = "installing"
        db.session.commit()
        start_provisioning(vm.id)
        flash(f"Migration to {target.name} started.", "ok")
        return redirect(url_for("vm_detail", vm_id=vm.id))
    return render_template("vm_migrating.html", vm=vm, nodes=nodes)


@app.route("/vm/<int:vm_id>/expiration", methods=["GET", "POST"])
@login_required
def vm_expiration(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    if request.method == "POST" and current_user.is_admin:
        raw = request.form.get("expires_at", "")
        vm.expires_at = datetime.strptime(raw, "%Y-%m-%d") if raw else None
        db.session.commit()
        flash("Expiration updated.", "ok")
    return render_template("vm_expiration.html", vm=vm)


@app.route("/vms/expiring")
@login_required
def vm_expiring():
    cutoff = datetime.utcnow() + timedelta(days=7)
    q = VM.query.filter(VM.expires_at.isnot(None), VM.expires_at <= cutoff)
    if not current_user.is_admin:
        q = q.filter_by(user_id=current_user.id)
    vms = q.order_by(VM.expires_at.asc()).all()
    return render_template("vm_expiring.html", vms=vms)


@app.route("/vm/<int:vm_id>/suspended")
@login_required
def vm_suspended(vm_id):
    vm = get_owned_vm_or_404(vm_id)
    return render_template("vm_suspended.html", vm=vm)


# ---- account / profile / settings --------------------------------------
@app.route("/profile")
@login_required
def profile():
    return render_template("profile.html")


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if request.method == "POST":
        section = request.form.get("section")
        if section == "email":
            new_email = request.form.get("email", "").strip().lower()
            if new_email and new_email != current_user.email:
                if User.query.filter_by(email=new_email).first():
                    flash("That email is already in use.", "err")
                else:
                    current_user.email = new_email
                    db.session.commit()
                    flash("Email updated.", "ok")
        elif section == "password":
            current_pw = request.form.get("current_password", "")
            new_pw = request.form.get("new_password", "")
            if not current_user.check_password(current_pw):
                flash("Current password is incorrect.", "err")
            elif len(new_pw) < 6:
                flash("New password must be at least 6 characters.", "err")
            else:
                current_user.set_password(new_pw)
                db.session.commit()
                flash("Password changed.", "ok")
        elif section == "2fa_enable" and pyotp:
            current_user.otp_secret = pyotp.random_base32()
            current_user.is_2fa_enabled = True
            db.session.commit()
            flash("Two-factor authentication enabled.", "ok")
        elif section == "2fa_disable":
            current_user.is_2fa_enabled = False
            current_user.otp_secret = None
            db.session.commit()
            flash("Two-factor authentication disabled.", "ok")
        return redirect(url_for("settings"))
    return render_template("settings.html", mode="user")


@app.route("/notifications")
@login_required
def notifications():
    items = Notification.query.filter_by(user_id=current_user.id).order_by(
        Notification.created_at.desc()
    ).all()
    return render_template("notifications.html", items=items)


@app.route("/notifications/<int:n_id>/read", methods=["POST"])
@login_required
def mark_notification_read(n_id):
    n = Notification.query.get_or_404(n_id)
    if n.user_id != current_user.id:
        abort(403)
    n.is_read = True
    db.session.commit()
    return redirect(url_for("notifications"))


@app.route("/backups")
@login_required
def backups():
    vms = VM.query.filter_by(user_id=current_user.id).all() if not current_user.is_admin else VM.query.all()
    return render_template("backup_list.html", vms=vms)


@app.route("/ports")
@login_required
def ports():
    vms = VM.query.filter_by(user_id=current_user.id).all() if not current_user.is_admin else VM.query.all()
    return render_template("ports.html", vms=vms)


@app.route("/logs")
@login_required
def logs():
    return render_template("logs.html", mode="admin" if current_user.is_admin else "user")


@app.route("/api-keys")
@login_required
def api_keys_page():
    return render_template("api.html")


@app.route("/system-info")
@login_required
@admin_required
def system_info():
    import platform
    info = {
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "nodes": Node.query.count(),
        "users": User.query.count(),
        "vms": VM.query.count(),
    }
    return render_template("system_info.html", info=info)


@app.route("/activate-license", methods=["GET", "POST"])
@login_required
@admin_required
def activate_license():
    if request.method == "POST":
        flash("SKVM Community Edition does not require a license key.", "info")
        return redirect(url_for("activate_license"))
    return render_template("activate_license.html")


@app.route("/live-stats")
@login_required
def live_stats_page():
    return render_template("live_stats.html")


@app.route("/api/live-stats/stream")
@login_required
def live_stats_stream():
    def gen():
        import time as _t
        while True:
            yield f"data: {live_stats.as_json()}\n\n"
            _t.sleep(4)
    return Response(gen(), mimetype="text/event-stream")


# --------------------------------------------------------------------- #
# Admin panel
# --------------------------------------------------------------------- #
@app.route("/admin/dashboard")
@login_required
@admin_required
def admin_dashboard():
    nodes = Node.query.all()
    vms = VM.query.all()
    users = User.query.all()
    stats = {
        "total_vms": len(vms),
        "active_vms": len([v for v in vms if v.status == "running"]),
        "total_nodes": len(nodes),
        "online_nodes": len([n for n in nodes if n.is_online()]),
        "total_users": len(users),
        "ram_total": sum(n.ram_mb for n in nodes),
        "ram_used": sum(n.used_ram() for n in nodes),
        "disk_total": sum(n.disk_gb for n in nodes),
        "disk_used": sum(n.used_disk() for n in nodes),
        "cpu_total": sum(n.cpu_cores for n in nodes),
        "cpu_used": sum(n.used_cpu() for n in nodes),
    }
    recent_vms = VM.query.order_by(VM.created_at.desc()).limit(6).all()
    return render_template("admindashboard.html", stats=stats, nodes=nodes, recent_vms=recent_vms)


@app.route("/admin/vm/create", methods=["GET", "POST"])
@login_required
@admin_required
def vm_create():
    nodes = Node.query.all()
    os_images = OSImage.query.filter_by(is_active=True).all()
    users = User.query.order_by(User.username).all()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        ram_mb = request.form.get("ram_mb", type=int)
        disk_gb = request.form.get("disk_gb", type=int)
        cpu_cores = request.form.get("cpu_cores", type=int)
        os_id = request.form.get("os_id", type=int)
        node_id = request.form.get("node_id", type=int)
        user_id = request.form.get("user_id", type=int)

        node = Node.query.get(node_id)
        os_image = OSImage.query.get(os_id)
        target_user = User.query.get(user_id)

        errors = []
        if not name:
            errors.append("VM name is required.")
        if not node:
            errors.append("Select a valid node.")
        if not os_image:
            errors.append("Select a valid operating system.")
        if not target_user:
            errors.append("Select a user to assign this VM to.")
        if node and ram_mb and node.used_ram() + ram_mb > node.ram_mb:
            errors.append("Not enough RAM left on that node.")
        if node and disk_gb and node.used_disk() + disk_gb > node.disk_gb:
            errors.append("Not enough disk left on that node.")
        if node and cpu_cores and node.used_cpu() + cpu_cores > node.cpu_cores:
            errors.append("Not enough vCPU left on that node.")
        if node and node.used_slots() >= node.vm_capacity:
            errors.append("That node is at its VM capacity.")

        if errors:
            for e in errors:
                flash(e, "err")
            return render_template("vm_create.html", nodes=nodes, os_images=os_images, users=users), 400

        vm = VM(
            name=name, user_id=target_user.id, node_id=node.id, os_id=os_image.id,
            ram_mb=ram_mb, disk_gb=disk_gb, cpu_cores=cpu_cores, status="queued",
        )
        db.session.add(vm)
        db.session.commit()
        start_provisioning(vm.id)
        notify(target_user.id, "A new VM is being created", f"'{vm.name}' is now installing.")
        flash("VM creation started.", "ok")
        return redirect(url_for("vm_installing", vm_id=vm.id))

    return render_template("vm_create.html", nodes=nodes, os_images=os_images, users=users)


@app.route("/admin/vm/<int:vm_id>/edit", methods=["GET", "POST"])
@login_required
@admin_required
def vm_edit(vm_id):
    vm = VM.query.get_or_404(vm_id)
    users = User.query.order_by(User.username).all()
    if request.method == "POST":
        vm.name = request.form.get("name", vm.name).strip()
        vm.ram_mb = request.form.get("ram_mb", type=int) or vm.ram_mb
        vm.disk_gb = request.form.get("disk_gb", type=int) or vm.disk_gb
        vm.cpu_cores = request.form.get("cpu_cores", type=int) or vm.cpu_cores
        new_owner = request.form.get("user_id", type=int)
        if new_owner:
            vm.user_id = new_owner
        db.session.commit()
        flash("VM updated.", "ok")
        return redirect(url_for("vm_detail", vm_id=vm.id))
    return render_template("vm_edit.html", vm=vm, users=users)


@app.route("/admin/vm/<int:vm_id>/delete", methods=["POST"])
@login_required
@admin_required
def vm_delete(vm_id):
    vm = VM.query.get_or_404(vm_id)
    try:
        run_agent_action(vm, "delete")
    except Exception as exc:  # noqa: BLE001
        flash(f"Node cleanup failed (continuing): {exc}", "err")
    vm.status = "deleted"
    db.session.commit()
    flash("VM deleted.", "ok")
    return redirect(url_for("vm_list"))


@app.route("/admin/vm/<int:vm_id>/suspend", methods=["POST"])
@login_required
@admin_required
def vm_suspend(vm_id):
    vm = VM.query.get_or_404(vm_id)
    try:
        run_agent_action(vm, "suspend")
    except Exception:
        pass
    vm.status = "suspended"
    db.session.commit()
    flash("VM suspended.", "ok")
    return redirect(url_for("vm_detail", vm_id=vm.id))


# ---- nodes --------------------------------------------------------------
@app.route("/admin/nodes")
@login_required
@admin_required
def nodes():
    all_nodes = Node.query.order_by(Node.created_at.desc()).all()
    return render_template("nodes.html", nodes=all_nodes)


@app.route("/admin/nodes/create", methods=["GET", "POST"])
@login_required
@admin_required
def nodes_create():
    if request.method == "POST":
        node = Node(
            name=request.form.get("name", "").strip(),
            location=request.form.get("location", "").strip(),
            ram_mb=request.form.get("ram_mb", type=int),
            disk_gb=request.form.get("disk_gb", type=int),
            cpu_cores=request.form.get("cpu_cores", type=int),
            vm_capacity=request.form.get("vm_capacity", type=int),
            hostname=request.form.get("hostname", "").strip(),
            port=request.form.get("port", type=int) or 8642,
        )
        db.session.add(node)
        db.session.commit()
        flash("Node created — copy the API token into node.py on that server.", "ok")
        return redirect(url_for("node_view", node_id=node.id))
    return render_template("nodes_create.html")


@app.route("/admin/nodes/<int:node_id>")
@login_required
@admin_required
def node_view(node_id):
    node = Node.query.get_or_404(node_id)
    live = live_stats.get_node_status(node.id)
    return render_template("node_view.html", node=node, live=live)


@app.route("/admin/nodes/<int:node_id>/edit", methods=["GET", "POST"])
@login_required
@admin_required
def node_edit(node_id):
    node = Node.query.get_or_404(node_id)
    if request.method == "POST":
        node.name = request.form.get("name", node.name).strip()
        node.location = request.form.get("location", node.location).strip()
        node.ram_mb = request.form.get("ram_mb", type=int) or node.ram_mb
        node.disk_gb = request.form.get("disk_gb", type=int) or node.disk_gb
        node.cpu_cores = request.form.get("cpu_cores", type=int) or node.cpu_cores
        node.vm_capacity = request.form.get("vm_capacity", type=int) or node.vm_capacity
        node.hostname = request.form.get("hostname", node.hostname).strip()
        node.port = request.form.get("port", type=int) or node.port
        db.session.commit()
        flash("Node updated.", "ok")
        return redirect(url_for("node_view", node_id=node.id))
    return render_template("node_edit.html", node=node)


@app.route("/admin/nodes/<int:node_id>/regenerate-token", methods=["POST"])
@login_required
@admin_required
def node_regen_token(node_id):
    from models import gen_token
    node = Node.query.get_or_404(node_id)
    node.api_token = gen_token()
    node.status = "offline"
    db.session.commit()
    flash("Token regenerated — update node.py on that server.", "ok")
    return redirect(url_for("node_view", node_id=node.id))


@app.route("/admin/nodes/<int:node_id>/delete", methods=["POST"])
@login_required
@admin_required
def node_delete(node_id):
    node = Node.query.get_or_404(node_id)
    if node.vms:
        flash("Cannot delete a node that still has VMs on it.", "err")
        return redirect(url_for("node_view", node_id=node.id))
    db.session.delete(node)
    db.session.commit()
    flash("Node removed.", "ok")
    return redirect(url_for("nodes"))


# ---- users ---------------------------------------------------------------
@app.route("/admin/users")
@login_required
@admin_required
def users():
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template("users.html", users=all_users)


@app.route("/admin/users/create", methods=["GET", "POST"])
@login_required
@admin_required
def users_create():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        is_admin = request.form.get("is_admin") == "on"
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already exists.", "err")
            return render_template("users_create.html"), 400
        user = User(username=username, email=email, is_admin=is_admin)
        user.set_password(password or secrets.token_urlsafe(8))
        db.session.add(user)
        db.session.commit()
        flash(f"User '{username}' created.", "ok")
        return redirect(url_for("users"))
    return render_template("users_create.html")


@app.route("/admin/users/<int:user_id>")
@login_required
@admin_required
def user_detail(user_id):
    user = User.query.get_or_404(user_id)
    return render_template("user_detail.html", user=user)


@app.route("/admin/users/<int:user_id>/edit", methods=["GET", "POST"])
@login_required
@admin_required
def users_edit(user_id):
    user = User.query.get_or_404(user_id)
    if request.method == "POST":
        user.username = request.form.get("username", user.username).strip()
        user.email = request.form.get("email", user.email).strip().lower()
        user.is_admin = request.form.get("is_admin") == "on"
        user.is_suspended = request.form.get("is_suspended") == "on"
        new_password = request.form.get("password", "")
        if new_password:
            user.set_password(new_password)
        db.session.commit()
        flash("User updated.", "ok")
        return redirect(url_for("user_detail", user_id=user.id))
    return render_template("users_edit.html", user=user)


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def users_delete(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "err")
        return redirect(url_for("users"))
    if user.vms:
        flash("Cannot delete a user who still owns VMs. Reassign or delete those first.", "err")
        return redirect(url_for("users"))
    db.session.delete(user)
    db.session.commit()
    flash("User deleted.", "ok")
    return redirect(url_for("users"))


# ---- OS images -------------------------------------------------------------
@app.route("/admin/os")
@login_required
@admin_required
def os_icons():
    images = OSImage.query.order_by(OSImage.name).all()
    return render_template("os_icons.html", images=images)


@app.route("/admin/os/create", methods=["POST"])
@login_required
@admin_required
def os_create():
    name = request.form.get("name", "").strip()
    version = request.form.get("version", "").strip()
    docker_image = request.form.get("docker_image", "").strip()
    icon_url = ""
    file = request.files.get("icon")
    if file and file.filename:
        filename = secure_filename(f"os_{name}_{version}_{file.filename}")
        file.save(os.path.join(UPLOAD_DIR, filename))
        icon_url = f"/static/uploads/{filename}"
    else:
        # fall back to a bundled icon when the name matches a known distro
        known_icons = {"ubuntu": "/static/img/os/ubuntu.png", "debian": "/static/img/os/debian.png"}
        icon_url = known_icons.get(name.strip().lower(), "")
    if not (name and version and docker_image):
        flash("Name, version and Docker image are required.", "err")
    else:
        db.session.add(OSImage(name=name, version=version, docker_image=docker_image, icon=icon_url))
        db.session.commit()
        flash(f"{name} {version} added.", "ok")
    return redirect(url_for("os_icons"))


@app.route("/admin/os/<int:os_id>/delete", methods=["POST"])
@login_required
@admin_required
def os_delete(os_id):
    image = OSImage.query.get_or_404(os_id)
    db.session.delete(image)
    db.session.commit()
    flash("OS image removed.", "ok")
    return redirect(url_for("os_icons"))


# ---- admin settings --------------------------------------------------------
@app.route("/admin/settings", methods=["GET", "POST"])
@login_required
@admin_required
def admin_settings():
    if request.method == "POST":
        for key in ("panel_name", "theme", "discord_link", "website_link"):
            val = request.form.get(key)
            if val is not None:
                Setting.set(key, val.strip())
        Setting.set("maintenance_mode", "1" if request.form.get("maintenance_mode") == "on" else "0")

        file = request.files.get("logo")
        if file and file.filename:
            filename = secure_filename(f"logo_{secrets.token_hex(4)}_{file.filename}")
            file.save(os.path.join(UPLOAD_DIR, filename))
            Setting.set("logo_url", f"/static/uploads/{filename}")

        flash("Settings saved.", "ok")
        return redirect(url_for("admin_settings"))
    return render_template("settings.html", mode="admin")


# --------------------------------------------------------------------- #
# JSON API consumed by node.py's outbound calls (heartbeat) — the rest of
# node <-> panel traffic is the panel calling node.py's /agent/* endpoints
# directly (see call_node_agent above).
# --------------------------------------------------------------------- #
@app.route("/api/agent/heartbeat", methods=["POST"])
def agent_heartbeat():
    token = request.headers.get("X-Node-Token", "")
    node = Node.query.filter_by(api_token=token).first()
    if not node:
        return jsonify({"error": "invalid token"}), 401
    node.status = "online"
    node.last_seen = datetime.utcnow()
    node.docker_version = request.json.get("docker_version") if request.is_json else node.docker_version
    db.session.commit()
    return jsonify({"ok": True})


# --------------------------------------------------------------------- #
# Error handlers
# --------------------------------------------------------------------- #
@app.errorhandler(403)
def err_403(e):
    return render_template("errors/403.html"), 403


@app.errorhandler(404)
def err_404(e):
    return render_template("errors/404.html"), 404


@app.errorhandler(500)
def err_500(e):
    return render_template("errors/500.html"), 500


# --------------------------------------------------------------------- #
# Bootstrapping helpers (also used by skvm.py CLI)
# --------------------------------------------------------------------- #
def init_db():
    with app.app_context():
        db.create_all()
        if OSImage.query.count() == 0:
            db.session.add_all([
                OSImage(name="Ubuntu", version="22.04", docker_image="skvm/ubuntu:22.04",
                        icon="/static/img/os/ubuntu.png"),
                OSImage(name="Ubuntu", version="20.04", docker_image="skvm/ubuntu:20.04",
                        icon="/static/img/os/ubuntu.png"),
                OSImage(name="Debian", version="11", docker_image="skvm/debian:11",
                        icon="/static/img/os/debian.png"),
                OSImage(name="Debian", version="12", docker_image="skvm/debian:12",
                        icon="/static/img/os/debian.png"),
            ])
            db.session.commit()


def create_admin(username, email, password):
    with app.app_context():
        if User.query.filter_by(username=username).first():
            print(f"User '{username}' already exists.")
            return
        user = User(username=username, email=email, is_admin=True)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        print(f"Admin '{username}' created.")


if __name__ == "__main__":
    init_db()
    live_stats.start()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
