"""
SKVM — live_stats_manager.py

A lightweight in-process background worker that periodically polls every
online node's agent (node.py) over HTTP for live per-container resource
usage (cpu %, memory, disk, network) and keeps the results cached in
memory. api.py reads this cache to render the dashboard and to feed the
Server-Sent-Events stream consumed by static/js/live-stats.js.

This intentionally avoids a separate message broker (Redis/RabbitMQ) so
the whole panel can run on a single small VPS with zero extra services.
"""
import json
import threading
import time
from datetime import datetime, timedelta

import requests


class LiveStatsManager:
    def __init__(self, app=None, poll_interval=5):
        self.app = app
        self.poll_interval = poll_interval
        self._cache = {}          # vm_id -> stats dict
        self._node_cache = {}     # node_id -> node status dict
        self._lock = threading.Lock()
        self._thread = None
        self._stop = threading.Event()

    def init_app(self, app):
        self.app = app

    # ------------------------------------------------------------------ #
    # lifecycle
    # ------------------------------------------------------------------ #
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def _run_loop(self):
        while not self._stop.is_set():
            try:
                self._poll_once()
            except Exception as exc:  # never let the poller die
                print(f"[live_stats_manager] poll error: {exc}")
            self._stop.wait(self.poll_interval)

    # ------------------------------------------------------------------ #
    # polling
    # ------------------------------------------------------------------ #
    def _poll_once(self):
        with self.app.app_context():
            from models import Node, VM, db

            nodes = Node.query.all()
            for node in nodes:
                url = f"http://{node.hostname}:{node.port}/agent/stats"
                try:
                    resp = requests.get(
                        url,
                        headers={"X-Node-Token": node.api_token},
                        timeout=4,
                    )
                    if resp.status_code != 200:
                        raise ValueError(f"HTTP {resp.status_code}")
                    data = resp.json()
                    node.status = "online"
                    node.last_seen = datetime.utcnow()
                    node.docker_version = data.get("docker_version", node.docker_version)
                    with self._lock:
                        self._node_cache[node.id] = {
                            "status": "online",
                            "docker_version": data.get("docker_version"),
                            "host_cpu_pct": data.get("host_cpu_pct", 0),
                            "host_mem_pct": data.get("host_mem_pct", 0),
                            "updated_at": datetime.utcnow().isoformat(),
                        }
                        for c in data.get("containers", []):
                            self._cache[c.get("vm_id")] = c
                except Exception:
                    # node unreachable: mark offline only after grace period
                    if node.last_seen and datetime.utcnow() - node.last_seen < timedelta(seconds=90):
                        pass
                    else:
                        node.status = "offline"
                    with self._lock:
                        self._node_cache[node.id] = {
                            "status": node.status,
                            "updated_at": datetime.utcnow().isoformat(),
                        }
            db.session.commit()

    # ------------------------------------------------------------------ #
    # accessors used by routes / SSE
    # ------------------------------------------------------------------ #
    def get_vm_stats(self, vm_id):
        with self._lock:
            return self._cache.get(vm_id, {
                "cpu_pct": 0, "mem_used_mb": 0, "disk_used_gb": 0,
                "net_rx_kb": 0, "net_tx_kb": 0, "status": "unknown",
            })

    def get_node_status(self, node_id):
        with self._lock:
            return self._node_cache.get(node_id, {"status": "offline"})

    def snapshot(self):
        with self._lock:
            return {
                "vms": dict(self._cache),
                "nodes": dict(self._node_cache),
                "at": datetime.utcnow().isoformat(),
            }

    def as_json(self):
        return json.dumps(self.snapshot())


live_stats = LiveStatsManager()
