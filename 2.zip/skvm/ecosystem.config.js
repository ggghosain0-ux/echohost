// PM2 config for SKVM.
// Start the panel with:   pm2 start ecosystem.config.js --only skvm-panel
// (install.sh does this for you automatically)
//
// If you also want PM2 to supervise a node agent running on this SAME
// machine, fill in NODE_TOKEN / PANEL_URL / NODE_PORT below and run:
//   pm2 start ecosystem.config.js --only skvm-node
module.exports = {
  apps: [
    {
      name: "skvm-panel",
      script: "venv/bin/gunicorn",
      args: "-w 4 -b 0.0.0.0:5000 --timeout 120 api:app",
      cwd: __dirname,
      interpreter: "none",
      env: {
        SKVM_SECRET_KEY: process.env.SKVM_SECRET_KEY || "change-me-in-.env",
        SKVM_DATABASE_URL: process.env.SKVM_DATABASE_URL || "",
      },
      autorestart: true,
      max_restarts: 10,
      restart_delay: 3000,
      out_file: "logs/panel.out.log",
      error_file: "logs/panel.err.log",
      time: true,
    },
    {
      name: "skvm-node",
      script: "venv/bin/python3",
      args: "node.py --token CHANGE_ME --panel-url http://127.0.0.1:5000 --port 8642",
      cwd: __dirname,
      interpreter: "none",
      autorestart: true,
      max_restarts: 10,
      restart_delay: 3000,
      out_file: "logs/node.out.log",
      error_file: "logs/node.err.log",
      time: true,
    },
  ],
};
