#!/usr/bin/env python3
"""
SKVM — skvm.py
Small management CLI wrapped around api.py.

Usage:
    python3 skvm.py init-db
    python3 skvm.py create-admin --username admin --email admin@example.com --password changeme
    python3 skvm.py run --host 0.0.0.0 --port 5000
"""
import argparse
import getpass
import sys

import api as skvm_api
from live_stats_manager import live_stats


def cmd_init_db(args):
    skvm_api.init_db()
    print("Database initialised (tables created, default OS images seeded).")


def cmd_create_admin(args):
    password = args.password
    if not password:
        password = getpass.getpass("Admin password: ")
        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("Passwords do not match.", file=sys.stderr)
            sys.exit(1)
    skvm_api.init_db()
    skvm_api.create_admin(args.username, args.email, password)


def cmd_run(args):
    skvm_api.init_db()
    live_stats.start()
    skvm_api.app.run(host=args.host, port=args.port, debug=args.debug)


def main():
    parser = argparse.ArgumentParser(prog="skvm.py", description="SKVM panel management CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-db", help="Create database tables and seed default OS images")

    p_admin = sub.add_parser("create-admin", help="Create an administrator account")
    p_admin.add_argument("--username", required=True)
    p_admin.add_argument("--email", required=True)
    p_admin.add_argument("--password", default=None, help="If omitted, you'll be prompted")

    p_run = sub.add_parser("run", help="Run the development server (use gunicorn/pm2 in production)")
    p_run.add_argument("--host", default="0.0.0.0")
    p_run.add_argument("--port", type=int, default=5000)
    p_run.add_argument("--debug", action="store_true")

    args = parser.parse_args()
    {
        "init-db": cmd_init_db,
        "create-admin": cmd_create_admin,
        "run": cmd_run,
    }[args.command](args)


if __name__ == "__main__":
    main()
