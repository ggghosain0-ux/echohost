#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${ECHO_PANEL_DIR:-/opt/echo-host}"
PORT="${PORT:-6767}"
if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo bash install.sh"; exit 1; fi
apt-get update -y
apt-get install -y ca-certificates curl openssl
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker || true
mkdir -p "$APP_DIR"
cp -r ./* "$APP_DIR/"
chmod +x "$APP_DIR/install.sh"
ADMIN_USER="${ECHO_ADMIN_USER:-admin}"
ADMIN_PASS="${ECHO_ADMIN_PASS:-$(openssl rand -base64 18 | tr -dc 'A-Za-z0-9' | head -c 16)}"
JWT_SECRET="${JWT_SECRET:-$(openssl rand -hex 32)}"
cat > "$APP_DIR/.env" <<ENV
PORT=$PORT
ECHO_ADMIN_USER=$ADMIN_USER
ECHO_ADMIN_PASS=$ADMIN_PASS
JWT_SECRET=$JWT_SECRET
ENV
cat > /etc/systemd/system/echo-host.service <<SERVICE
[Unit]
Description=ECHO HOST Minecraft and App Hosting Panel
After=docker.service network-online.target
Requires=docker.service

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now echo-host
IP=$(hostname -I | awk '{print $1}')
echo
echo "=============================================="
echo " ECHO HOST installation complete"
echo " Panel: http://$IP:$PORT"
echo " Username: $ADMIN_USER"
echo " Password: $ADMIN_PASS"
echo " Data: $APP_DIR/.data"
echo "=============================================="
echo "IMPORTANT: open TCP $PORT for the panel and the allocated Minecraft ports (default 25565-25665) in your VPS firewall/security group."
