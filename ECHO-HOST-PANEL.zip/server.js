const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const {spawn, execFile} = require('child_process');
const os = require('os');

const ROOT=__dirname, DATA=path.join(ROOT,'.data'), SERVERS=path.join(DATA,'servers'), DB=path.join(DATA,'db.json');
const PORT=Number(process.env.PORT||6767), HOST='0.0.0.0';
const JWT_SECRET=process.env.JWT_SECRET||crypto.randomBytes(32).toString('hex');
const ADMIN_USER=process.env.ECHO_ADMIN_USER||'admin';
const ADMIN_PASS=process.env.ECHO_ADMIN_PASS||'';
const processes=new Map();
fs.mkdirSync(SERVERS,{recursive:true});
if(!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({users:[],servers:[],settings:{panelName:'ECHO HOST',defaultPortStart:25565,defaultPortEnd:25665}},null,2));
function db(){try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {users:[],servers:[],settings:{}}}}
function save(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
function b64(s){return Buffer.from(s).toString('base64url')}
function token(user){const h=b64(JSON.stringify({alg:'HS256',typ:'JWT'})),p=b64(JSON.stringify({id:user.id,username:user.username,role:user.role,exp:Date.now()+7*86400000}));const sig=crypto.createHmac('sha256',JWT_SECRET).update(h+'.'+p).digest('base64url');return h+'.'+p+'.'+sig}
function auth(req){const x=(req.headers.authorization||'').split(' ')[1];if(!x)return null;try{const [h,p,s]=x.split('.');const good=crypto.createHmac('sha256',JWT_SECRET).update(h+'.'+p).digest('base64url');if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(good)))return null;const u=JSON.parse(Buffer.from(p,'base64url'));if(u.exp<Date.now())return null;return u}catch{return null}}
async function body(req){let d='';for await(const c of req)d+=c;if(!d)return {};return JSON.parse(d)}
function send(res,status,data,type='application/json'){const b=Buffer.isBuffer(data)?data:Buffer.from(type==='application/json'?JSON.stringify(data):data);res.writeHead(status,{'Content-Type':type,'Content-Length':b.length,'Cache-Control':'no-store'});res.end(b)}
function ok(res,data){send(res,200,data)} function err(res,s,m){send(res,s,{error:m})}
function safeName(s){return String(s||'server').replace(/[^a-zA-Z0-9_-]/g,'-').slice(0,50)}
function run(cmd,args,opts={}){return new Promise((resolve,reject)=>execFile(cmd,args,{timeout:opts.timeout||120000,maxBuffer:20*1024*1024,cwd:opts.cwd},(e,stdout,stderr)=>e?reject(Object.assign(e,{stdout,stderr})):resolve({stdout,stderr})))}
async function dockerOK(){try{await run('docker',['info'],{timeout:5000});return true}catch{return false}}
async function portFree(port){const d=db();return !d.servers.some(s=>Number(s.port)===Number(port))}
async function allocPort(){const d=db(),a=Number(d.settings.defaultPortStart||25565),z=Number(d.settings.defaultPortEnd||25665);for(let p=a;p<=z;p++)if(!d.servers.some(s=>Number(s.port)===p))return p;throw new Error('No free host ports in the configured allocation range.')}
async function ensureAdmin(){if(!ADMIN_PASS)return;const d=db();let u=d.users.find(x=>x.username===ADMIN_USER);const hash=crypto.createHash('sha256').update(ADMIN_PASS).digest('hex');if(!u){u={id:crypto.randomUUID(),username:ADMIN_USER,role:'owner',passwordHash:hash};d.users.push(u)}else{u.passwordHash=hash;u.role='owner'}save(d)}
function serverDir(id){return path.join(SERVERS,id)}
async function createDockerServer(s){
  if(!(await dockerOK())) throw new Error('Docker is unavailable. Install/start Docker or use local runtime for Node/Python.');
  const dir=serverDir(s.id); fs.mkdirSync(dir,{recursive:true});
  let image,cmd;
  if(s.type==='minecraft'){
    image='itzg/minecraft-server:latest';
    cmd=['run','-d','--name',s.containerName,'--restart','unless-stopped','--memory',String(s.ram)+'g','--cpus',String(Math.max(.1,Number(s.cpu||100)/100)),'-p',String(s.port)+':25565/tcp','-p',String(s.port)+':25565/udp','-v',dir+':/data','-e','EULA=TRUE','-e','TYPE='+(s.serverType||'PAPER'),'-e','VERSION='+(s.version||'1.21.11'),'-e','SERVER_PORT=25565','-e','MEMORY='+String(s.ram)+'G','-e','ENABLE_RCON=true','-e','RCON_PASSWORD=echo-panel'];
  } else if(s.type==='nodejs'){
    image='node:'+(s.version||'22')+'-bookworm-slim';
    cmd=['run','-d','--name',s.containerName,'--restart','unless-stopped','--memory',String(s.ram)+'g','--cpus',String(Math.max(.1,Number(s.cpu||100)/100)),'-p',String(s.port)+':'+String(s.internalPort||3000),'-v',dir+':/app','-w','/app','-e','PORT='+String(s.internalPort||3000),'-e','SERVER_PORT='+String(s.internalPort||3000),image,'sh','-lc',s.startup||'if [ -f package.json ]; then npm install --omit=dev && npm start; else node index.js; fi'];
  } else {
    image='python:'+(s.version||'3.12')+'-slim';
    cmd=['run','-d','--name',s.containerName,'--restart','unless-stopped','--memory',String(s.ram)+'g','--cpus',String(Math.max(.1,Number(s.cpu||100)/100)),'-p',String(s.port)+':'+String(s.internalPort||8000),'-v',dir+':/app','-w','/app','-e','PORT='+String(s.internalPort||3000),'-e','SERVER_PORT='+String(s.internalPort||3000),image,'sh','-lc',s.startup||'if [ -f requirements.txt ]; then pip install -r requirements.txt; fi; python3 -u main.py'];
  }
  try{await run('docker',cmd,{timeout:180000});}catch(e){throw new Error((e.stderr||e.message||'Docker create failed').trim())}
  return (await run('docker',['inspect','-f','{{.Id}}',s.containerName])).stdout.trim();
}
async function createLocalServer(s){const dir=serverDir(s.id);fs.mkdirSync(dir,{recursive:true});let child;if(s.type==='nodejs'){const f=fs.existsSync(path.join(dir,'index.js'))?'index.js':'index.js';if(!fs.existsSync(path.join(dir,f)))fs.writeFileSync(path.join(dir,f),`const http=require('http');const p=process.env.PORT||${s.internalPort||3000};http.createServer((q,r)=>r.end('ECHO Node.js server online')).listen(p,'0.0.0.0');console.log('Node.js listening on '+p);`);child=spawn('node',[f],{cwd:dir,env:{...process.env,PORT:String(s.internalPort||s.port),SERVER_PORT:String(s.internalPort||s.port)},stdio:['pipe','pipe','pipe']})}else{if(!fs.existsSync(path.join(dir,'main.py')))fs.writeFileSync(path.join(dir,'main.py'),`from http.server import HTTPServer,BaseHTTPRequestHandler\nimport os\np=int(os.getenv('PORT','${s.internalPort||s.port}'))\nclass H(BaseHTTPRequestHandler):\n def do_GET(self): self.send_response(200); self.end_headers(); self.wfile.write(b'ECHO Python server online')\nHTTPServer(('0.0.0.0',p),H).serve_forever()`);child=spawn('python3',['-u','main.py'],{cwd:dir,env:{...process.env,PORT:String(s.internalPort||s.port)},stdio:['pipe','pipe','pipe']})}processes.set(s.id,child);const log=path.join(dir,'console.log');const ws=fs.createWriteStream(log,{flags:'a'});child.stdout.on('data',d=>ws.write(d));child.stderr.on('data',d=>ws.write(d));child.on('exit',()=>{processes.delete(s.id);ws.end()});return 'local-'+s.id}
async function start(s){if(s.runtime==='local'){if(processes.has(s.id))return;await createLocalServer(s);return}await run('docker',['start',s.containerName],{timeout:30000})}
async function stop(s){if(s.runtime==='local'){const p=processes.get(s.id);if(p){try{p.kill('SIGTERM')}catch{}processes.delete(s.id)}return}await run('docker',['stop',s.containerName],{timeout:30000}).catch(()=>{})}
async function remove(s){await stop(s);if(s.runtime!=='local')await run('docker',['rm','-f',s.containerName],{timeout:30000}).catch(()=>{});await fsp.rm(serverDir(s.id),{recursive:true,force:true})}
async function status(s){if(s.runtime==='local')return {running:processes.has(s.id)};try{const x=(await run('docker',['inspect','-f','{{.State.Running}}',s.containerName],{timeout:5000})).stdout.trim();return {running:x==='true'}}catch{return {running:false}}}
async function logs(s){if(s.runtime==='local'){try{return await fsp.readFile(path.join(serverDir(s.id),'console.log'),'utf8')}catch{return ''}}try{return (await run('docker',['logs','--tail','300',s.containerName],{timeout:10000})).stdout}catch(e){return e.stdout||''}}
async function filesList(s,rel=''){const base=serverDir(s.id),target=path.resolve(base,rel||'.');if(!target.startsWith(base))throw new Error('Invalid path');const arr=await fsp.readdir(target,{withFileTypes:true});return arr.map(x=>({name:x.name,type:x.isDirectory()?'dir':'file',size:x.isFile()?fs.statSync(path.join(target,x.name)).size:0}))}
function requireUser(req,res){const u=auth(req);if(!u){err(res,401,'Authentication required');return null}return u}
async function route(req,res){const u=auth(req), url=new URL(req.url,`http://${req.headers.host||'localhost'}`), p=url.pathname;
if(req.method==='GET'&&p==='/api/health')return ok(res,{status:'ok',panel:'ECHO HOST',docker:await dockerOK(),platform:process.platform,version:'1.0.0'});
if(req.method==='POST'&&p==='/api/auth/login'){const b=await body(req),d=db(),hash=crypto.createHash('sha256').update(String(b.password||'')).digest('hex');const user=d.users.find(x=>x.username===b.username&&x.passwordHash===hash);if(!user)return err(res,401,'Invalid credentials');return ok(res,{token:token(user),user:{id:user.id,username:user.username,role:user.role}})}
if(req.method==='POST'&&p==='/api/auth/register'){const b=await body(req),d=db();if(!b.username||String(b.password).length<6)return err(res,400,'Username and password are required (password: 6+ chars).');if(d.users.some(x=>x.username.toLowerCase()===String(b.username).toLowerCase()))return err(res,409,'Username already exists');const user={id:crypto.randomUUID(),username:String(b.username),role:'user',passwordHash:crypto.createHash('sha256').update(String(b.password)).digest('hex')};d.users.push(user);save(d);return ok(res,{user:{id:user.id,username:user.username,role:user.role}})}
if(!u)return err(res,401,'Authentication required');
if(req.method==='GET'&&p==='/api/me')return ok(res,{user:u});
if(req.method==='GET'&&p==='/api/system')return ok(res,{hostname:os.hostname(),platform:os.platform(),arch:os.arch(),cpus:os.cpus().length,memory:Math.round(os.totalmem()/1073741824*10)/10,freeMemory:Math.round(os.freemem()/1073741824*10)/10,docker:await dockerOK()});
if(req.method==='GET'&&p==='/api/servers'){const d=db();const out=[];for(const s of d.servers){if(u.role!=='owner'&&u.role!=='admin'&&s.owner!==u.id)continue;out.push({...s,status:(await status(s)).running?'online':'offline'});}return ok(res,out)}
if(req.method==='POST'&&p==='/api/servers'){
  if(u.role!=='owner'&&u.role!=='admin') return err(res,403,'Only administrators can create servers');
  const b=await body(req),d=db();
  const type=['minecraft','nodejs','python'].includes(b.type)?b.type:'minecraft';
  const chosenPort=Number(b.port)||await allocPort();
  if(!await portFree(chosenPort)) return err(res,409,'Port is already allocated');
  const dockerAvailable=await dockerOK();
  if(!dockerAvailable&&type==='minecraft'&&b.runtime!=='local') return err(res,503,'Docker is required for real Minecraft hosting. This environment does not provide a Docker daemon.');
  const runtime=(b.runtime==='local'||(!dockerAvailable&&type!=='minecraft'))?'local':'docker';
  const s={id:crypto.randomUUID(),name:String(b.name||'New Server'),owner:b.owner||u.id,type,serverType:String(b.serverType||'PAPER').toUpperCase(),version:String(b.version||(type==='minecraft'?'1.21.11':type==='nodejs'?'22':'3.12')),ram:Math.max(.25,Number(b.ram||2)),cpu:Math.max(10,Number(b.cpu||100)),disk:Number(b.disk||10),port:chosenPort,runtime,internalPort:chosenPort,startup:b.startup||'',containerName:`echo-${safeName(b.name)}-${crypto.randomBytes(4).toString('hex')}`,createdAt:new Date().toISOString()};
  d.servers.push(s);save(d);
  try{s.containerId=s.runtime==='local'?await createLocalServer(s):await createDockerServer(s);save(d);return ok(res,s)}catch(e){d.servers=d.servers.filter(x=>x.id!==s.id);save(d);await fsp.rm(serverDir(s.id),{recursive:true,force:true}).catch(()=>{});return err(res,500,e.message)}}
const m=p.match(/^\/api\/servers\/([^/]+)(?:\/(.*))?$/);if(m){const id=m[1],sub=m[2]||'',d=db(),s=d.servers.find(x=>x.id===id);if(!s)return err(res,404,'Server not found');if(u.role!=='owner'&&u.role!=='admin'&&s.owner!==u.id)return err(res,403,'Forbidden');
if(req.method==='GET'&&!sub)return ok(res,{...s,status:(await status(s)).running?'online':'offline'});
if(req.method==='POST'&&['start','stop','restart'].includes(sub)){try{if(sub==='start')await start(s);if(sub==='stop')await stop(s);if(sub==='restart'){await stop(s);await start(s)}save(d);return ok(res,{success:true,status:(await status(s)).running?'online':'offline'})}catch(e){return err(res,500,e.message)}}
if(req.method==='DELETE'&&!sub){await remove(s);d.servers=d.servers.filter(x=>x.id!==id);save(d);return ok(res,{success:true})}
if(req.method==='GET'&&sub==='logs')return ok(res,{logs:await logs(s)});
if(req.method==='POST'&&sub==='command'){const b=await body(req);if(s.runtime==='local'){const pr=processes.get(s.id);if(!pr||!pr.stdin)return err(res,409,'Server is not running');pr.stdin.write(String(b.command||'')+'\n')}else { if(s.type==='minecraft') await run('docker',['exec',s.containerName,'rcon-cli',String(b.command||'')],{timeout:15000}).catch(()=>{}); else await run('docker',['exec',s.containerName,'sh','-lc',String(b.command||'')],{timeout:15000}).catch(()=>{}); } return ok(res,{success:true})}
if(req.method==='GET'&&sub==='files'){const rel=url.searchParams.get('path')||'';return ok(res,{path:rel,files:await filesList(s,rel)})}
if(req.method==='POST'&&sub==='files/write'){const b=await body(req),rel=String(b.path||''),base=serverDir(id),target=path.resolve(base,rel);if(!target.startsWith(base))return err(res,400,'Invalid path');if(typeof b.content!=='string')return err(res,400,'content required');await fsp.mkdir(path.dirname(target),{recursive:true});await fsp.writeFile(target,b.content);return ok(res,{success:true})}
if(req.method==='DELETE'&&sub==='files'){const rel=url.searchParams.get('path')||'',base=serverDir(id),target=path.resolve(base,rel);if(!target.startsWith(base)||target===base)return err(res,400,'Invalid path');await fsp.rm(target,{recursive:true,force:true});return ok(res,{success:true})}
if(req.method==='GET'&&sub==='stats'){const st=await status(s);return ok(res,{status:st.running?'online':'offline',cpu:0,ram:s.ram,disk:s.disk,port:s.port})}
}
return err(res,404,'Not found')}
async function main(){await ensureAdmin();const server=http.createServer(async(req,res)=>{try{if(req.method==='GET'&&!req.url.startsWith('/api/')){let f=req.url==='/'?'/index.html':req.url.split('?')[0];f=path.normalize(f).replace(/^\.\.(\/|\\)/,'');const fp=path.join(ROOT,'public',f);if(fs.existsSync(fp)&&fs.statSync(fp).isFile()){const ext=path.extname(fp),types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};return send(res,200,fs.readFileSync(fp),types[ext]||'application/octet-stream')}return send(res,404,'Not found','text/plain')}await route(req,res)}catch(e){console.error(e);err(res,500,e.message||'Internal server error')}});server.listen(PORT,HOST,()=>console.log(`ECHO HOST listening on ${HOST}:${PORT}`))}
main();
