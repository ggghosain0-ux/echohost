# ECHO HOST — real local-node hosting panel

A new frontend and lightweight backend for a self-hosted Minecraft / Node.js / Python control panel. The reference project was used only to understand backend capabilities and page concepts; this project does not copy its frontend.

## What is real
- Automatic single local execution target; there is no Nodes page.
- Docker-backed Minecraft hosting using `itzg/minecraft-server`.
- Docker-backed Node.js and Python hosting.
- Optional local-process fallback for Node.js/Python when Docker is unavailable.
- Automatic host-port allocation (default 25565–25665).
- Start / stop / restart / delete.
- Live-ish console through log polling and command input.
- Basic file listing and server data storage.
- RAM/CPU container limits.
- Persistent server containers and data.
- Admin authentication and generated credentials.

## Important capacity note
“Unlimited capacity” is not physically possible. The panel has no artificial node capacity limit, but the VPS still limits CPU, RAM, disk, network and available ports. The allocation range can be changed in `.data/db.json` after installation.

## Install on a VPS
```bash
sudo bash install.sh
```
The installer installs Node.js 22, Docker, creates a systemd service, generates an admin password, and prints the panel URL.

Open TCP 6767 for the panel and the allocated Minecraft port range (default TCP/UDP 25565–25665). Your cloud provider may also require a security-group rule.

## GitHub / CodeSandbox
GitHub itself does not provide a persistent Docker host for an `install.sh` deployment. CodeSandbox environments may not expose a Docker daemon or stable public TCP ports. The panel can run as a web app there, but real public Minecraft hosting requires an environment that provides Docker and inbound TCP/UDP ports, such as a VPS.

## Security
The Docker socket is intentionally not exposed to the browser. The backend is the only component that manages containers. Before public production use, put the panel behind HTTPS, restrict firewall ports, and consider stronger database/auth infrastructure for a multi-tenant service.
