module.exports = {
  apps: [
    {
      name: "echo-host",
      script: "npm",
      args: "start",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "1G",
      env: {
        NODE_ENV: "production",
        PORT: 4455,
        DEFAULT_RUNTIME: "docker",
        ENABLE_DOCKER: "true",
        DOCKER_SOCKET_PATH: "/var/run/docker.sock"
      }
    },
    {
      name: "echo-host-dev",
      script: "npm",
      args: "run dev",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "2G",
      env: {
        NODE_ENV: "development",
        PORT: 3000,
        DEFAULT_RUNTIME: "docker",
        ENABLE_DOCKER: "true",
        DOCKER_SOCKET_PATH: "/var/run/docker.sock"
      }
    }
  ]
};
