#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${ECHO_HOST_DIR:-/opt/echo-host}"
PORT="${PORT:-4455}"
if [ "$(id -u)" -ne 0 ]; then echo "Run as root: sudo bash install-vps.sh"; exit 1; fi

echo "=== ECHO HOST VPS INSTALLER ==="
apt-get update -y
apt-get install -y curl ca-certificates build-essential git

if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

mkdir -p "$APP_DIR"
SRC="$(cd "$(dirname "$0")" && pwd)"
if [ "$SRC" != "$APP_DIR" ]; then cp -a "$SRC/." "$APP_DIR/"; fi
cd "$APP_DIR"

npm install
read -r -p "Admin email: " ADMIN_EMAIL
read -r -s -p "Admin password (minimum 10 characters): " ADMIN_PASS; echo
if [ "${#ADMIN_PASS}" -lt 10 ]; then echo "Password must be at least 10 characters."; exit 1; fi
cat > .env <<ENVEOF
NODE_ENV=production
PORT=$PORT
JWT_SECRET=$(node -e 'console.log(require("crypto").randomBytes(48).toString("hex"))')
ENABLE_DOCKER=true
DOCKER_SOCKET_PATH=/var/run/docker.sock
JTG_OWNER_USER=$ADMIN_EMAIL
JTG_OWNER_PASS=$ADMIN_PASS
ENVEOF
npm run createuser
npm run build
npm install -g pm2
pm2 delete echo-host 2>/dev/null || true
pm2 start dist/server.cjs --name echo-host --update-env
pm2 save
pm2 startup systemd -u root --hp /root >/tmp/echo-host-pm2-startup.txt || true

echo "ECHO HOST installed. URL: http://SERVER_IP:$PORT"
