#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-4455}"
export NODE_ENV=production PORT

echo "=========================================="
echo "        ECHO HOST — CODESANDBOX          "
echo "=========================================="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install Node.js 20+ in the CodeSandbox environment first."
  exit 1
fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "Node.js 20+ required. Found: $(node -v)"
  exit 1
fi

echo "Node: $(node -v)"
echo "NPM : $(npm -v)"

if [ ! -d node_modules ]; then
  echo "[1/4] Installing dependencies..."
  npm install
else
  echo "[1/4] Dependencies already installed."
fi

echo "[2/4] Creating admin account..."
read -r -p "Admin email: " ADMIN_EMAIL
while [ -z "$ADMIN_EMAIL" ]; do read -r -p "Admin email: " ADMIN_EMAIL; done
read -r -s -p "Admin password (minimum 10 characters): " ADMIN_PASS; echo
if [ "${#ADMIN_PASS}" -lt 10 ]; then echo "Password must be at least 10 characters."; exit 1; fi
export JTG_OWNER_USER="$ADMIN_EMAIL"
export JTG_OWNER_PASS="$ADMIN_PASS"
cat > .env <<ENVEOF
NODE_ENV=production
PORT=$PORT
JWT_SECRET=$(node -e 'console.log(require("crypto").randomBytes(48).toString("hex"))')
ENABLE_DOCKER=true
DOCKER_SOCKET_PATH=/var/run/docker.sock
JTG_OWNER_USER=$ADMIN_EMAIL
JTG_OWNER_PASS=$ADMIN_PASS
ENVEOF

# Ensure owner before build/start; this uses the source project's existing user system.
npm run createuser >/tmp/echo-host-createuser.log 2>&1 <<INPUT
$ADMIN_EMAIL
$ADMIN_PASS
INPUT

echo "[3/4] Building the original panel pages/system..."
npm run build

echo "[4/4] Starting ECHO HOST on port $PORT..."
# CodeSandbox does not run systemd; keep the foreground process alive.
exec node dist/server.cjs
