#!/usr/bin/env bash
set -euo pipefail
PANEL=""
TOKEN=""
PORT="7788"
while [[ $# -gt 0 ]]; do
 case "$1" in
  --panel) PANEL="$2"; shift 2;;
  --token) TOKEN="$2"; shift 2;;
  --port) PORT="$2"; shift 2;;
  *) echo "Usage: sudo bash install-node.sh --panel http://PANEL_IP:4455 --token NODE_TOKEN [--port 7788]"; exit 1;;
 esac
done
[ -n "$PANEL" ] && [ -n "$TOKEN" ] || { echo "Panel URL and token are required."; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
apt-get update -y
apt-get install -y curl ca-certificates
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then curl -fsSL https://deb.nodesource.com/setup_20.x | bash -; apt-get install -y nodejs; fi
curl -fsSL https://get.docker.com | sh || true
npm install -g pm2
mkdir -p /opt/echo-host-node
cat > /opt/echo-host-node/package.json <<'JSON'
{"name":"echo-host-node","private":true,"type":"module","dependencies":{"express":"^4.22.2","cors":"^2.8.6"}}
JSON
cat > /opt/echo-host-node/agent.mjs <<'JS'
import express from 'express'; import cors from 'cors';
const app=express(); app.use(cors()); app.use(express.json());
const key=process.env.NODE_KEY;
app.use((req,res,next)=>{if(!key||req.get('authorization')!==`Bearer ${key}`) return res.status(401).json({error:'Unauthorized'}); next();});
app.get('/health',(req,res)=>res.json({status:'online',node:process.env.NODE_NAME||'echo-node'}));
app.get('/info',(req,res)=>res.json({status:'online',node:process.env.NODE_NAME||'echo-node',docker: true}));
app.listen(process.env.PORT||7788,'0.0.0.0',()=>console.log(`ECHO HOST node listening on ${process.env.PORT||7788}`));
JS
cd /opt/echo-host-node
npm install --omit=dev
cat > .env <<ENV
NODE_KEY=$TOKEN
PANEL_URL=$PANEL
PORT=$PORT
ENV
pm2 delete echo-host-node 2>/dev/null || true
pm2 start agent.mjs --name echo-host-node --update-env
pm2 save
IP=$(curl -4 -fsS ifconfig.me || true)
echo "Node online: ${IP:-SERVER_IP}:$PORT"
