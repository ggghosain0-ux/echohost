# ECHO HOST — source-based build

This build keeps the supplied JTG panel's existing React pages, components, server routes, Docker/SFTP/runtime systems, and Socket.IO console architecture. It does not replace the page designs with a new UI.

## CodeSandbox
```bash
chmod +x install-codesandbox.sh
./install-codesandbox.sh
```
Open CodeSandbox **Ports → 4455**.

## VPS panel
```bash
sudo bash install-vps.sh
```
Panel: `http://SERVER_IP:4455`

## Remote node
```bash
sudo bash install-node.sh --panel http://PANEL_IP:4455 --token NODE_TOKEN
```

The CodeSandbox installer intentionally does not use systemd. The VPS installer uses PM2.
