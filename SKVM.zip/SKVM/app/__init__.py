import os, platform, shutil, subprocess, secrets
from datetime import datetime
from flask import Flask, jsonify, request, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from argon2 import PasswordHasher
from functools import wraps
import psutil

db=SQLAlchemy(); login_manager=LoginManager(); ph=PasswordHasher()
SUPPORTED_OS={'Ubuntu 20.04':'ubuntu:20.04','Ubuntu 22.04':'ubuntu:22.04','Debian 11':'debian:11','Debian 12':'debian:12'}
class User(UserMixin,db.Model):
 id=db.Column(db.Integer,primary_key=True); email=db.Column(db.String(255),unique=True,nullable=False); password_hash=db.Column(db.String(512),nullable=False); role=db.Column(db.String(20),default='user'); force_password_change=db.Column(db.Boolean,default=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
class VM(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(64),unique=True,nullable=False); owner_id=db.Column(db.Integer,db.ForeignKey('user.id'),nullable=False); engine=db.Column(db.String(10),nullable=False); os=db.Column(db.String(40),nullable=False); status=db.Column(db.String(30),default='PENDING'); container_id=db.Column(db.String(128)); hostname=db.Column(db.String(64)); username=db.Column(db.String(64)); ssh_port=db.Column(db.Integer); ip_address=db.Column(db.String(64)); tmate_session=db.Column(db.String(512)); cpu=db.Column(db.Integer); ram=db.Column(db.Integer); disk=db.Column(db.Integer); error=db.Column(db.Text); created_at=db.Column(db.DateTime,default=datetime.utcnow); updated_at=db.Column(db.DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
class LocalNode(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(64),unique=True); cpu_total=db.Column(db.Integer); ram_total=db.Column(db.Integer); disk_total=db.Column(db.Integer); docker=db.Column(db.Boolean); lxc=db.Column(db.Boolean); status=db.Column(db.String(20))
class Settings(db.Model):
 id=db.Column(db.Integer,primary_key=True); panel_name=db.Column(db.String(100),default='SKVM'); theme=db.Column(db.String(20),default='dark'); discord_url=db.Column(db.String(500)); container_engine=db.Column(db.String(10),default='docker'); google_enabled=db.Column(db.Boolean,default=False)
@login_manager.user_loader
def load_user(uid): return db.session.get(User,int(uid))
def admin_required(f):
 @wraps(f)
 @login_required
 def w(*a,**k):
  if current_user.role!='admin': return jsonify(error='Forbidden'),403
  return f(*a,**k)
 return w
def host_info():
 return dict(cpu=psutil.cpu_count() or 1,ram=psutil.virtual_memory().total,disk=psutil.disk_usage('/').total,docker=shutil.which('docker') is not None,lxc=shutil.which('lxc') is not None)
def create_app():
 app=Flask(__name__,template_folder='../templates',static_folder='../static'); app.config['SECRET_KEY']=os.getenv('SECRET_KEY',secrets.token_hex(32)); app.config['SQLALCHEMY_DATABASE_URI']=os.getenv('DATABASE_URL','sqlite:///data/skvm.db'); app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
 db.init_app(app); login_manager.init_app(app); login_manager.login_view='login'
 with app.app_context():
  os.makedirs('data',exist_ok=True); db.create_all(); s=Settings.query.first() or Settings(); db.session.add(s)
  if not User.query.filter_by(role='admin').first(): db.session.add(User(email=os.getenv('BOOTSTRAP_ADMIN_EMAIL','admin@gmail.com'),password_hash=ph.hash(os.getenv('BOOTSTRAP_ADMIN_PASSWORD','admin')),role='admin',force_password_change=True))
  n=LocalNode.query.first(); hi=host_info()
  if not n: n=LocalNode(name='local',status='online'); db.session.add(n)
  n.cpu_total=hi['cpu']; n.ram_total=hi['ram']; n.disk_total=hi['disk']; n.docker=hi['docker']; n.lxc=hi['lxc']; db.session.commit()
 @app.context_processor
 def ctx(): return {'settings':Settings.query.first()}
 @app.get('/')
 def starter(): return render_template('starter.html')
 @app.route('/login',methods=['GET','POST'])
 def login():
  if request.method=='POST':
   u=User.query.filter_by(email=request.form['email'].lower()).first()
   try: ok=u and ph.verify(u.password_hash,request.form['password'])
   except Exception: ok=False
   if ok: login_user(u); return redirect('/admin' if u.role=='admin' else '/user')
   flash('Invalid credentials')
  return render_template('login.html')
 @app.route('/register',methods=['GET','POST'])
 def register():
  if request.method=='POST':
   if request.form['password']!=request.form['confirm']: flash('Passwords do not match')
   elif User.query.filter_by(email=request.form['email'].lower()).first(): flash('Email already exists')
   else: db.session.add(User(email=request.form['email'].lower(),password_hash=ph.hash(request.form['password']))); db.session.commit(); return redirect('/login')
  return render_template('register.html')
 @app.get('/logout')
 def logout(): logout_user(); return redirect('/')
 @app.get('/admin')
 @admin_required
 def admin(): return render_template('admin.html',vms=VM.query.all(),info=host_info())
 @app.get('/user')
 @login_required
 def user(): return render_template('user.html',vms=VM.query.filter_by(owner_id=current_user.id).all())
 @app.route('/api/vms',methods=['GET','POST'])
 @login_required
 def vms():
  if request.method=='GET': q=VM.query.all() if current_user.role=='admin' else VM.query.filter_by(owner_id=current_user.id).all(); return jsonify([vm_json(x) for x in q])
  if current_user.role!='admin': return jsonify(error='Forbidden'),403
  d=request.get_json() or {}; required=['name','os','ram','cpu','disk','username','password'];
  if any(k not in d for k in required) or d['os'] not in SUPPORTED_OS: return jsonify(error='Invalid request or unsupported OS'),400
  if VM.query.filter_by(name=d['name']).first(): return jsonify(error='Name already exists'),409
  s=Settings.query.first(); n=LocalNode.query.first(); engine=s.container_engine
  if engine=='docker' and not n.docker or engine=='lxc' and not n.lxc: return jsonify(error=f'{engine} unavailable on this host'),503
  if int(d['ram'])*1024*1024>n.ram_total: return jsonify(error='Requested RAM exceeds host capacity'),400
  vm=VM(name=d['name'],owner_id=d.get('owner_id') or User.query.filter_by(role='user').first().id if User.query.filter_by(role='user').first() else current_user.id,engine=engine,os=d['os'],hostname=d.get('hostname') or d['name'],username=d['username'],cpu=int(d['cpu']),ram=int(d['ram']),disk=int(d['disk']),status='PENDING'); db.session.add(vm); db.session.commit()
  from .services.provisioning.worker import provision; provision(vm.id,d['password']); return jsonify(vm_json(vm)),202
 @app.get('/api/health')
 def health(): n=LocalNode.query.first(); s=Settings.query.first(); return jsonify(status='ok',database='ok',local_node=n.status if n else 'missing',engine=s.container_engine,engine_status='ok' if ((s.container_engine=='docker' and n.docker) or (s.container_engine=='lxc' and n.lxc)) else 'unavailable')
 return app
def vm_json(v): return {'id':v.id,'name':v.name,'engine':v.engine,'os':v.os,'status':v.status,'container_id':v.container_id,'ip_address':v.ip_address,'ssh_port':v.ssh_port,'cpu':v.cpu,'ram':v.ram,'disk':v.disk,'error':v.error}
