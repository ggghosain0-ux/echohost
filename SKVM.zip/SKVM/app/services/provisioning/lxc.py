import subprocess, shutil
class LXCProvider:
 def __init__(self,vm): self.vm=vm
 def _run(self,args): return subprocess.run(args,check=True,capture_output=True,text=True)
 def create(self,password):
  if not shutil.which('lxc'): raise RuntimeError('LXC command is unavailable')
  # LXC image aliases vary by host; fail clearly rather than substitute an OS.
  distro,release=self.vm.os.split(); alias=f'{distro.lower()}/{release}/amd64'
  self._run(['lxc','launch',alias,'skvm-'+self.vm.name]); self.vm.container_id='skvm-'+self.vm.name
  self._run(['lxc','config','set',self.vm.container_id,'limits.cpu',str(self.vm.cpu)]); self._run(['lxc','config','set',self.vm.container_id,'limits.memory',f'{self.vm.ram}MB'])
  raise RuntimeError('LXC provisioning created a container but SSH/tmate integration requires a host-specific LXC image configuration; container left recoverable')
 def start(self): self._run(['lxc','start',self.vm.container_id])
 def stop(self): self._run(['lxc','stop',self.vm.container_id])
 def restart(self): self.stop(); self.start()
 def delete(self): self._run(['lxc','delete','--force',self.vm.container_id])
