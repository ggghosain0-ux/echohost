import docker, secrets, time
class DockerProvider:
 def __init__(self,vm): self.vm=vm; self.client=docker.from_env()
 def create(self,password):
  image={'Ubuntu 20.04':'ubuntu:20.04','Ubuntu 22.04':'ubuntu:22.04','Debian 11':'debian:11','Debian 12':'debian:12'}[self.vm.os]; self.client.images.pull(image)
  c=self.client.containers.create(image,name='skvm-'+self.vm.name,command=['/bin/sh','-c','trap : TERM INT; sleep infinity & wait'],hostname=self.vm.hostname,detach=True,mem_limit=f'{self.vm.ram}m',nano_cpus=self.vm.cpu*100000000,labels={'skvm':'true'})
  self.vm.container_id=c.id; c.start(); self.vm.ip_address=c.attrs['NetworkSettings']['IPAddress']
  # Installation is executed inside the real container; failures are not hidden.
  cmd=['sh','-lc','apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server tmate && mkdir -p /run/sshd && useradd -m '+self.vm.username+' || true && echo '+self.vm.username+':'+password+' | chpasswd && /usr/sbin/sshd && tmate -F -S /tmp/skvm-tmate new-session -d && tmate -S /tmp/skvm-tmate display -p "#{tmate_ssh}"']
  out=c.exec_run(cmd,demux=False); text=out.output.decode(errors='replace') if hasattr(out,'output') else str(out)
  if out.exit_code!=0: raise RuntimeError(text)
  self.vm.tmate_session=text.strip().splitlines()[-1]
 def start(self): self.client.containers.get(self.vm.container_id).start()
 def stop(self): self.client.containers.get(self.vm.container_id).stop()
 def restart(self): self.client.containers.get(self.vm.container_id).restart()
 def delete(self): self.client.containers.get(self.vm.container_id).remove(force=True)
