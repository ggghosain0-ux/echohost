import threading, subprocess, secrets
from ... import db, VM, Settings
from .docker import DockerProvider
from .lxc import LXCProvider
def provision(vm_id,password):
 def run():
  vm=db.session.get(VM,vm_id)
  try:
   vm.status='CREATING'; db.session.commit(); p=DockerProvider(vm) if vm.engine=='docker' else LXCProvider(vm); p.create(password); vm.status='READY'; db.session.commit()
  except Exception as e: vm.status='FAILED'; vm.error=str(e)[:2000]; db.session.commit()
 threading.Thread(target=run,daemon=True).start()
