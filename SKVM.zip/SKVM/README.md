# SKVM

SKVM is a Flask-based infrastructure panel for real Docker/LXC workloads. It supports exactly Ubuntu 20.04, Ubuntu 22.04, Debian 11 and Debian 12. The local node is automatically discovered; there is no Nodes UI.

## Status and safety
This repository is an infrastructure-oriented baseline, not a claim of production certification. Docker provisioning uses the Docker SDK and real in-container package installation. LXC distributions, storage quotas, bridge networking and SSH exposure vary significantly by host; the LXC provider fails explicitly where host-specific configuration is incomplete rather than reporting success. Run it only on a dedicated, hardened VPS and review the security model before exposure to the internet.

## Install on Debian/Ubuntu VPS
```bash
git clone <your-repository> SKVM
cd SKVM
chmod +x install.sh
sudo ./install.sh
sudo systemctl status skvm
sudo journalctl -u skvm -f
```
The installer is rerun-safe: it preserves `.env`, SQLite data and existing containers. Set a strong `SECRET_KEY` and bootstrap password in `.env` before production use. The bootstrap defaults are `admin@gmail.com` / `admin`; change them immediately.

## Engines
Set `container_engine` in the database through the future admin settings surface or directly during controlled deployment. Docker requires a reachable daemon. LXC requires the `lxc` CLI, privileges, a matching image alias, cgroups and networking. Never expose privileged host execution to ordinary users.

## CodeSandbox
The web application may run, but real Docker/LXC provisioning generally cannot due to missing daemon, privileges, cgroups and networking. `/api/health` reports detected capabilities; no successful provisioning is fabricated.

## Tests and checks
```bash
python -m compileall .
bash -n install.sh
pytest
```
Infrastructure integration tests must be run on a disposable Linux host with Docker/LXC available. The supplied `vm.sh` was reviewed as a reference for validation, OS selection and cleanup concepts; its QEMU/cloud-init design was not wrapped into SKVM.

## Security
Use TLS/reverse proxy, firewall the management port, rotate secrets, restrict Docker socket access, add CSRF protection/rate limiting before public deployment, and maintain backups. Do not store passwords or tmate sessions in logs. Tmate sessions are temporary access material and should be treated as sensitive.
