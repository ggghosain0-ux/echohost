#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo.'; exit 1; fi
command -v apt-get >/dev/null || { echo 'Debian/Ubuntu installer required'; exit 1; }
apt-get update; apt-get install -y python3 python3-venv python3-pip curl
python3 -m venv .venv; . .venv/bin/activate; pip install -r requirements.txt
[[ -f .env ]] || cp .env.example .env
mkdir -p data logs
cat >/etc/systemd/system/skvm.service <<UNIT
[Unit]
Description=SKVM Hosting Panel
After=network.target docker.service
[Service]
WorkingDirectory=$ROOT
ExecStart=$ROOT/.venv/bin/python $ROOT/run.py
Restart=on-failure
EnvironmentFile=$ROOT/.env
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload; systemctl enable --now skvm; curl -fsS http://127.0.0.1:8080/api/health; echo; echo "SKVM running at http://$(hostname -I | awk '{print $1}'):8080"
