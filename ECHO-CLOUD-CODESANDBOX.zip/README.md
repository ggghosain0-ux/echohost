# ECHO CLOUD — One Panel. Every Server.

Production-oriented monorepo foundation for unified Minecraft, website, bot, Docker and VPS hosting.

## Stack
React + TypeScript + Vite, Fastify + TypeScript, PostgreSQL/Prisma, Redis-ready worker, secure node-agent protocol, Docker provider abstraction.

## Development
1. `cp .env.example .env`
2. `docker compose -f infrastructure/docker/docker-compose.dev.yml up -d postgres redis`
3. `npm install`
4. `npm run db:migrate`
5. `npm run db:seed`
6. `npm run dev`

API: http://localhost:4000/health
Web: http://localhost:5173

This repository intentionally uses provider abstractions where real infrastructure depends on external virtualization/DNS/cloud providers. Development adapters report unavailable infrastructure instead of inventing metrics or IPs.
