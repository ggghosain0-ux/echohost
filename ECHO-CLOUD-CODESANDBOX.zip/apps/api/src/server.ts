import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';

const app = Fastify({ logger: true });
const DATA_DIR = path.resolve(process.cwd(), '.echo-data');
const DB_FILE = path.join(DATA_DIR, 'dev.json');

type Role = 'OWNER'|'ADMIN'|'STAFF'|'USER'|'READ_ONLY';
type User = { id:string; email:string; name:string; passwordHash:string; role:Role; createdAt:string; disabledAt?:string|null };
type Service = { id:string; internalId:string; ownerId:string; name:string; type:string; status:string; cpu:number; ramMb:number; storageMb:number; createdAt:string; config:Record<string,unknown> };
type Activity = { id:string; userId:string; action:string; resourceType:string; resourceId:string; createdAt:string };
type Store = { users:User[]; services:Service[]; activities:Activity[] };

async function load(): Promise<Store> { await fs.mkdir(DATA_DIR,{recursive:true}); try { return JSON.parse(await fs.readFile(DB_FILE,'utf8')); } catch { const s:Store={users:[],services:[],activities:[]}; await save(s); return s; } }
async function save(s:Store){ await fs.writeFile(DB_FILE,JSON.stringify(s,null,2),'utf8'); }
const store = await load();
const email = z.string().email();
const password = z.string().min(8).max(200);

await app.register(cors,{origin:true,credentials:true});
await app.register(helmet);
await app.register(rateLimit,{max:120,timeWindow:'1 minute'});
await app.register(jwt,{secret:process.env.JWT_SECRET || 'codesandbox-dev-secret-change-in-production'});

function ok(data:unknown){return {success:true,data};}
function fail(reply:any,status:number,code:string,message:string){return reply.code(status).send({success:false,error:{code,message}});}
async function requireAuth(req:any,reply:any){ try { await req.jwtVerify(); } catch { return fail(reply,401,'UNAUTHORIZED','Authentication required'); } }
function currentUser(req:any){ return store.users.find(u=>u.id===req.user.sub); }

app.get('/health',async()=>({ok:true,service:'echo-api',mode:'codesandbox-development',time:new Date().toISOString()}));

app.post('/api/auth/register',async(req,reply)=>{
  const b=z.object({email,password,name:z.string().min(2).max(80)}).parse(req.body);
  if(store.users.some(u=>u.email.toLowerCase()===b.email.toLowerCase())) return fail(reply,409,'EMAIL_EXISTS','Email is already registered');
  const user:User={id:randomUUID(),email:b.email.toLowerCase(),name:b.name,passwordHash:await bcrypt.hash(b.password,12),role:store.users.length===0?'OWNER':'USER',createdAt:new Date().toISOString()};
  store.users.push(user); await save(store);
  const token=app.jwt.sign({sub:user.id,role:user.role});
  return reply.code(201).send(ok({token,user:{id:user.id,email:user.email,name:user.name,role:user.role}}));
});

app.post('/api/auth/login',async(req,reply)=>{
  const b=z.object({email,password}).parse(req.body); const user=store.users.find(u=>u.email===b.email.toLowerCase());
  if(!user || user.disabledAt || !(await bcrypt.compare(b.password,user.passwordHash))) return fail(reply,401,'INVALID_CREDENTIALS','Invalid email or password');
  store.activities.push({id:randomUUID(),userId:user.id,action:'LOGIN',resourceType:'USER',resourceId:user.id,createdAt:new Date().toISOString()}); await save(store);
  return ok({token:app.jwt.sign({sub:user.id,role:user.role}),user:{id:user.id,email:user.email,name:user.name,role:user.role}});
});
app.get('/api/auth/me',{preHandler:requireAuth},async(req,reply)=>{const u=currentUser(req); if(!u)return fail(reply,401,'USER_NOT_FOUND','User not found'); return ok({id:u.id,email:u.email,name:u.name,role:u.role,createdAt:u.createdAt});});

const serviceSchema=z.object({name:z.string().min(1).max(80),type:z.enum(['MINECRAFT','WEBSITE','BOT','VIRTUAL_MACHINE','DOCKER_APP']),cpu:z.number().positive().max(64),ramMb:z.number().int().positive().max(262144),storageMb:z.number().int().positive().max(10485760),config:z.record(z.string(),z.unknown()).optional()});
app.get('/api/services',{preHandler:requireAuth},async(req)=>ok(store.services.filter(s=>s.ownerId===req.user.sub).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))));
app.post('/api/services',{preHandler:requireAuth},async(req,reply)=>{
  const b=serviceSchema.parse(req.body); const owned=store.services.filter(s=>s.ownerId===req.user.sub); if(owned.length>=50)return fail(reply,429,'SERVICE_LIMIT','Service limit reached');
  const s:Service={id:randomUUID(),internalId:randomUUID(),ownerId:req.user.sub,name:b.name,type:b.type,status:'OFFLINE',cpu:b.cpu,ramMb:b.ramMb,storageMb:b.storageMb,createdAt:new Date().toISOString(),config:b.config||{}};
  store.services.push(s); store.activities.push({id:randomUUID(),userId:req.user.sub,action:'SERVICE_CREATED',resourceType:'SERVICE',resourceId:s.id,createdAt:new Date().toISOString()}); await save(store); return reply.code(201).send(ok(s));
});
app.post('/api/services/:id/:action',{preHandler:requireAuth},async(req,reply)=>{
  const {id,action}=req.params as {id:string;action:string}; if(!['start','stop','restart','kill'].includes(action))return fail(reply,400,'INVALID_ACTION','Unsupported service action');
  const s=store.services.find(x=>x.id===id && x.ownerId===req.user.sub); if(!s)return fail(reply,404,'SERVICE_NOT_FOUND','Service was not found');
  if(action==='start'||action==='restart')s.status='ONLINE'; else s.status='OFFLINE';
  store.activities.push({id:randomUUID(),userId:req.user.sub,action:action.toUpperCase(),resourceType:'SERVICE',resourceId:s.id,createdAt:new Date().toISOString()}); await save(store); return ok({accepted:true,service:s,provider:'local-development-adapter'});
});
app.get('/api/activity',{preHandler:requireAuth},async(req)=>ok(store.activities.filter(a=>a.userId===req.user.sub).slice(-100).reverse()));
app.get('/api/nodes',{preHandler:requireAuth},async()=>ok([]));

app.setErrorHandler((err,req,reply)=>{ req.log.error({err},'request failed'); if(err instanceof z.ZodError)return fail(reply,400,'VALIDATION_ERROR','Invalid request data'); return fail(reply,(err as any).statusCode||500,'INTERNAL_ERROR','Request could not be completed'); });

const port=Number(process.env.API_PORT||4000); await app.listen({port,host:'0.0.0.0'});
