import {db} from '@echo/database';
console.log('ECHO WORKER online');
setInterval(async()=>{await db.node.updateMany({where:{lastHeartbeat:{lt:new Date(Date.now()-90000)},status:'ONLINE'}},data:{status:'OFFLINE'}}).catch(console.error)},30000);
