const API=process.env.ECHO_API_URL||'http://localhost:4000'; const TOKEN=process.env.ECHO_AGENT_TOKEN||''; const nodeId=process.env.ECHO_NODE_ID||'';
async function heartbeat(){const m={nodeId,cpuUsed:0,ramUsedMb:0,diskUsedMb:0}; const r=await fetch(API+'/api/nodes/heartbeat',{method:'POST',headers:{Authorization:`Bearer ${TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify(m)}); if(!r.ok)console.error('Heartbeat rejected',r.status);}
console.log('ECHO AGENT starting'); setInterval(()=>heartbeat().catch(console.error),30000); heartbeat().catch(console.error);
