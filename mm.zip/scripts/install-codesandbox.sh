#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
echo "=== ECHO CLOUD CodeSandbox Installer ==="
command -v node >/dev/null || { echo "Node.js is required"; exit 1; }
node -e 'if(+process.versions.node.split(".")[0]<20)process.exit(1)' || { echo "Node.js 20+ required"; exit 1; }
[ -f .env ] || cp .env.example .env
node scripts/init-node.mjs
npm install
npm run build
printf '\nInstalled successfully.\n'
printf 'Start: npm run dev\n'
printf 'Web:  http://127.0.0.1:5173\nAPI:  http://127.0.0.1:4000\nAgent: http://127.0.0.1:8080\n'
printf 'The local node is registered automatically when API + agent start.\n'
