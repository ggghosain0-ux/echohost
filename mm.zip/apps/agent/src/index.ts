import Fastify from 'fastify';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { promises as fs } from 'node:fs';
import path from 'node:path';
const exec=promisify(execFile);
const api=(process.env.ECHO_API_URL||'').replace(/\/$/,'');
const token=process.env.ECHO_NODE_TOKEN||'';
const agentToken=token;
const port=Number(process.env.AGENT_PORT||8080);
const dataRoot=process.env.ECHO_AGENT_DATA||path.resolve(process.cwd(),'.echo-agent-data');

async function docker(args:string[], allowFailure=false){
  try{return (await exec('docker',args,{maxBuffer:1024*1024*8})).stdout.trim();}
  catch(e:any){if(allowFailure)return e?.stdout?.trim()||'';throw new Error(e?.stderr||e?.message||'docker failed')}
}
async function hasDocker(){try{await docker(['version','--format','{{.Server.Version}}']);return true}catch{return false}}
function cname(id:string){return `echo-${id.replace(/[^a-zA-Z0-9_.-]/g,'').slice(0,48)}`}
function imageFor(s:any){
  if(s.type==='MINECRAFT') return String(s.config?.image||'itzg/minecraft-server:latest');
  if(s.type==='WEBSITE') return String(s.config?.image||'nginx:alpine');
  if(s.type==='BOT') return String(s.config?.image || (s.config?.runtime==='python'?'python:3.12-alpine':'node:20-alpine'));
  return String(s.config?.image||'alpine:latest');
}
async function freePort(){
  for(let p=25565;p<26000;p++) { const out=await docker(['ps','--format','{{.Ports}}'],true); if(!out.includes(`:${p}->`)&&!out.includes(`:${p}/`)) return p; }
  throw new Error('NO_FREE_PORTS');
}
function envArgs(s:any){const out:string[]=[];const env=s.config?.env||{};for(const [k,v] of Object.entries(env))out.push('-e',`${k}=${v}`);if(s.type==='MINECRAFT'){out.push('-e','EULA=TRUE');if(s.config?.version)out.push('-e',`VERSION=${s.config.version}`);if(s.config?.runtime)out.push('-e',`TYPE=${s.config.runtime}`);out.push('-e',`MEMORY=${Math.max(512,Math.floor(s.ramMb*0.9))}M`);}return out}
async function writeFiles(id:string,files:any){if(!files||typeof files!=='object')return;const root=path.join(dataRoot,id,'files');await fs.mkdir(root,{recursive:true});for(const [name,content] of Object.entries(files)){const rel=String(name);const target=path.resolve(root,rel);if(target!==root&&!target.startsWith(root+path.sep))throw new Error('PATH_TRAVERSAL');await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,String(content),'utf8');}}
async function provision(s:any){
  if(!(await hasDocker())) throw new Error('DOCKER_UNAVAILABLE');
  const name=cname(s.id); await docker(['rm','-f',name],true);
  const hostPort=Number(s.config?.port||await freePort());
  const volume=`echo-${s.id}`;
  await docker(['volume','create',volume]);
  await writeFiles(s.id,s.config?.files);
  const args=['run','-d','--name',name,'--label',`echo.cloud.service=${s.id}`,'--restart',String(s.config?.restartPolicy||'unless-stopped'),'--cpus',String(s.cpu),'--memory',`${s.ramMb}m`,'-v',`${volume}:/data`];
  if(s.type==='MINECRAFT') args.push('-p',`${hostPort}:25565/tcp`);
  else if(s.type==='WEBSITE') args.push('-p',`${hostPort}:80/tcp`);
  else if(s.config?.containerPort) args.push('-p',`${hostPort}:${Number(s.config.containerPort)}/tcp`);
  args.push(...envArgs(s)); args.push(imageFor(s));
  if(s.type==='BOT'){
    const runtime=String(s.config?.runtime||'node'); const start=String(s.config?.startCommand||(runtime==='python'?'pip install -r /data/requirements.txt && python /data/main.py':'npm install --prefix /data && node /data/index.js'));
    args.push('sh','-lc',start);
  } else if(s.type==='WEBSITE' && s.config?.startCommand) args.push('sh','-lc',String(s.config.startCommand));
  await docker(args);
  return {container:name,port:hostPort,volume};
}
async function action(s:any,act:string){const n=cname(s.id);if(act==='start')await docker(['start',n]);if(act==='stop')await docker(['stop',n]);if(act==='restart')await docker(['restart',n]);if(act==='remove'){await docker(['rm','-f',n],true);await docker(['volume','rm',`echo-${s.id}`],true);return;}return {container:n};}
async function main(){
  await fs.mkdir(dataRoot,{recursive:true});
  const app=Fastify({logger:true});
  app.addHook('preHandler',async(req,reply)=>{if(req.url==='/health')return;const a=req.headers.authorization||'';if(!agentToken||a!==`Bearer ${agentToken}`)return reply.code(401).send({success:false,error:{message:'Unauthorized'}})});
  app.get('/health',async()=>({ok:true,agent:true,docker:await hasDocker(),hostname:os.hostname()}));
  app.post('/internal/services/provision',async(req)=>({success:true,data:await provision(req.body as any)}));
  for(const act of ['start','stop','restart','remove']) app.post(`/internal/services/${act}`,async(req)=>({success:true,data:await action(req.body as any,act)}));
  app.post('/internal/services/logs',async(req)=>{const s:any=req.body;const logs=await docker(['logs','--tail','300',cname(s.id)],true);return {success:true,logs:logs.split('\n').filter(Boolean)}});
  app.post('/internal/vps/reinstall',async(req,reply)=>reply.code(501).send({success:false,error:{message:'VPS provider is not configured. Connect Proxmox/Libvirt.'}}));
  app.post('/internal/vps/snapshot',async(req,reply)=>reply.code(501).send({success:false,error:{message:'VPS provider is not configured. Connect Proxmox/Libvirt.'}}));
  await app.listen({host:'0.0.0.0',port});
  console.log(`ECHO AGENT listening on ${port}; docker=${await hasDocker()}`);
  if(api&&token){
    const payload={token,name:process.env.ECHO_NODE_NAME||os.hostname(),hostname:os.hostname(),ip:process.env.ECHO_NODE_IP,cpuTotal:os.cpus().length,ramTotalMb:Math.floor(os.totalmem()/1048576),diskTotalMb:undefined,agentUrl:process.env.ECHO_AGENT_URL||`http://127.0.0.1:${port}`};
    const r=await fetch(api+'/api/agent/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)}); const reg:any=await r.json(); console.log('Node registration:',r.status,reg); if(!r.ok) throw new Error(reg?.error?.message||'Node registration failed');
    const nodeId=reg.data.nodeId;
    setInterval(async()=>{try{await fetch(api+'/api/agent/heartbeat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({nodeId,token,cpuUsed:os.loadavg()[0],ramUsedMb:Math.floor((os.totalmem()-os.freem())/1048576)})})}catch(e){console.error('heartbeat',e)}},30000);
  }
}
main().catch(e=>{console.error(e);process.exit(1)});
