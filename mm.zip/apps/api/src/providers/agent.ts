import { Service } from '../types';
import { ServiceProvider, VPSProvider } from './types';

export class AgentProvider implements ServiceProvider, VPSProvider {
  readonly name = 'echo-agent';
  constructor(private readonly node: { agentUrl?: string; token?: string }) {}
  private async call(path: string, service: Service, extra: Record<string, unknown> = {}) {
    if (!this.node.agentUrl || !this.node.token) throw new Error('AGENT_NOT_CONFIGURED');
    const r = await fetch(this.node.agentUrl.replace(/\/$/, '') + path, { method: 'POST', headers: {'content-type':'application/json','authorization':`Bearer ${this.node.token}`}, body: JSON.stringify({service, ...extra}) });
    const text = await r.text(); let data:any; try { data=JSON.parse(text); } catch { data={message:text}; }
    if (!r.ok) throw new Error(data?.error?.message || data?.message || `Agent returned ${r.status}`);
    return data;
  }
  async provision(service: Service){return this.call('/internal/services/provision',service)}
  async start(service: Service){return this.call('/internal/services/start',service)}
  async stop(service: Service){return this.call('/internal/services/stop',service)}
  async restart(service: Service){return this.call('/internal/services/restart',service)}
  async remove(service: Service){return this.call('/internal/services/remove',service)}
  async logs(service: Service){const r=await this.call('/internal/services/logs',service);return r.logs||[]}
  async reinstall(service: Service,image: string){return this.call('/internal/vps/reinstall',service,{image})}
  async snapshot(service: Service,name: string){return this.call('/internal/vps/snapshot',service,{name})}
}
