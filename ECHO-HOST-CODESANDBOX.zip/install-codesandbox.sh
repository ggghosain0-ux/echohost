#!/usr/bin/env bash
set -euo pipefail

# ECHO HOST — CodeSandbox installer/runner
# Designed for CodeSandbox/dev containers where systemd is unavailable.

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-4455}"

printf '\n====================================\n'
printf '        ECHO HOST / CODESANDBOX\n'
printf '====================================\n\n'

command -v node >/dev/null 2>&1 || {
  echo "ERROR: Node.js is not installed. Node.js 20+ is required."
  exit 1
}

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "ERROR: Node.js 20+ is required. Found: $(node -v)"
  exit 1
fi

echo "Node.js: $(node -v)"
echo "npm:     $(npm -v)"
echo "Port:    $PORT"
echo

cd "$APP_DIR"

if [ ! -f "apps/panel/server.js" ]; then
  echo "ERROR: apps/panel/server.js was not found."
  echo "Run this script from the ECHO-HOST project directory."
  exit 1
fi

echo "[1/4] Installing panel dependencies..."
npm install --omit=dev --prefix apps/panel

# The original server protected '/' with API authentication before static routing.
# CodeSandbox should expose the dashboard at '/'. Move static GET handling before API auth.
node <<'NODE'
const fs = require('fs');
const file = 'apps/panel/server.js';
let s = fs.readFileSync(file, 'utf8');
const marker = '  const user=requireAuth(req,res); if(!user) return;\n';
const replacement = '  // Public dashboard assets; API routes remain protected.\n  if (req.method === "GET" && !p.startsWith("/api/")) return serveStatic(req,res);\n\n' + marker;
if (s.includes(marker) && !s.includes('Public dashboard assets; API routes remain protected.')) {
  s = s.replace(marker, replacement);
  // Remove the old catch-all static route at the end because it is now handled above.
  s = s.replace('  if(req.method==="GET") return serveStatic(req,res);\n', '');
  fs.writeFileSync(file, s);
  console.log('Patched dashboard routing: / now serves the web UI.');
} else if (s.includes('Public dashboard assets; API routes remain protected.')) {
  console.log('Dashboard routing already patched.');
} else {
  console.log('Dashboard routing patch was not applied; inspect server.js before deployment.');
}
NODE

echo "[2/4] Preparing CodeSandbox data directory..."
mkdir -p .echo-host-data

# Stop an older ECHO HOST process started by this project, if present.
echo "[3/4] Stopping previous panel process (if any)..."
pkill -f 'apps/panel/server.js' 2>/dev/null || true
sleep 1

echo "[4/4] Starting ECHO HOST on port $PORT..."
echo
echo "Dashboard: http://localhost:$PORT/"
echo "Health:    http://localhost:$PORT/api/health"
echo
echo "In CodeSandbox, open the PORTS panel and open port $PORT."
echo "Keep this terminal running while the panel is in use."
echo

export NODE_ENV=development
export PORT
export ECHO_DATA_DIR="$APP_DIR/.echo-host-data"
exec node apps/panel/server.js
