#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=4455

echo "== ECHO HOST panel installer =="
if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo bash install-panel.sh"; exit 1; fi

command -v node >/dev/null || { echo "Node.js 20+ is required."; exit 1; }
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[[ "$NODE_MAJOR" -ge 20 ]] || { echo "Node.js 20+ required; found $(node -v)"; exit 1; }

mkdir -p /opt/echo-host /var/lib/echo-host-panel
cp -a "$APP_DIR/." /opt/echo-host/
cd /opt/echo-host

npm install --omit=dev --prefix apps/panel

cat >/etc/systemd/system/echo-host-panel.service <<'UNIT'
[Unit]
Description=ECHO HOST Control Panel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/echo-host
Environment=NODE_ENV=production
Environment=PORT=4455
Environment=ECHO_DATA_DIR=/var/lib/echo-host-panel
ExecStart=/usr/bin/node /opt/echo-host/apps/panel/server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/var/lib/echo-host-panel
[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now echo-host-panel
sleep 2
if ! curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null; then
  journalctl -u echo-host-panel --no-pager -n 80
  exit 1
fi

echo
echo "ECHO HOST is running on http://SERVER_IP:${PORT}"
echo "Create the first administrator by POSTing /api/auth/bootstrap with email/password."
echo "Example:"
echo "curl -X POST http://127.0.0.1:${PORT}/api/auth/bootstrap -H 'content-type: application/json' -d '{\"email\":\"admin@example.com\",\"password\":\"CHANGE_THIS_LONG_PASSWORD\"}'"
