FROM node:22-bookworm-slim
WORKDIR /app
COPY package.json ./
COPY apps/panel/package.json apps/panel/package.json
COPY apps/panel apps/panel
RUN cd apps/panel && npm install --omit=dev
EXPOSE 4455
CMD ["node","apps/panel/server.js"]
