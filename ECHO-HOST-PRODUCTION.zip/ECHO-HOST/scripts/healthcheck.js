const http=require("http");
function get(u){return new Promise((resolve,reject)=>{http.get(u,r=>{let s="";r.on("data",c=>s+=c);r.on("end",()=>resolve({code:r.statusCode,body:s}))}).on("error",reject)})}
(async()=>{
 try{
   const x=await get("http://127.0.0.1:"+(process.env.PORT||4455)+"/api/health");
   if(x.code!==200) throw new Error(x.body);
   console.log("ECHO HOST health: OK",x.body);
 }catch(e){console.error("ECHO HOST health: FAILED",e.message);process.exit(1)}
})();
