#!/usr/bin/env bash
set -euo pipefail

PANEL=""
TOKEN=""
PORT=7788

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel) PANEL="$2"; shift 2;;
    --token) TOKEN="$2"; shift 2;;
    --port) PORT="$2"; shift 2;;
    *) echo "Unknown argument: $1"; exit 2;;
  esac
done

if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo bash install-node.sh ..."; exit 1; fi
[[ -n "$PANEL" && -n "$TOKEN" ]] || { echo "Usage: sudo bash install-node.sh --panel http://PANEL:4455 --token NODE_TOKEN"; exit 1; }

command -v node >/dev/null || { echo "Node.js 20+ is required."; exit 1; }
command -v docker >/dev/null || echo "WARNING: Docker is not installed; Minecraft/website/bot workloads will not start until Docker is installed."

mkdir -p /opt/echo-host-node /var/lib/echo-host
cp -a "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/apps/agent/." /opt/echo-host-node/
cd /opt/echo-host-node
npm install --omit=dev

cat >/etc/systemd/system/echo-host-node.service <<UNIT
[Unit]
Description=ECHO HOST Node Agent
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/echo-host-node
Environment=NODE_ENV=production
Environment=AGENT_PORT=${PORT}
Environment=ECHO_NODE_TOKEN=${TOKEN}
Environment=ECHO_AGENT_DATA=/var/lib/echo-host
ExecStart=/usr/bin/node /opt/echo-host-node/agent.js
Restart=always
RestartSec=3
NoNewPrivileges=false
[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now echo-host-node
sleep 2
curl -fsS "http://127.0.0.1:${PORT}/health" || { journalctl -u echo-host-node --no-pager -n 80; exit 1; }
echo
echo "ECHO HOST node agent is online on port ${PORT}."
echo "Open the panel and wait for the node health check."
