# ECHO HOST — Production-Oriented Multi-Service Hosting Panel

ECHO HOST is a self-hosted control panel for four workloads:

- Minecraft servers
- Website/app hosting
- Bot hosting
- VPS hosting through Proxmox VE

It includes a browser panel, API, PostgreSQL persistence, Redis-ready architecture,
an authenticated node agent, Docker workload provisioning, Proxmox VPS integration,
backups, schedules, audit logs, resource monitoring, allocations, users/roles,
and a tunnel provider abstraction.

## Important production note

This repository is designed as a real deployable platform rather than a UI mockup.
However, no software can honestly be guaranteed to have "zero bugs" before it is
deployed and tested against the operator's actual Linux, Docker, firewall, DNS,
storage, Proxmox, and network environment.

The included scripts perform dependency checks and fail safely. They do not expose
an unrestricted root shell through the web panel.

## Quick start

Panel:

    sudo bash install-panel.sh

The panel listens on:

    http://SERVER_IP:4455

Node:

    sudo bash install-node.sh --panel http://PANEL_IP:4455 --token NODE_ENROLLMENT_TOKEN

For a production deployment, put HTTPS in front of port 4455 using Caddy or Nginx.

## Main architecture

Browser
  -> ECHO HOST API/UI :4455
  -> PostgreSQL
  -> authenticated node-agent
  -> Docker workloads / Proxmox API / host networking

Docker is used for application-style workloads such as Minecraft and bots.
Real VPS workloads use Proxmox/QEMU instead of pretending that a Docker container
is a virtual machine.

## First administrator

The first administrator is created by install-panel.sh. The password is generated
and printed once. Change it immediately after login.

## Security model

- Argon2id password hashes
- signed session tokens
- role based authorization
- per-resource ownership checks
- node enrollment tokens
- TLS-ready architecture
- audit trail
- command allowlists
- resource limits
- no arbitrary browser-to-node shell execution
- destructive operations require explicit API actions
- secrets are stored separately from normal resource metadata

## Providers

Minecraft:
Docker + official/known server images configured by the administrator.

Websites:
Docker containers with static, Node.js or PHP runtime profiles.

Bots:
Docker containers with Node.js or Python runtime profiles.

VPS:
Proxmox VE API using QEMU/KVM. Proxmox is required for real VPS provisioning.

Tunnels:
The provider interface supports Playit-compatible agent installation and a generic
tunnel provider adapter. The panel never scrapes or reverse engineers third-party
private APIs.

## Production checklist

1. Use a dedicated Linux node.
2. Use HTTPS.
3. Change all generated credentials.
4. Use PostgreSQL on persistent storage.
5. Back up PostgreSQL and workload data.
6. Configure firewall rules.
7. Configure DNS and an IP allocation pool.
8. Configure a Proxmox API token for VPS provisioning.
9. Install the node agent on each workload node.
10. Run the included health checks.
11. Test restores before accepting real customers.
12. Monitor disk, memory, CPU, Docker and Proxmox health.
