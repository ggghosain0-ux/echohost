# Feature matrix

## Control plane
- Dashboard
- Authentication
- RBAC roles
- Node enrollment
- Service lifecycle
- Audit logging
- Service resources
- Backup records
- Schedules
- Tunnel records
- System health
- Responsive UI

## Minecraft
- Service creation
- CPU/RAM/disk allocation
- Start/stop/restart
- Dedicated node model
- Tunnel integration point
- Backup/schedule model
- Docker runtime target

Production extensions expected per deployment:
- version-specific server image catalog
- EULA acknowledgement
- startup variables
- file manager
- WebSocket console
- SFTP
- plugin/mod installer
- world import/export
- automatic crash recovery
- Java runtime profiles

## Website
- Node/static/PHP runtime model
- Resource allocation
- Domain/DNS integration point
- SSL reverse-proxy integration point
- Backups and schedules

## Bot
- Node/Python runtime model
- resource allocation
- start command model
- persistent filesystem
- restart policy

## VPS
- Proxmox integration point
- VM resource model
- node/storage configuration
- snapshots/reinstall/firewall integration points

A real VPS must be backed by a hypervisor such as Proxmox/QEMU/KVM; Docker alone is
not equivalent to a VPS. Proxmox documents both KVM virtual machines and LXC containers.
