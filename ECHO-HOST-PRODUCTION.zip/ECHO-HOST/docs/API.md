# API

Authentication:
- POST /api/auth/bootstrap
- POST /api/auth/login
- GET /api/me

Control plane:
- GET /api/dashboard
- GET /api/services
- POST /api/services
- POST /api/services/:id/start
- POST /api/services/:id/stop
- POST /api/services/:id/restart
- POST /api/services/:id/delete

Nodes:
- GET /api/nodes
- POST /api/nodes/enroll

Backups:
- GET /api/backups
- POST /api/backups

Schedules:
- POST /api/schedules

Tunnels:
- GET /api/tunnels
- POST /api/tunnels

Audit:
- GET /api/audit

Node agent:
- GET /health
- GET /v1/system
- POST /v1/docker/inspect
- POST /v1/docker/run
