# Production deployment

## Panel
Run install-panel.sh on a dedicated Ubuntu/Debian server. Put Caddy/Nginx in front
of port 4455 for HTTPS.

## Node
Run install-node.sh on every compute node. Use one node enrollment token per node
and rotate/revoke tokens when nodes are retired.

## Minecraft
Use isolated Docker workloads with fixed CPU, memory and disk limits. Never allow
customers to submit arbitrary host commands.

## Websites and bots
Use separate Docker networks, filesystem quotas and egress policy. Add an image
allowlist and scan uploads before production use.

## VPS
Configure a dedicated Proxmox cluster and use an API token with the minimum required
permissions. Never store a Proxmox root password in the browser.

## Backups
Use object storage or a dedicated backup server. Test restores.

## Monitoring
Monitor panel, node agent, Docker daemon, disk inode usage, PostgreSQL, Proxmox and
network health.

## TLS
Use HTTPS for the panel and agent control channel. Never expose the node agent's
port to the public internet without an authenticated TLS/reverse-proxy boundary.

## Scaling
Put PostgreSQL on managed/dedicated storage, add Redis for queues, use a job worker,
and run multiple panel instances behind a load balancer.
