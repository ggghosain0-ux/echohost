let token=localStorage.getItem("echo_token");
let page="dashboard";
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(path,opt={}) {
  const r=await fetch(path,{...opt,headers:{"content-type":"application/json",...(token?{authorization:"Bearer "+token}:{}),...(opt.headers||{})}});
  if(r.status===401){token=null;localStorage.removeItem("echo_token");login();throw new Error("login");}
  const j=await r.json(); if(!r.ok) throw new Error(j.error||"request_failed"); return j;
}
async function login(){
  const email=prompt("ECHO HOST admin email"); const password=prompt("Password");
  try{const j=await api("/api/auth/login",{method:"POST",body:JSON.stringify({email,password})});token=j.token;localStorage.setItem("echo_token",token);render();}
  catch(e){alert(e.message);login();}
}
function table(rows,cols){return `<table class="table"><thead><tr>${cols.map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows||""}</tbody></table>`}
async function render(){
  if(!token)return login();
  $("#pageTitle").textContent=page[0].toUpperCase()+page.slice(1); $("#status").textContent="Connected";
  document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  try {
    if(page==="dashboard"){
      const d=await api("/api/dashboard");
      $("#content").innerHTML=`<div class="grid">${Object.entries(d.counts).map(([k,v])=>`<div class="card"><h3>${esc(k)}</h3><div class="big">${v}</div></div>`).join("")}</div>
      <div class="card" style="margin-top:16px"><h3>Recent services</h3>${table(d.services.map(s=>`<tr><td>${esc(s.name)}</td><td><span class="pill">${s.type}</span></td><td>${s.status}</td><td>${s.cpu} vCPU / ${s.ramMb} MB</td></tr>`).join(""),["Name","Type","Status","Resources"])}</div>`;
    } else if(["minecraft","websites","bots","vps"].includes(page)){
      const type=page==="minecraft"?"minecraft":page==="websites"?"website":page==="bots"?"bot":"vps";
      const all=await api("/api/services"), rows=all.filter(s=>s.type===type);
      $("#content").innerHTML=`<div class="toolbar"><button class="btn" onclick="createService('${type}')">+ Create ${page}</button></div>${rows.length?table(rows.map(s=>`<tr><td>${esc(s.name)}</td><td>${s.status}</td><td>${s.cpu} vCPU</td><td>${s.ramMb} MB</td><td><button class="btn alt" onclick="action('${s.id}','restart')">Restart</button> <button class="btn alt" onclick="action('${s.id}', '${s.status==="running"?"stop":"start"}')">${s.status==="running"?"Stop":"Start"}</button></td></tr>`).join(""),["Name","Status","CPU","RAM","Actions"]):`<div class="empty">No ${page} yet.</div>`}`;
    } else if(page==="nodes"){
      const n=await api("/api/nodes");
      $("#content").innerHTML=`<div class="toolbar"><button class="btn" onclick="createNode()">+ Add node</button></div>${n.length?table(n.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.address)}</td><td>${x.status}</td><td>${(x.capabilities||[]).join(", ")}</td></tr>`).join(""),["Name","Address","Status","Capabilities"]):"<div class=empty>No nodes registered.</div>"}`;
    } else if(page==="backups"){
      const b=await api("/api/backups"); $("#content").innerHTML=table(b.map(x=>`<tr><td>${x.id}</td><td>${x.serviceId}</td><td>${x.storage}</td><td>${x.status}</td></tr>`).join(""),["ID","Service","Storage","Status"]);
    } else if(page==="tunnels"){
      const t=await api("/api/tunnels"); $("#content").innerHTML=`<div class="toolbar"><button class="btn" onclick="createTunnel()">+ Create tunnel</button></div>`+table(t.map(x=>`<tr><td>${x.provider}</td><td>${x.serviceId}</td><td>${x.protocol}</td><td>${x.status}</td><td>${x.publicAddress||"—"}</td></tr>`).join(""),["Provider","Service","Protocol","Status","Public address"]);
    } else if(page==="audit"){
      const a=await api("/api/audit"); $("#content").innerHTML=table(a.map(x=>`<tr><td>${new Date(x.at).toLocaleString()}</td><td>${esc(x.user)}</td><td>${esc(x.action)}</td><td>${esc(x.target)}</td></tr>`).join(""),["Time","User","Action","Target"]);
    } else if(page==="settings"){
      const s=await api("/api/system"); $("#content").innerHTML=`<div class="card"><h2>System</h2><p>Node ${esc(s.node)}</p><p>Platform ${esc(s.platform)}</p><p>Panel port ${s.port}</p></div>`;
    }
  } catch(e){$("#content").innerHTML=`<div class="card">Error: ${esc(e.message)}</div>`}
}
async function createNode(){
 const name=prompt("Node name"); const address=prompt("Node public/private address");
 if(!name)return; const n=await api("/api/nodes/enroll",{method:"POST",body:JSON.stringify({name,address})});
 alert("Node created.\nEnrollment token:\n"+n.enrollmentToken+"\nGive this token to install-node.sh."); render();
}
async function createService(type){
 const nodes=await api("/api/nodes"); if(!nodes.length)return alert("Add a node first.");
 const name=prompt("Service name"); if(!name)return;
 const nodeId=prompt("Node ID:\n"+nodes.map(n=>n.id+" = "+n.name).join("\n"),nodes[0].id);
 await api("/api/services",{method:"POST",body:JSON.stringify({type,name,nodeId,cpu:1,ramMb:type==="vps"?2048:1024,diskMb:10240})}); render();
}
async function action(id,op){await api("/api/services/"+id+"/"+op,{method:"POST"});render();}
async function createTunnel(){
 const services=await api("/api/services"); if(!services.length)return alert("Create a service first.");
 const serviceId=prompt("Service ID",services[0].id), provider=prompt("Provider","playit");
 if(!serviceId)return; await api("/api/tunnels",{method:"POST",body:JSON.stringify({serviceId,provider,localPort:25565})});render();
}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{page=b.dataset.page;render()});
$("#refresh").onclick=render; render();
