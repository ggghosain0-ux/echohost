const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");

const PORT = Number(process.env.PORT || 4455);
const DATA = process.env.ECHO_DATA_DIR || path.join(process.cwd(), "data");
const DB = path.join(DATA, "echo-host.json");
fs.mkdirSync(DATA, { recursive: true });

function readDB() {
  try { return JSON.parse(fs.readFileSync(DB, "utf8")); }
  catch {
    return {
      users: [], nodes: [], services: [], allocations: [], backups: [],
      schedules: [], tunnels: [], audit: [], settings: {
        brand: "ECHO HOST", version: "1.0.0"
      }
    };
  }
}
function writeDB(db) {
  const tmp = DB + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB);
}
function id(prefix) { return prefix + "_" + crypto.randomBytes(8).toString("hex"); }
function json(res, code, data) {
  const body = JSON.stringify(data);
  res.writeHead(code, {"content-type":"application/json; charset=utf-8","cache-control":"no-store"});
  res.end(body);
}
function parseBody(req) {
  return new Promise((resolve,reject)=>{
    let s="";
    req.on("data", c => { s += c; if (s.length > 2_000_000) req.destroy(); });
    req.on("end", ()=> { try { resolve(s ? JSON.parse(s) : {}); } catch(e){ reject(e); } });
    req.on("error", reject);
  });
}
function auth(req) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return null;
  const db = readDB();
  return db.users.find(u => u.token === h.slice(7)) || null;
}
function requireAuth(req,res) {
  const u = auth(req);
  if (!u) { json(res,401,{error:"authentication_required"}); return null; }
  return u;
}
function audit(db,user,action,target,detail={}) {
  db.audit.unshift({id:id("aud"), at:new Date().toISOString(), user:user?.email||"system", action,target,detail});
  db.audit = db.audit.slice(0,5000);
}
function safeName(s) { return String(s||"").replace(/[^a-zA-Z0-9._-]/g,"-").slice(0,64); }

const staticRoot = path.join(__dirname, "web");

function serveStatic(req,res) {
  let p = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
  if (p === "/") p = "/index.html";
  const full = path.normalize(path.join(staticRoot,p));
  if (!full.startsWith(staticRoot)) return json(res,403,{error:"forbidden"});
  fs.readFile(full,(err,data)=>{
    if(err) return json(res,404,{error:"not_found"});
    const ext=path.extname(full);
    const types={".html":"text/html",".js":"text/javascript",".css":"text/css",".svg":"image/svg+xml",".json":"application/json"};
    res.writeHead(200,{"content-type":types[ext]||"application/octet-stream"});
    res.end(data);
  });
}

async function route(req,res) {
  const url = new URL(req.url,"http://localhost");
  const p = url.pathname;
  if (req.method === "GET" && p === "/api/health")
    return json(res,200,{ok:true,service:"echo-host-panel",version:"1.0.0",time:new Date().toISOString()});

  if (req.method === "POST" && p === "/api/auth/bootstrap") {
    const db=readDB();
    if(db.users.length) return json(res,409,{error:"bootstrap_already_completed"});
    const b=await parseBody(req);
    if(!b.email || !b.password || String(b.password).length < 10)
      return json(res,400,{error:"email_and_password_minimum_10_required"});
    const token=crypto.randomBytes(32).toString("hex");
    db.users.push({id:id("usr"),email:String(b.email).trim().toLowerCase(),role:"admin",
      passwordHash:crypto.createHash("sha256").update(String(b.password)).digest("hex"),token});
    writeDB(db);
    return json(res,201,{token,email:db.users[0].email});
  }

  if (req.method === "POST" && p === "/api/auth/login") {
    const b=await parseBody(req), db=readDB();
    const hash=crypto.createHash("sha256").update(String(b.password||"")).digest("hex");
    const u=db.users.find(x=>x.email===String(b.email||"").trim().toLowerCase() && x.passwordHash===hash);
    if(!u) return json(res,401,{error:"invalid_credentials"});
    u.token=crypto.randomBytes(32).toString("hex"); writeDB(db);
    return json(res,200,{token:u.token,user:{id:u.id,email:u.email,role:u.role}});
  }

  const user=requireAuth(req,res); if(!user) return;
  const db=readDB();

  if(req.method==="GET" && p==="/api/me")
    return json(res,200,{id:user.id,email:user.email,role:user.role});

  if(req.method==="GET" && p==="/api/dashboard")
    return json(res,200,{
      counts:{
        minecraft:db.services.filter(x=>x.type==="minecraft").length,
        websites:db.services.filter(x=>x.type==="website").length,
        bots:db.services.filter(x=>x.type==="bot").length,
        vps:db.services.filter(x=>x.type==="vps").length,
        nodes:db.nodes.length
      },
      services:db.services.slice(0,20),
      nodes:db.nodes.map(n=>({...n,token:undefined}))
    });

  if(req.method==="GET" && p==="/api/services")
    return json(res,200,db.services);
  if(req.method==="GET" && p==="/api/nodes")
    return json(res,200,db.nodes.map(n=>({...n,enrollmentToken:undefined})));
  if(req.method==="GET" && p==="/api/audit")
    return json(res,200,db.audit.slice(0,200));
  if(req.method==="GET" && p==="/api/backups")
    return json(res,200,db.backups);
  if(req.method==="GET" && p==="/api/tunnels")
    return json(res,200,db.tunnels);

  if(req.method==="POST" && p==="/api/nodes/enroll") {
    if(user.role!=="admin") return json(res,403,{error:"admin_required"});
    const b=await parseBody(req);
    const token=crypto.randomBytes(24).toString("hex");
    const node={id:id("node"),name:safeName(b.name||"node"),address:b.address||"",
      status:"pending",createdAt:new Date().toISOString(),enrollmentToken:token,
      capabilities:b.capabilities||["minecraft","website","bot"]};
    db.nodes.push(node); audit(db,user,"node.create",node.id,{name:node.name}); writeDB(db);
    return json(res,201,{nodeId:node.id,enrollmentToken:token,node});
  }

  if(req.method==="POST" && p==="/api/services") {
    const b=await parseBody(req);
    const allowed=["minecraft","website","bot","vps"];
    if(!allowed.includes(b.type)) return json(res,400,{error:"unsupported_service_type"});
    if(!b.name || !b.nodeId) return json(res,400,{error:"name_and_node_required"});
    const node=db.nodes.find(n=>n.id===b.nodeId);
    if(!node) return json(res,404,{error:"node_not_found"});
    const s={id:id(b.type),name:safeName(b.name),type:b.type,nodeId:b.nodeId,
      status:"created",plan:b.plan||"custom",cpu:Number(b.cpu||1),ramMb:Number(b.ramMb||1024),
      diskMb:Number(b.diskMb||10240),port:b.port||null,config:b.config||{},
      createdAt:new Date().toISOString()};
    db.services.push(s); audit(db,user,"service.create",s.id,{type:s.type,name:s.name}); writeDB(db);
    return json(res,201,s);
  }

  const sm=p.match(/^\/api\/services\/([^/]+)\/(start|stop|restart|delete)$/);
  if(req.method==="POST" && sm) {
    const s=db.services.find(x=>x.id===sm[1]); if(!s) return json(res,404,{error:"service_not_found"});
    const op=sm[2];
    if(op==="delete"){ s.status="deleting"; audit(db,user,"service.delete",s.id); writeDB(db); return json(res,202,{accepted:true}); }
    s.status=op==="stop"?"stopped":"running";
    audit(db,user,"service."+op,s.id); writeDB(db);
    return json(res,200,{accepted:true,service:s});
  }

  if(req.method==="POST" && p==="/api/tunnels") {
    const b=await parseBody(req);
    if(!b.serviceId || !b.provider) return json(res,400,{error:"serviceId_and_provider_required"});
    const t={id:id("tun"),serviceId:b.serviceId,provider:b.provider,protocol:b.protocol||"tcp",
      localPort:Number(b.localPort||25565),status:"requested",publicAddress:null,createdAt:new Date().toISOString()};
    db.tunnels.push(t); audit(db,user,"tunnel.create",t.id,t); writeDB(db);
    return json(res,201,t);
  }

  if(req.method==="POST" && p==="/api/backups") {
    const b=await parseBody(req);
    const item={id:id("bkp"),serviceId:b.serviceId,storage:b.storage||"local",
      status:"queued",createdAt:new Date().toISOString()};
    db.backups.push(item); audit(db,user,"backup.create",item.id,item); writeDB(db);
    return json(res,202,item);
  }

  if(req.method==="POST" && p==="/api/schedules") {
    const b=await parseBody(req);
    db.schedules.push({id:id("sch"),serviceId:b.serviceId,cron:b.cron,action:b.action,enabled:true});
    audit(db,user,"schedule.create",db.schedules.at(-1).id,b); writeDB(db);
    return json(res,201,db.schedules.at(-1));
  }

  if(req.method==="GET" && p==="/api/system")
    return json(res,200,{node:process.version,platform:process.platform,port:PORT,dataDir:DATA});

  if(req.method==="GET") return serveStatic(req,res);
  return json(res,404,{error:"route_not_found"});
}

http.createServer((req,res)=>{
  route(req,res).catch(e=>{console.error(e);json(res,500,{error:"internal_error"});});
}).listen(PORT,"0.0.0.0",()=>console.log(`ECHO HOST listening on :${PORT}`));
