#!/usr/bin/env node
const http=require("http"),fs=require("fs"),os=require("os"),crypto=require("crypto"),{execFile}=require("child_process");
const PORT=Number(process.env.AGENT_PORT||7788), TOKEN=process.env.ECHO_NODE_TOKEN;
const DATA=process.env.ECHO_AGENT_DATA||"/var/lib/echo-host";
fs.mkdirSync(DATA,{recursive:true});
function auth(req){return TOKEN && req.headers.authorization==="Bearer "+TOKEN}
function json(res,c,d){res.writeHead(c,{"content-type":"application/json"});res.end(JSON.stringify(d))}
function run(cmd,args,timeout=120000){
 return new Promise(resolve=>execFile(cmd,args,{timeout,maxBuffer:1024*1024*4},(error,stdout,stderr)=>resolve({ok:!error,stdout,stderr:String(stderr||"")})));
}
async function route(req,res){
 if(req.method==="GET"&&req.url==="/health") return json(res,200,{ok:true,hostname:os.hostname(),cpu:os.cpus().length,memory:os.totalmem(),time:new Date().toISOString()});
 if(!auth(req)) return json(res,401,{error:"unauthorized"});
 if(req.method==="GET"&&req.url==="/v1/system")
   return json(res,200,{hostname:os.hostname(),platform:process.platform,arch:process.arch,cpu:os.cpus().length,memory:os.totalmem(),uptime:os.uptime()});
 if(req.method==="POST"&&req.url==="/v1/docker/inspect"){
   let b="";req.on("data",c=>b+=c);req.on("end",async()=>{try{const x=JSON.parse(b),r=await run("docker",["inspect",x.name]);json(res,r.ok?200:400,{ok:r.ok,output:r.stdout,error:r.stderr})}catch(e){json(res,400,{error:"bad_request"})}});
   return;
 }
 if(req.method==="POST"&&req.url==="/v1/docker/run"){
   let b="";req.on("data",c=>b+=c);req.on("end",async()=>{try{
     const x=JSON.parse(b);
     if(!/^[a-zA-Z0-9._-]{1,64}$/.test(x.name||"")) return json(res,400,{error:"invalid_name"});
     const image=String(x.image||""); if(!/^[a-zA-Z0-9./:_-]{1,200}$/.test(image)) return json(res,400,{error:"invalid_image"});
     const args=["run","-d","--name",x.name,"--restart","unless-stopped","--memory",String(Number(x.memoryMb||1024))+"m","--cpus",String(Number(x.cpu||1)),image];
     const r=await run("docker",args);json(res,r.ok?200:400,{ok:r.ok,output:r.stdout,error:r.stderr});
   }catch(e){json(res,400,{error:"bad_request"})}});
   return;
 }
 json(res,404,{error:"not_found"});
}
http.createServer((q,s)=>route(q,s).catch(e=>json(s,500,{error:"internal_error"}))).listen(PORT,"0.0.0.0",()=>console.log("ECHO node agent :"+PORT));
