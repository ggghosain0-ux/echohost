import React from 'react';
export function Badge({children}:{children:React.ReactNode}){return <span className="badge">{children}</span>}
export function StatCard({label,value,detail}:{label:string;value:string|number;detail?:string}){return <div className="card stat"><span className="muted">{label}</span><strong>{value}</strong>{detail&&<small>{detail}</small>}</div>}
