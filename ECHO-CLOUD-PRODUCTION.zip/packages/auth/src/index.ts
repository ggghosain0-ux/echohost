import crypto from 'node:crypto';
export function hashToken(token:string){return crypto.createHash('sha256').update(token).digest('hex')}
export function createApiKey(){return `echo_${crypto.randomBytes(32).toString('base64url')}`}
export function safeKeyPrefix(key:string){return key.slice(0,12)}
