import {z} from 'zod';
export const env=z.object({NODE_ENV:z.enum(['development','test','production']).default('development'),DATABASE_URL:z.string().min(1),JWT_SECRET:z.string().min(32),API_PORT:z.coerce.number().int().positive().default(4000),CORS_ORIGIN:z.string().default('http://localhost:5173'),AGENT_HEARTBEAT_TIMEOUT_SEC:z.coerce.number().int().positive().default(90)}).parse(process.env);
