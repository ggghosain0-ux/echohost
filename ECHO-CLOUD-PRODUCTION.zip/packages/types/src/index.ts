export type Role='OWNER'|'ADMIN'|'STAFF'|'USER'|'READ_ONLY';
export type ServiceType='MINECRAFT'|'WEBSITE'|'BOT'|'VIRTUAL_MACHINE'|'DOCKER_APP';
export type ServiceStatus='PROVISIONING'|'ONLINE'|'OFFLINE'|'ERROR'|'SUSPENDED'|'DELETING';
export type ApiResponse<T>={success:true;data:T}|{success:false;error:{code:string;message:string}};
export * from './models';
