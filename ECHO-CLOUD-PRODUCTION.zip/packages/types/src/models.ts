export interface ResourceRequest { cpu:number; ramMb:number; storageMb:number; }
export interface NodeMetrics { cpuUsed?:number; ramUsedMb?:number; diskUsedMb?:number; }
export interface ServiceAction { action:'start'|'stop'|'restart'|'kill'; serviceId:string; }
