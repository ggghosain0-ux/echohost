# ECHO CLOUD — One Panel. Every Server.

ECHO CLOUD is a cloud-hosting control-plane monorepo for Minecraft, websites, bots, Docker applications and future VPS providers. It is deliberately provider-driven: the control plane never invents infrastructure state.

## Architecture

`Web → Fastify API → PostgreSQL/Redis → Worker → ECHO Agent → isolated workloads / VPS provider`

### Workspace layout

- `apps/web` — responsive React control panel
- `apps/api` — authenticated REST API, RBAC, service/job control plane
- `apps/worker` — background health/job processing
- `apps/agent` — node heartbeat/metrics agent
- `packages/database` — Prisma schema/client/seed
- `packages/auth` — token/key helpers
- `packages/types` — shared contracts
- `packages/ui` — reusable UI primitives
- `packages/config` — validated environment configuration
- `infrastructure/docker` — local/production container orchestration
- `infrastructure/nginx` — reverse proxy
- `migrations` — migration workflow documentation
- `tests` — critical integration/security test location

## Development

1. Copy `.env.example` to `.env` and set a strong `JWT_SECRET` (32+ characters).
2. Start PostgreSQL and Redis: `docker compose -f infrastructure/docker/docker-compose.dev.yml up -d postgres redis`.
3. Install dependencies: `npm install`.
4. Generate Prisma client: `npm run db:generate`.
5. Apply migrations: `npm run db:migrate`.
6. Seed the development admin: `npm run db:seed`.
7. Start web/API: `npm run dev`.

API health: `GET /health`

## Production principles

- Backend authorization is authoritative.
- User service roots must be isolated by the node runtime; never expose the host Docker socket to tenant workloads.
- Node agents authenticate with hashed enrollment tokens and should run behind TLS.
- Providers return explicit unavailable/configuration errors instead of fabricated IPs, metrics or statuses.
- Secrets are supplied through environment/secret management, never source control.
- File APIs must canonicalize paths and reject traversal before touching storage.
- Destructive restore/delete operations require explicit confirmation in the final UI implementation.
- Queue workers are the only place for long-running infrastructure operations.
- Metrics displayed in the panel originate from connected infrastructure or show an unavailable state.

## Production deployment

Build all workspaces with `npm run build`. Put the API/web behind the supplied reverse proxy, run PostgreSQL and Redis with persistent storage, run the worker separately, and install one agent per infrastructure node. Configure real implementations of `ContainerProvider`, `VPSProvider`, and `DNSProvider` before enabling those actions for tenants.

## Verification

`npm run typecheck`
`npm run lint`
`npm run build`
`npm test`

The build/test commands are provided as CI gates. This environment could not complete dependency installation within the execution window, so no claim is made that those commands have passed here.
