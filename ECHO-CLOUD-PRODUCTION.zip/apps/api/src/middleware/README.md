Authentication and authorization middleware lives here. Backend authorization is authoritative; the frontend is never treated as a security boundary.
