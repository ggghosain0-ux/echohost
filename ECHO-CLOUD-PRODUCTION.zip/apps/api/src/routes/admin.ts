import {FastifyInstance} from 'fastify'; import {db} from '@echo/database'; import {requireRoles} from '../middleware/auth';
export async function adminRoutes(app:FastifyInstance){
 app.get('/summary',{preHandler:requireRoles('OWNER','ADMIN','STAFF')},async()=>({success:true,data:{users:await db.user.count(),services:await db.service.count(),nodes:await db.node.count(),backups:await db.backup.count(),deployments:await db.deployment.count()}}));
 app.get('/users',{preHandler:requireRoles('OWNER','ADMIN')},async()=>({success:true,data:await db.user.findMany({select:{id:true,email:true,name:true,role:true,disabledAt:true,createdAt:true},orderBy:{createdAt:'desc'},take:100})}));
}
