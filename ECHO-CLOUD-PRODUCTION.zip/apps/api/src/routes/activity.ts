import {FastifyInstance} from 'fastify'; import {db} from '@echo/database'; import {requireAuth} from '../middleware/auth';
export async function activityRoutes(app:FastifyInstance){app.get('/',{preHandler:requireAuth},async req=>({success:true,data:await db.activityLog.findMany({where:{userId:(req as any).currentUser.id},orderBy:{createdAt:'desc'},take:100})}));}
