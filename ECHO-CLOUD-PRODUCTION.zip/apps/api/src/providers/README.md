Provider interfaces isolate infrastructure integrations from the control plane. Implementations must report unavailable infrastructure rather than fabricate state.
