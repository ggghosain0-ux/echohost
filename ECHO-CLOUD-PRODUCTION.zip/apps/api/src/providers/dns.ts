export type DNSRecord={type:string;name:string;value:string;ttl:number};
export interface DNSProvider{upsert(domain:string,record:DNSRecord):Promise<void>;remove(domain:string,record:DNSRecord):Promise<void>}
export class UnconfiguredDNSProvider implements DNSProvider{async upsert(){throw new Error('DNS_PROVIDER_NOT_CONFIGURED')}async remove(){throw new Error('DNS_PROVIDER_NOT_CONFIGURED')}}
