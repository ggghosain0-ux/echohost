Reusable ECHO CLOUD presentation components live here. Feature pages should compose these components instead of duplicating UI primitives.
