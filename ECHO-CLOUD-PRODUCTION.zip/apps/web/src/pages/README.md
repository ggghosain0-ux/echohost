Route-level feature pages live here. Each page should consume API state through server-state hooks and show loading, empty, error and success states.
