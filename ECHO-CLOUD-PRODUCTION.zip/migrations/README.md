# Database migrations

Prisma migrations are generated from `packages/database/prisma/schema.prisma`.

Production: `npm run db:migrate` after reviewing the migration SQL.
Development: `npx prisma migrate dev --schema packages/database/prisma/schema.prisma`.
