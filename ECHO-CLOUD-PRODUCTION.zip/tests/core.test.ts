import {describe,it,expect} from 'vitest';
import {hashToken,createApiKey,safeKeyPrefix} from '../packages/auth/src/index';
describe('security primitives',()=>{it('hashes tokens deterministically',()=>expect(hashToken('abc')).toBe(hashToken('abc')));it('does not expose an api key prefix as the secret',()=>{const k=createApiKey();expect(k.length).toBeGreaterThan(20);expect(safeKeyPrefix(k)).toBe(k.slice(0,12));});});
