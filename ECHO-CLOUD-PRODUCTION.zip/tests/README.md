# Tests

Critical API and security tests belong here. The repository CI command is `npm test` and intentionally uses `--passWithNoTests` until integration infrastructure is provisioned. No test suite is claimed to pass unless executed in the target environment.
