#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "=== ECHO CLOUD CodeSandbox Installer ==="
command -v node >/dev/null || { echo "Node.js is required"; exit 1; }
node -e 'if(+process.versions.node.split(".")[0]<20)process.exit(1)' || { echo "Node.js 20+ required"; exit 1; }
[ -f .env ] || cp .env.example .env
node scripts/init-node.mjs
echo "Installing dependencies..."
npm install --no-audit --no-fund
echo "Building API, agent and web..."
npm run build:all
echo
echo "ECHO CLOUD installed successfully."
echo "Start: npm run dev"
echo "Preview: port 5173"
echo "API: port 4000"
echo "Agent: port 8080"
