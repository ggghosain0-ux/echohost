#!/usr/bin/env bash
set -euo pipefail
command -v docker >/dev/null || { echo 'Docker is required'; exit 1; }
cp -n .env.example .env || true
docker compose -f infrastructure/docker/docker-compose.dev.yml up -d postgres redis
npm install
npm run db:migrate
npm run db:seed
echo 'ECHO CLOUD development stack is ready.'
