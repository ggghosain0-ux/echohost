#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash scripts/install-vps.sh"; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates build-essential unzip
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
if ! command -v docker >/dev/null; then curl -fsSL https://get.docker.com | sh; fi
systemctl enable --now docker
[ -f .env ] || cp .env.example .env
node scripts/init-node.mjs
sed -i 's/^NODE_ENV=.*/NODE_ENV=production/' .env
npm install
npm run build:all
cat >/etc/systemd/system/echo-cloud-api.service <<UNIT
[Unit]
Description=ECHO CLOUD API
After=network-online.target docker.service
Wants=network-online.target
[Service]
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=/usr/bin/npm run start:api
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
cat >/etc/systemd/system/echo-cloud-agent.service <<UNIT
[Unit]
Description=ECHO CLOUD ECHO AGENT
After=network-online.target docker.service echo-cloud-api.service
Wants=network-online.target
[Service]
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=/usr/bin/npm run start:agent
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
cat >/etc/systemd/system/echo-cloud-web.service <<UNIT
[Unit]
Description=ECHO CLOUD Web UI
After=network-online.target echo-cloud-api.service
[Service]
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=/usr/bin/npm run start:web -- --host 0.0.0.0 --port 5173
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now echo-cloud-api echo-cloud-agent echo-cloud-web
printf '\nECHO CLOUD is running.\nWeb: http://SERVER_IP:5173\nAPI: http://SERVER_IP:4000\nAgent: http://SERVER_IP:8080\n'
