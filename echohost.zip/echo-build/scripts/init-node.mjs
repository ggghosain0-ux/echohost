import os from 'node:os';
import crypto from 'node:crypto';
import fs from 'node:fs';
const p='.env'; let s=fs.existsSync(p)?fs.readFileSync(p,'utf8'):'';
function set(k,v){const r=new RegExp(`^${k}=.*$`,'m');s=r.test(s)?s.replace(r,`${k}=${v}`):s+`\n${k}=${v}`}
set('ECHO_AUTO_NODE','true');
if(!/^JWT_SECRET=(?!replace|$)/m.test(s)) set('JWT_SECRET',crypto.randomBytes(48).toString('hex')); set('ECHO_NODE_HOSTNAME',os.hostname()); set('ECHO_NODE_NAME',process.env.ECHO_NODE_NAME||'Local Node');
if(!/^ECHO_NODE_TOKEN=(?!replace|$)/m.test(s)) set('ECHO_NODE_TOKEN',crypto.randomBytes(32).toString('hex'));
set('ECHO_API_URL',process.env.ECHO_API_URL||'http://127.0.0.1:4000'); set('ECHO_AGENT_URL',process.env.ECHO_AGENT_URL||'http://127.0.0.1:8080');
fs.writeFileSync(p,s.trimStart()+'\n'); console.log('Local node configuration prepared for '+os.hostname());
