export const serviceTypes=['MINECRAFT','WEBSITE','BOT','VIRTUAL_MACHINE','DOCKER_APP'] as const;
export const serviceStatuses=['PROVISIONING','ONLINE','OFFLINE','ERROR','SUSPENDED','DELETING'] as const;
