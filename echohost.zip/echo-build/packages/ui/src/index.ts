export const uiTokens={brand:'ECHO CLOUD',tagline:'One Panel. Every Server.',radius:'18px',surface:'glass'} as const;
