import { db } from './index'; import bcrypt from 'bcryptjs';
async function main(){ const hash=await bcrypt.hash('ChangeMeNow!123',12); await db.user.upsert({where:{email:'admin@echocloud.local'},update:{},create:{email:'admin@echocloud.local',name:'ECHO Admin',passwordHash:hash,role:'ADMIN'}}); console.log('Seeded admin@echocloud.local / ChangeMeNow!123 — change it immediately.'); }
main().finally(()=>db.$disconnect());
