/** Production database boundary. Prisma Client is generated from prisma/schema.prisma during production install. */
export const databaseProvider='postgresql-prisma';
