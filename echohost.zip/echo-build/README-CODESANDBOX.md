# ECHO CLOUD — CodeSandbox mode

## What actually works
- React control panel + Fastify API
- local persistent JSON store
- automatic Local Node registration
- ECHO Agent with authenticated internal API
- real Docker lifecycle for Minecraft, websites, Node/Python bots and Docker apps **when a Docker daemon is available to the sandbox**
- CPU/RAM limits via Docker
- persistent per-service Docker volumes
- real container logs and lifecycle state

## Important infrastructure limitation
CodeSandbox does not guarantee a privileged Docker daemon or a hypervisor. The panel cannot manufacture a Docker daemon or a true VPS/VM inside an unprivileged sandbox. For real production hosting, run ECHO CLOUD on a Linux host with Docker, and connect Proxmox/Libvirt for VM/VPS services.

## Install
```bash
bash scripts/install-codesandbox.sh
npm run dev
```

The dev command starts API, web UI and ECHO Agent together. The API and agent automatically register the local node.
