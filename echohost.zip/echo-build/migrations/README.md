# Database migrations
Production uses PostgreSQL + Prisma. Run `npm run db:migrate` after setting `DATABASE_URL`. The CodeSandbox development adapter intentionally uses a local JSON store because ordinary sandboxes do not provide a durable managed Postgres/Redis/node-agent environment.
