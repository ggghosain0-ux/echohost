# ECHO CLOUD production checklist

1. Set `NODE_ENV=production` and a long random `JWT_SECRET`.
2. Configure PostgreSQL `DATABASE_URL`; run Prisma migrations.
3. Move sessions/queues/rate limits to Redis where appropriate.
4. Run API, worker and web as separate containers/processes.
5. Deploy ECHO AGENT to each node with mTLS or signed request authentication.
6. Implement Docker and hypervisor provider methods inside the agent; never mount the host Docker socket into the public API.
7. Add object storage for backups and enforce retention policies.
8. Connect a DNS provider before reporting DNS changes as applied.
9. Add TLS termination and secure WebSocket authentication at the reverse proxy.
10. Enable centralized logs, metrics, health/readiness checks and alerts.
11. Run the test suite and security review before exposing the panel to users.

The CodeSandbox adapter is deliberately explicit about what it cannot execute. It must not be marketed as a real VPS/Minecraft/Docker provisioning backend until the agent/provider integrations are installed.
