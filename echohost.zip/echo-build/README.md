# ECHO CLOUD

**One Panel. Every Server.**

This repository contains the ECHO CLOUD control plane, ECHO Agent, worker, installers and frontend. It is designed to run as a real hosting control plane on a Linux host with Docker, with provider adapters for infrastructure that requires a hypervisor.

## Default administrator

- Email: `admin@gmail.com`
- Password: `admin12345`

Change these credentials immediately from **Account** / **Admin Center** after first login. Credentials can also be overridden with `DEFAULT_ADMIN_EMAIL` and `DEFAULT_ADMIN_PASSWORD`.

## Real workload model

The panel never fabricates container state. Service provisioning is delegated to an ECHO Agent. On a Docker-capable host the agent creates actual containers and persistent data directories. Minecraft provisioning downloads the selected server JAR, creates the EULA/properties, enables RCON, maps the public port, and starts the Java container. Console commands are delivered through RCON and logs come from Docker.

Websites and bots are also executed as real Docker workloads. The VPS service uses an isolated SSH container as a local development/containers provider; true hardware VMs require a configured Proxmox/Libvirt provider.

## CodeSandbox

CodeSandbox can run the control plane and local agent only when the sandbox permits the required processes/network. It cannot grant Docker or hypervisor privileges that the platform does not expose. For real Internet-facing Minecraft, website and bot workloads, connect a Docker-capable Linux node.

## Production

Use PostgreSQL/Redis/object storage and a real reverse proxy for a multi-node production deployment. The included file-backed store is intentionally a bootstrap/dev store; replace it with the database package/provider before exposing a multi-user installation to the public Internet.

## Verification

Run `npm install`, `npm run typecheck`, `npm run build:all`, and `npm test` in an environment with network access. This environment could not complete dependency installation, so no claim is made that those commands were executed successfully here.
