Middleware layer: authentication, role authorization, request security and future CSRF/session guards.
