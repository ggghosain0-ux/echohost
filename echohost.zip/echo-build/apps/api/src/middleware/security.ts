/** Central security notes for production adapters. Keep secrets server-side; validate all input; scope every resource by owner/role; never expose raw provider credentials. */
export const securityPolicy={maxBodyBytes:'2mb',fileTraversal:'deny',dockerSocket:'agent-only',secretLogging:'deny',websocketAuth:'required'} as const;
