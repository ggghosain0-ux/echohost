import {FastifyReply,FastifyRequest} from 'fastify';
export async function requireAuth(req:FastifyRequest,reply:FastifyReply){try{await req.jwtVerify();}catch{return reply.code(401).send({success:false,error:{code:'UNAUTHORIZED',message:'Authentication required'}})}}
export function userId(req:FastifyRequest){return (req.user as {sub:string}).sub;}
export function role(req:FastifyRequest){return (req.user as {role:string}).role;}
export function requireRole(...roles:string[]){return async(req:FastifyRequest,reply:FastifyReply)=>{if(!roles.includes(role(req)))return reply.code(403).send({success:false,error:{code:'FORBIDDEN',message:'Insufficient permission'}})}}
