import { ServiceType } from '../types';
import { LocalDNSProvider, LocalBackupProvider } from './local';
import { ServiceProvider, VPSProvider, DNSProvider, BackupProvider } from './types';
import { AgentProvider } from './agent';
import { db } from '../store';

class UnavailableProvider implements ServiceProvider {
  readonly name='unavailable';
  private fail():never { throw new Error('NODE_AGENT_REQUIRED'); }
  async provision(_:any){this.fail()} async start(_:any){this.fail()} async stop(_:any){this.fail()} async restart(_:any){this.fail()} async remove(_:any){this.fail()} async logs(_:any){this.fail()}
}
export function providerFor(type: ServiceType, nodeId?: string|null): ServiceProvider {
  if (type==='VIRTUAL_MACHINE') {
    const n=nodeId ? db().nodes.find(x=>x.id===nodeId) : undefined;
    return n?.agentUrl && n.token ? new AgentProvider(n) : new UnavailableProvider();
  }
  const n=nodeId ? db().nodes.find(x=>x.id===nodeId) : db().nodes.find(x=>x.status==='ONLINE' && x.agentUrl);
  return n?.agentUrl && n.token ? new AgentProvider(n) : new UnavailableProvider();
}
export const vpsProvider: VPSProvider = new UnavailableProvider() as VPSProvider;
export const dnsProvider: DNSProvider = new LocalDNSProvider();
export const backupProvider: BackupProvider = new LocalBackupProvider();
