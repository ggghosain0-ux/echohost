import {Service} from '../types';
export interface ServiceProvider { readonly name:string; provision(service:Service):Promise<void>; start(service:Service):Promise<void>; stop(service:Service):Promise<void>; restart(service:Service):Promise<void>; remove(service:Service):Promise<void>; logs(service:Service):Promise<string[]>; }
export interface VPSProvider extends ServiceProvider { reinstall(service:Service, image:string):Promise<void>; snapshot(service:Service,name:string):Promise<void>; }
export interface DNSProvider { createRecord(domain:string,record:{type:string;name:string;value:string;ttl:number}):Promise<void>; deleteRecord(domain:string,id:string):Promise<void>; }
export interface BackupProvider { create(service:Service):Promise<{key:string;sizeMb:number}>; restore(service:Service,key:string):Promise<void>; remove(key:string):Promise<void>; }
