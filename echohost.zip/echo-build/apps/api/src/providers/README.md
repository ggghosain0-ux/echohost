Provider layer: infrastructure adapters. Public API code must use interfaces here rather than directly touching Docker, hypervisors, DNS credentials or host filesystems.
