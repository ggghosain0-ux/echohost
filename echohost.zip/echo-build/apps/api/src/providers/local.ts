import {Service} from '../types';
import {ServiceProvider,VPSProvider,DNSProvider,BackupProvider} from './types';
export class LocalServiceProvider implements ServiceProvider { readonly name='local-development'; async provision(_:Service){return} async start(_:Service){return} async stop(_:Service){return} async restart(_:Service){return} async remove(_:Service){return} async logs(_:Service){return ['Local development adapter: no host process is attached.','Connect an ECHO AGENT in production to execute real lifecycle operations.'];} }
export class LocalVPSProvider extends LocalServiceProvider implements VPSProvider { async reinstall(_:Service,__:string){return} async snapshot(_:Service,__:string){return} }
export class LocalDNSProvider implements DNSProvider { async createRecord(_:string,__:any){return} async deleteRecord(_:string,__:string){return} }
export class LocalBackupProvider implements BackupProvider { async create(service:Service){return {key:`dev/${service.id}/${Date.now()}`,sizeMb:0}} async restore(_:Service,__:string){return} async remove(_:string){return} }
