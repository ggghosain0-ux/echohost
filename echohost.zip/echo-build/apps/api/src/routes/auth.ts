import {FastifyInstance} from 'fastify';
import bcrypt from 'bcryptjs';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {db,transaction} from '../store';
import {requireAuth,userId} from '../middleware/auth';

const credentials=z.object({email:z.string().email().transform(v=>v.toLowerCase()),password:z.string().min(8).max(200)});
const safe=(u:any)=>({id:u.id,name:u.name,email:u.email,role:u.role,createdAt:u.createdAt,disabled:!!u.disabledAt,mustChangePassword:!!u.mustChangePassword});
function issue(app:FastifyInstance,u:any){return app.jwt.sign({sub:u.id,role:u.role});}

export async function authRoutes(app:FastifyInstance){
 app.post('/api/auth/register',async(req,reply)=>{
   const b=z.object({name:z.string().min(2).max(80),email:z.string().email(),password:z.string().min(8).max(200)}).parse(req.body);
   const email=b.email.toLowerCase(); if(db().users.some(u=>u.email===email)) return reply.code(409).send({success:false,error:{code:'EMAIL_EXISTS',message:'Email is already registered'}});
   const u:any={id:randomUUID(),name:b.name,email,passwordHash:await bcrypt.hash(b.password,12),role:db().users.length?'USER':'OWNER',createdAt:new Date().toISOString(),mustChangePassword:false};
   await transaction(s=>s.users.push(u)); return reply.code(201).send({success:true,data:{token:issue(app,u),user:safe(u)}});
 });
 app.post('/api/auth/login',async(req,reply)=>{
   const b=credentials.parse(req.body); const u=db().users.find(x=>x.email===b.email);
   if(!u||u.disabledAt||!(await bcrypt.compare(b.password,u.passwordHash))) return reply.code(401).send({success:false,error:{code:'INVALID_CREDENTIALS',message:'Invalid email or password'}});
   await transaction(s=>s.activities.unshift({id:randomUUID(),userId:u.id,action:'LOGIN',resourceType:'USER',resourceId:u.id,createdAt:new Date().toISOString()}));
   return {success:true,data:{token:issue(app,u),user:safe(u)}};
 });
 app.get('/api/auth/me',{preHandler:requireAuth},async(req,reply)=>{const u=db().users.find(x=>x.id===userId(req));if(!u)return reply.code(401).send({success:false,error:{code:'USER_NOT_FOUND',message:'User not found'}});return {success:true,data:safe(u)}});
 app.post('/api/auth/logout',{preHandler:requireAuth},async(req)=>{await transaction(s=>s.activities.unshift({id:randomUUID(),userId:userId(req),action:'LOGOUT',resourceType:'USER',resourceId:userId(req),createdAt:new Date().toISOString()}));return {success:true,data:{ok:true}}});
 app.post('/api/auth/change-password',{preHandler:requireAuth},async(req,reply)=>{const b=credentials.pick({password:true}).extend({currentPassword:z.string().min(1)}).parse(req.body);const u=db().users.find(x=>x.id===userId(req));if(!u||!(await bcrypt.compare(b.currentPassword,u.passwordHash)))return reply.code(400).send({success:false,error:{code:'INVALID_PASSWORD',message:'Current password is incorrect'}});u.passwordHash=await bcrypt.hash(b.password,12);u.mustChangePassword=false;await transaction(s=>s.activities.unshift({id:randomUUID(),userId:u.id,action:'PASSWORD_CHANGED',resourceType:'USER',resourceId:u.id,createdAt:new Date().toISOString()}));return {success:true,data:{ok:true}}});
}
