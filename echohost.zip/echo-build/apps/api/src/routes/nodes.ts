import {FastifyInstance} from 'fastify';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {db,transaction} from '../store';
import {requireAuth,requireRole,userId} from '../middleware/auth';

const nodeInput=z.object({name:z.string().trim().min(2).max(80),hostname:z.string().trim().min(1).max(255),ip:z.string().optional(),agentUrl:z.string().url().optional(),cpuTotal:z.number().positive().optional(),ramTotalMb:z.number().int().positive().optional(),diskTotalMb:z.number().int().positive().optional(),token:z.string().min(16).max(256).optional()});

export async function nodeRoutes(app:FastifyInstance){
 app.get('/api/nodes',{preHandler:requireAuth},async()=>({success:true,data:db().nodes.map(({token,...n})=>n)}));
 app.post('/api/nodes',{preHandler:[requireAuth,requireRole('OWNER','ADMIN')]},async(req,reply)=>{
   const b=nodeInput.parse(req.body);
   if(db().nodes.some(n=>n.hostname===b.hostname)) return reply.code(409).send({success:false,error:{code:'NODE_EXISTS',message:'Node already exists'}});
   const n={id:randomUUID(),name:b.name,hostname:b.hostname,ip:b.ip,token:b.token,status:'OFFLINE' as const,cpuTotal:b.cpuTotal,ramTotalMb:b.ramTotalMb,diskTotalMb:b.diskTotalMb,agentUrl:b.agentUrl};
   await transaction(s=>{s.nodes.push(n);s.activities.unshift({id:randomUUID(),userId:userId(req),action:'NODE_CREATED',resourceType:'NODE',resourceId:n.id,createdAt:new Date().toISOString()})});
   const {token,...safe}=n; return reply.code(201).send({success:true,data:safe});
 });
 app.post('/api/agent/register',async(req,reply)=>{
   const b=z.object({token:z.string().min(16),name:z.string().trim().min(2).max(80),hostname:z.string().trim().min(1).max(255),ip:z.string().optional(),agentUrl:z.string().url().optional(),cpuTotal:z.number().positive().optional(),ramTotalMb:z.number().int().positive().optional(),diskTotalMb:z.number().int().positive().optional()}).parse(req.body);
   const expected=process.env.ECHO_NODE_TOKEN||'';
   if(!expected || b.token!==expected) return reply.code(401).send({success:false,error:{code:'AGENT_UNAUTHORIZED',message:'Invalid node token'}});
   let n=db().nodes.find(x=>x.hostname===b.hostname);
   if(!n){ n={id:randomUUID(),name:b.name,hostname:b.hostname,ip:b.ip,token:b.token,status:'ONLINE',cpuTotal:b.cpuTotal,ramTotalMb:b.ramTotalMb,diskTotalMb:b.diskTotalMb,agentUrl:b.agentUrl,lastHeartbeat:new Date().toISOString()}; await transaction(s=>{s.nodes.push(n)}); }
   else { n.token=b.token;n.status='ONLINE';n.ip=b.ip;n.agentUrl=b.agentUrl||n.agentUrl;n.cpuTotal=b.cpuTotal??n.cpuTotal;n.ramTotalMb=b.ramTotalMb??n.ramTotalMb;n.diskTotalMb=b.diskTotalMb??n.diskTotalMb;n.lastHeartbeat=new Date().toISOString();await transaction(()=>{}); }
   return {success:true,data:{nodeId:n.id,heartbeatSeconds:30}};
 });
 app.post('/api/agent/heartbeat',async(req,reply)=>{
   const b=z.object({nodeId:z.string().uuid(),token:z.string().min(16),cpuUsed:z.number().nonnegative().optional(),ramUsedMb:z.number().int().nonnegative().optional(),diskUsedMb:z.number().int().nonnegative().optional()}).parse(req.body);
   const n=db().nodes.find(x=>x.id===b.nodeId);
   if(!n || !n.token || n.token!==b.token) return reply.code(401).send({success:false,error:{code:'AGENT_UNAUTHORIZED',message:'Invalid node credentials'}});
   n.status='ONLINE';n.cpuUsed=b.cpuUsed;n.ramUsedMb=b.ramUsedMb;n.diskUsedMb=b.diskUsedMb;n.lastHeartbeat=new Date().toISOString();await transaction(()=>{});
   return {success:true,data:{accepted:true,nextHeartbeatSeconds:30}};
 });
}
