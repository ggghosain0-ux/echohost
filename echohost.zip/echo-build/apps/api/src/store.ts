import {promises as fs} from 'node:fs'; import path from 'node:path'; import bcrypt from 'bcryptjs'; import {randomUUID} from 'node:crypto'; import {Store} from './types';
const dir=path.resolve(process.env.ECHO_DATA_DIR||'.echo-data'); const file=path.join(dir,'store.json');
const empty:Store={users:[],services:[],nodes:[],activities:[],notifications:[],domains:[],backups:[],apiKeys:[]}; let store:Store=structuredClone(empty); let writing=Promise.resolve();
export async function initStore(){await fs.mkdir(dir,{recursive:true});try{store=JSON.parse(await fs.readFile(file,'utf8'));}catch{await saveStore(store)}
 if(!store.apiKeys) store.apiKeys=[]; if(!store.notifications) store.notifications=[];
 const adminEmail=(process.env.DEFAULT_ADMIN_EMAIL||'admin@gmail.com').toLowerCase(),adminPassword=process.env.DEFAULT_ADMIN_PASSWORD||'admin12345';
 if(!store.users.length){const u:any={id:randomUUID(),name:'Administrator',email:adminEmail,passwordHash:await bcrypt.hash(adminPassword,12),role:'OWNER',createdAt:new Date().toISOString(),mustChangePassword:false};store.users.push(u);store.activities.unshift({id:randomUUID(),userId:u.id,action:'DEFAULT_ADMIN_CREATED',resourceType:'USER',resourceId:u.id,createdAt:new Date().toISOString()});await saveStore(store)}
}
export function db(){return store} export async function saveStore(next=store){store=next;writing=writing.then(()=>fs.writeFile(file,JSON.stringify(store,null,2),'utf8'));await writing} export async function transaction(fn:(s:Store)=>unknown|Promise<unknown>){await fn(store);await saveStore()}
