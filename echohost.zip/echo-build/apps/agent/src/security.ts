export const agentSecurity={mTLS:true,signedRequests:true,allowListedActions:['CREATE','START','STOP','RESTART','DELETE','BACKUP','RESTORE','DEPLOY','METRICS']} as const;
