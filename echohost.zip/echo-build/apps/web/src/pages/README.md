Route-level pages live here. Unimplemented infrastructure modules intentionally show a transparent provider-integration state instead of fake server data.
