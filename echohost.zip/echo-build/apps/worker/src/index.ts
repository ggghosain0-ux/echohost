import 'dotenv/config';
/** ECHO worker: production deployments should run this as a separate process/container. Jobs: backups, schedules, deployments, health checks, cleanup, SSL renewal and metrics aggregation. */
const interval=Number(process.env.WORKER_INTERVAL_MS||30000);console.log(`ECHO CLOUD worker started; polling every ${interval}ms`);setInterval(()=>console.log(new Date().toISOString(),'worker heartbeat'),interval);
