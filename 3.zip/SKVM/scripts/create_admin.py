#!/usr/bin/env python3
"""
Manually (re)create or reset the SKVM admin account.
Usage: python scripts/create_admin.py admin@example.com 'NewPassword123'
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app
from app.extensions import db
from app.models import User
from app.auth.utils import hash_password


def main():
    if len(sys.argv) != 3:
        print("Usage: python scripts/create_admin.py <email> <password>")
        sys.exit(1)
    email, password = sys.argv[1], sys.argv[2]
    if len(password) < 8:
        print("Password must be at least 8 characters.")
        sys.exit(1)

    app = create_app()
    with app.app_context():
        user = User.query.filter_by(email=email).first()
        if user:
            user.password_hash = hash_password(password)
            user.role = "admin"
            print(f"Updated existing user {email} -> admin, password reset.")
        else:
            user = User(email=email, password_hash=hash_password(password), role="admin")
            db.session.add(user)
            print(f"Created new admin user {email}.")
        db.session.commit()


if __name__ == "__main__":
    main()
