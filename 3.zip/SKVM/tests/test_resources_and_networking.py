import pytest


def test_resource_validation_ok_within_capacity(app):
    with app.app_context():
        from app.models import LocalNode
        from app.extensions import db
        from app.services.resources import validate_request

        node = LocalNode.query.first()
        node.cpu_total = 8
        node.ram_total_mb = 16384
        node.disk_total_gb = 200
        db.session.commit()

        assert validate_request(cpu=2, ram_mb=2048, disk_gb=20) is True


def test_resource_validation_rejects_excess_cpu(app):
    with app.app_context():
        from app.models import LocalNode
        from app.extensions import db
        from app.services.resources import validate_request, ResourceError

        node = LocalNode.query.first()
        node.cpu_total = 4
        db.session.commit()

        with pytest.raises(ResourceError):
            validate_request(cpu=999, ram_mb=512, disk_gb=5)


def test_port_allocator_returns_unique_ports(app):
    with app.app_context():
        from app.services.networking import allocate_port
        from app.models import VM, VMState
        from app.extensions import db
        from app.models import User

        user = User.query.filter_by(role="admin").first()
        p1 = allocate_port()
        vm = VM(
            id="vm-1", name="a", owner_id=user.id, engine="docker", os_key="ubuntu-22.04",
            status=VMState.READY, username="ubuntu", password_hash="x", cpu=1, ram_mb=512,
            disk_gb=5, ssh_port=p1,
        )
        db.session.add(vm)
        db.session.commit()

        p2 = allocate_port()
        assert p1 != p2
