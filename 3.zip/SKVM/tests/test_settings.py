def test_user_cannot_update_settings(user_client):
    resp = user_client.put("/api/settings", json={"panel_name": "Hacked"})
    assert resp.status_code == 403


def test_admin_can_update_panel_name(app, admin_client):
    resp = admin_client.put("/api/settings", json={"panel_name": "MyPanel"})
    assert resp.status_code == 200
    with app.app_context():
        from app.models import Settings

        assert Settings.query.first().panel_name == "MyPanel"


def test_engine_setting_persists_and_does_not_convert_existing_vms(app, admin_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    admin_client.post(
        "/api/vms",
        json={"name": "docker-vm", "os": "ubuntu-20.04", "ram": 512, "cpu": 1, "disk": 5,
              "username": "ubuntu", "password": "password123"},
    )

    admin_client.put("/api/settings", json={"container_engine": "lxc"})

    with app.app_context():
        from app.models import VM, Settings

        vm = VM.query.filter_by(name="docker-vm").first()
        assert vm.engine == "docker"  # unchanged after engine switch
        assert Settings.query.first().container_engine == "lxc"


def test_invalid_engine_rejected(admin_client):
    resp = admin_client.put("/api/settings", json={"container_engine": "vmware"})
    assert resp.status_code == 400


def test_google_auth_not_configured_by_default(client):
    resp = client.get("/api/settings")
    assert resp.status_code == 401  # requires auth, but exercised via login below


def test_settings_public_dict_hides_secrets(app):
    with app.app_context():
        from app.models import Settings
        from app.extensions import db

        s = Settings.query.first()
        s.google_client_secret = "super-secret"
        db.session.commit()
        public = s.to_public_dict()
        assert "google_client_secret" not in public
