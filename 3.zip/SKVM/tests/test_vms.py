def test_user_cannot_create_vm_via_api(app, user_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    resp = user_client.post(
        "/api/vms",
        json={
            "name": "my-vm",
            "os": "ubuntu-22.04",
            "ram": 1024,
            "cpu": 1,
            "disk": 5,
            "username": "ubuntu",
            "password": "password123",
        },
    )
    assert resp.status_code == 403

    with app.app_context():
        from app.models import VM

        assert VM.query.count() == 0


def test_admin_can_create_vm_via_api(app, admin_client, monkeypatch):
    from app.services import jobs

    called = {}
    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: called.setdefault("id", vm_id))

    resp = admin_client.post(
        "/api/vms",
        json={
            "name": "admin-vm",
            "os": "ubuntu-22.04",
            "ram": 1024,
            "cpu": 1,
            "disk": 5,
            "username": "ubuntu",
            "password": "password123",
        },
    )
    assert resp.status_code == 202
    assert "id" in called

    with app.app_context():
        from app.models import VM

        assert VM.query.count() == 1


def test_unauthenticated_cannot_create_vm(client):
    resp = client.post(
        "/api/vms",
        json={"name": "x", "os": "ubuntu-22.04", "ram": 512, "cpu": 1, "disk": 5,
              "username": "ubuntu", "password": "password123"},
    )
    assert resp.status_code == 401


def test_resource_validation_rejects_oversized_request(app, admin_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    with app.app_context():
        from app.models import LocalNode

        node = LocalNode.query.first()
        node.ram_total_mb = 2048
        from app.extensions import db

        db.session.commit()

    resp = admin_client.post(
        "/api/vms",
        json={
            "name": "too-big",
            "os": "ubuntu-22.04",
            "ram": 999999,
            "cpu": 1,
            "disk": 5,
            "username": "ubuntu",
            "password": "password123",
        },
    )
    assert resp.status_code == 400
    assert "exceeds" in resp.get_json()["error"]


def test_user_cannot_see_another_users_vm(app, admin_client, user_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    resp = admin_client.post(
        "/api/vms",
        json={"name": "admin-only-vm", "os": "debian-12", "ram": 512, "cpu": 1, "disk": 5,
              "username": "ubuntu", "password": "password123"},
    )
    vm_id = resp.get_json()["id"]

    resp = user_client.get(f"/api/vms/{vm_id}")
    assert resp.status_code == 404  # not found rather than leaking existence


def test_invalid_os_rejected(admin_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    resp = admin_client.post(
        "/api/vms",
        json={"name": "bad-os", "os": "windows-11", "ram": 512, "cpu": 1, "disk": 5,
              "username": "ubuntu", "password": "password123"},
    )
    assert resp.status_code == 400


def test_invalid_vm_name_rejected(admin_client, monkeypatch):
    from app.services import jobs

    monkeypatch.setattr(jobs, "enqueue_provision", lambda vm_id: None)

    resp = admin_client.post(
        "/api/vms",
        json={"name": "Not Valid!!", "os": "ubuntu-22.04", "ram": 512, "cpu": 1, "disk": 5,
              "username": "ubuntu", "password": "password123"},
    )
    assert resp.status_code == 400
