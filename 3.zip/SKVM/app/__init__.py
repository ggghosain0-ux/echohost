import os

from flask import Flask, render_template

from app.config import Config
from app.extensions import db, login_manager, limiter


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db_uri = app.config["SQLALCHEMY_DATABASE_URI"]
    if db_uri.startswith("sqlite:///"):
        db_path = db_uri.replace("sqlite:///", "", 1)
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    limiter.init_app(app)

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    # Blueprints
    from app.auth import auth_bp
    from app.routes.public import public_bp
    from app.routes.admin import admin_bp
    from app.routes.user import user_bp
    from app.api import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(public_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(api_bp)

    @app.context_processor
    def inject_settings():
        from app.models import Settings

        settings = Settings.query.first()
        return {"panel_settings": settings}

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403, message="Forbidden"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="Not found"), 404

    with app.app_context():
        db.create_all()
        _bootstrap(app)

    from app.services import jobs

    jobs.init_app(app)

    return app


def _bootstrap(app):
    """Idempotent first-run setup: default admin, default settings row,
    local node detection (spec sections 7, 18)."""
    from app.models import User, Settings
    from app.auth.utils import hash_password
    from app.services.system import sync_local_node

    if Settings.query.first() is None:
        db.session.add(Settings(id=1, panel_name="SKVM", container_engine="docker"))
        db.session.commit()

    if User.query.filter_by(role="admin").first() is None:
        admin_email = app.config["BOOTSTRAP_ADMIN_EMAIL"]
        admin_password = app.config["BOOTSTRAP_ADMIN_PASSWORD"]
        db.session.add(
            User(
                email=admin_email,
                password_hash=hash_password(admin_password),
                role="admin",
                must_change_password=True,
            )
        )
        db.session.commit()
        app.logger.warning(
            "Bootstrap admin account created (%s). Log in and change the password immediately.",
            admin_email,
        )

    sync_local_node()
