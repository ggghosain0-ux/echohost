import os
import secrets
import uuid

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from app.extensions import db
from app.auth.decorators import admin_required
from app.auth.utils import hash_password, verify_password
from app.models import User, VM, VMState, OS_CATALOG, LocalNode, Settings, ActivityLog, ApiKey
from app.services import resources as resource_service
from app.services.validation import (
    ValidationError,
    validate_vm_name,
    validate_username,
    validate_hostname,
    validate_os_key,
    validate_password,
    validate_int_range,
)
from app.services.system import detect_capabilities
from app.services import jobs

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def _log(action, target=None, status="ok", message=""):
    db.session.add(
        ActivityLog(user_id=current_user.id, action=action, target=target, status=status, message=message)
    )
    db.session.commit()


@admin_bp.before_request
@login_required
@admin_required
def _guard():
    """Every route in this blueprint requires an authenticated admin."""
    pass


@admin_bp.route("/dashboard")
def dashboard():
    node = LocalNode.query.first()
    settings = Settings.query.first()
    total_users = User.query.count()
    total_vms = VM.query.filter(VM.status != VMState.DELETED).count()
    running = VM.query.filter_by(status=VMState.RUNNING).count()
    stopped = VM.query.filter_by(status=VMState.STOPPED).count()
    failed = VM.query.filter_by(status=VMState.FAILED).count()
    recent_logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(15).all()
    caps = detect_capabilities()
    return render_template(
        "admin/dashboard.html",
        node=node,
        settings=settings,
        total_users=total_users,
        total_vms=total_vms,
        running=running,
        stopped=stopped,
        failed=failed,
        recent_logs=recent_logs,
        caps=caps,
    )


@admin_bp.route("/vms")
def vm_list():
    vms = VM.query.filter(VM.status != VMState.DELETED).order_by(VM.created_at.desc()).all()
    return render_template("admin/vm_list.html", vms=vms)


@admin_bp.route("/vms/create", methods=["GET", "POST"])
def create_vm():
    settings = Settings.query.first()
    node = LocalNode.query.first()

    if request.method == "POST":
        try:
            name = validate_vm_name(request.form.get("name", ""))
            os_key = validate_os_key(request.form.get("os", ""))
            ram_mb = validate_int_range(request.form.get("ram", 512), 128, 262144, "RAM")
            cpu = validate_int_range(request.form.get("cpu", 1), 1, 64, "CPU")
            disk_gb = validate_int_range(request.form.get("disk", 5), 1, 4096, "Disk")
            username = validate_username(request.form.get("username", "ubuntu"))
            password = validate_password(request.form.get("password", ""))
            hostname = validate_hostname(request.form.get("hostname", ""), fallback=name)

            resource_service.validate_request(cpu, ram_mb, disk_gb)

            engine = settings.container_engine
            vm = VM(
                name=name,
                owner_id=current_user.id,
                engine=engine,
                os_key=os_key,
                status=VMState.PENDING,
                username=username,
                password_hash=hash_password(password),
                hostname=hostname,
                cpu=cpu,
                ram_mb=ram_mb,
                disk_gb=disk_gb,
            )
            db.session.add(vm)
            db.session.commit()

            # Plaintext password is passed through the in-memory job queue only
            # (never written to the database -- only its argon2 hash is, above)
            # so the background worker can set the real OS account password.
            jobs.enqueue_provision(vm.id, password_plain=password)

            _log("vm.create_requested", vm.id, "ok", f"engine={engine} os={os_key}")
            flash(f"VM '{name}' queued for provisioning.", "success")
            return redirect(url_for("admin.vm_detail", vm_id=vm.id))
        except (ValidationError, resource_service.ResourceError) as exc:
            flash(str(exc), "error")

    return render_template(
        "admin/create_vm.html", settings=settings, node=node, os_catalog=OS_CATALOG
    )


@admin_bp.route("/vms/<vm_id>")
def vm_detail(vm_id):
    vm = VM.query.get_or_404(vm_id)
    from app.services.status_sync import sync_vm_status

    sync_vm_status(vm)
    return render_template("admin/vm_detail.html", vm=vm, is_admin_view=True)


@admin_bp.route("/vms/<vm_id>/<action>", methods=["POST"])
def vm_action(vm_id, action):
    vm = VM.query.get_or_404(vm_id)
    if action in ("start", "stop", "restart"):
        jobs.enqueue_lifecycle(vm_id, action)
        flash(f"{action.title()} requested.", "success")
    elif action == "delete":
        jobs.enqueue_lifecycle(vm_id, "delete")
        flash("Deletion requested.", "success")
    elif action == "tmate":
        jobs.enqueue_tmate_regenerate(vm_id)
        flash("Regenerating tmate session.", "success")
    else:
        flash("Unknown action.", "error")
    _log(f"vm.{action}_requested", vm_id)
    return redirect(url_for("admin.vm_detail", vm_id=vm_id))


@admin_bp.route("/api-keys", methods=["GET", "POST"])
def api_keys():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()[:64] or "unnamed"
        raw_key = "skvm_" + secrets.token_urlsafe(32)
        key_hash = hash_password(raw_key)
        key = ApiKey(
            user_id=current_user.id,
            name=name,
            key_prefix=raw_key[:12],
            key_hash=key_hash,
            is_admin_key=True,
        )
        db.session.add(key)
        db.session.commit()
        _log("apikey.created", key.id)
        flash("API key created. Copy it now -- it will not be shown again.", "success")
        return render_template(
            "admin/api_keys.html",
            keys=ApiKey.query.order_by(ApiKey.created_at.desc()).all(),
            new_key=raw_key,
        )

    keys = ApiKey.query.order_by(ApiKey.created_at.desc()).all()
    return render_template("admin/api_keys.html", keys=keys, new_key=None)


@admin_bp.route("/api-keys/<key_id>/revoke", methods=["POST"])
def revoke_api_key(key_id):
    key = ApiKey.query.get_or_404(key_id)
    key.revoked = True
    db.session.commit()
    _log("apikey.revoked", key_id)
    flash("API key revoked.", "success")
    return redirect(url_for("admin.api_keys"))


@admin_bp.route("/settings", methods=["GET", "POST"])
def settings_page():
    settings = Settings.query.first()
    node = LocalNode.query.first()

    if request.method == "POST":
        form_type = request.form.get("form_type")

        if form_type == "branding":
            settings.panel_name = (request.form.get("panel_name") or "SKVM")[:64]
            settings.discord_url = request.form.get("discord_url") or None
            theme = request.form.get("theme", "dark")
            if theme in ("dark", "light", "system"):
                settings.theme = theme

            logo = request.files.get("logo")
            if logo and logo.filename:
                ext = logo.filename.rsplit(".", 1)[-1].lower()
                if ext in current_app.config["ALLOWED_LOGO_EXTENSIONS"]:
                    filename = f"logo_{uuid.uuid4().hex}.{ext}"
                    dest = os.path.join(current_app.config["UPLOAD_FOLDER"], secure_filename(filename))
                    logo.save(dest)
                    settings.logo_path = f"uploads/{filename}"
                else:
                    flash("Unsupported logo file type.", "error")

            db.session.commit()
            _log("settings.branding_updated")
            flash("Branding updated.", "success")

        elif form_type == "engine":
            engine = request.form.get("container_engine")
            if engine not in ("docker", "lxc"):
                flash("Invalid engine.", "error")
            else:
                settings.container_engine = engine
                db.session.commit()
                _log("settings.engine_changed", message=f"engine={engine}")
                flash(
                    f"Container engine set to {engine.upper()}. Existing VMs keep their original engine.",
                    "success",
                )

        elif form_type == "google_auth":
            settings.google_auth_enabled = bool(request.form.get("google_auth_enabled"))
            settings.google_client_id = request.form.get("google_client_id") or None
            settings.google_client_secret = request.form.get("google_client_secret") or None
            settings.google_redirect_uri = request.form.get("google_redirect_uri") or None
            settings.firebase_project_id = request.form.get("firebase_project_id") or None
            settings.firebase_api_key = request.form.get("firebase_api_key") or None
            settings.firebase_auth_domain = request.form.get("firebase_auth_domain") or None
            settings.firebase_app_id = request.form.get("firebase_app_id") or None
            db.session.commit()
            _log("settings.google_auth_updated")
            flash("Google authentication settings saved.", "success")

        elif form_type == "admin_account":
            current_password = request.form.get("current_password") or ""
            new_email = (request.form.get("new_email") or "").strip().lower()
            new_password = request.form.get("new_password") or ""
            confirm_password = request.form.get("confirm_password") or ""

            if not verify_password(current_user.password_hash, current_password):
                flash("Current password is incorrect.", "error")
            else:
                if new_email and new_email != current_user.email:
                    if User.query.filter_by(email=new_email).first():
                        flash("That email is already in use.", "error")
                        return redirect(url_for("admin.settings_page"))
                    current_user.email = new_email
                if new_password:
                    if len(new_password) < 8:
                        flash("New password must be at least 8 characters.", "error")
                        return redirect(url_for("admin.settings_page"))
                    if new_password != confirm_password:
                        flash("New password and confirmation do not match.", "error")
                        return redirect(url_for("admin.settings_page"))
                    current_user.password_hash = hash_password(new_password)
                    current_user.must_change_password = False
                db.session.commit()
                _log("settings.admin_account_updated")
                flash("Admin account updated.", "success")

        return redirect(url_for("admin.settings_page"))

    caps = detect_capabilities()
    return render_template("admin/settings.html", settings=settings, node=node, caps=caps)


@admin_bp.route("/users")
def users():
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=all_users)
