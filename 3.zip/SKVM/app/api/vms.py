from flask import Blueprint, request, jsonify, g

from app.extensions import db
from app.models import VM, VMState, Settings, ActivityLog
from app.auth.utils import hash_password
from app.api.auth import api_login_required, api_admin_required
from app.services import resources as resource_service
from app.services.validation import (
    ValidationError,
    validate_vm_name,
    validate_username,
    validate_hostname,
    validate_os_key,
    validate_password,
    validate_int_range,
)
from app.services import jobs

vms_bp = Blueprint("api_vms", __name__)


def _log(user_id, action, target=None, status="ok", message=""):
    db.session.add(ActivityLog(user_id=user_id, action=action, target=target, status=status, message=message))
    db.session.commit()


@vms_bp.route("/vms", methods=["GET"])
@api_login_required
def list_vms():
    user = g.api_user
    query = VM.query.filter(VM.status != VMState.DELETED)
    if not user.is_admin:
        query = query.filter_by(owner_id=user.id)
    vms = query.order_by(VM.created_at.desc()).all()
    return jsonify([v.to_dict(include_owner=user.is_admin) for v in vms])


@vms_bp.route("/vms", methods=["POST"])
@api_admin_required
def create_vm():
    """Admin-only, enforced server-side regardless of what the UI shows (spec 11)."""
    data = request.get_json(silent=True) or {}
    try:
        name = validate_vm_name(data.get("name", ""))
        os_key = validate_os_key(data.get("os", ""))
        ram_mb = validate_int_range(data.get("ram", 512), 128, 262144, "RAM")
        cpu = validate_int_range(data.get("cpu", 1), 1, 64, "CPU")
        disk_gb = validate_int_range(data.get("disk", 5), 1, 4096, "Disk")
        username = validate_username(data.get("username", "ubuntu"))
        password = validate_password(data.get("password", ""))
        hostname = validate_hostname(data.get("hostname", ""), fallback=name)

        resource_service.validate_request(cpu, ram_mb, disk_gb)

        settings = Settings.query.first()
        vm = VM(
            name=name,
            owner_id=g.api_user.id,
            engine=settings.container_engine,
            os_key=os_key,
            status=VMState.PENDING,
            username=username,
            password_hash=hash_password(password),
            hostname=hostname,
            cpu=cpu,
            ram_mb=ram_mb,
            disk_gb=disk_gb,
        )
        db.session.add(vm)
        db.session.commit()
        jobs.enqueue_provision(vm.id, password_plain=password)
        _log(g.api_user.id, "vm.create_requested", vm.id)
        return jsonify(vm.to_dict()), 202
    except (ValidationError, resource_service.ResourceError) as exc:
        return jsonify({"error": str(exc)}), 400


def _get_owned_vm_or_404(vm_id):
    vm = VM.query.get(vm_id)
    if vm is None:
        return None
    user = g.api_user
    if not user.is_admin and vm.owner_id != user.id:
        return None
    return vm


@vms_bp.route("/vms/<vm_id>", methods=["GET"])
@api_login_required
def get_vm(vm_id):
    vm = _get_owned_vm_or_404(vm_id)
    if vm is None:
        return jsonify({"error": "not found"}), 404
    from app.services.status_sync import sync_vm_status

    sync_vm_status(vm)
    d = vm.to_dict(include_owner=g.api_user.is_admin)
    if vm.status == VMState.READY or vm.status == VMState.RUNNING:
        if vm.ssh_port and vm.ip_address:
            d["ssh_command"] = f"ssh {vm.username}@{vm.ip_address} -p {vm.ssh_port}"
        d["tmate_command"] = vm.tmate_ssh
    return jsonify(d)


@vms_bp.route("/vms/<vm_id>/start", methods=["POST"])
@api_admin_required
def start_vm(vm_id):
    return _lifecycle(vm_id, "start")


@vms_bp.route("/vms/<vm_id>/stop", methods=["POST"])
@api_admin_required
def stop_vm(vm_id):
    return _lifecycle(vm_id, "stop")


@vms_bp.route("/vms/<vm_id>/restart", methods=["POST"])
@api_admin_required
def restart_vm(vm_id):
    return _lifecycle(vm_id, "restart")


@vms_bp.route("/vms/<vm_id>", methods=["DELETE"])
@api_admin_required
def delete_vm(vm_id):
    return _lifecycle(vm_id, "delete")


def _lifecycle(vm_id, action):
    vm = VM.query.get(vm_id)
    if vm is None:
        return jsonify({"error": "not found"}), 404
    jobs.enqueue_lifecycle(vm_id, action)
    _log(g.api_user.id, f"vm.{action}_requested", vm_id)
    return jsonify({"status": "queued", "action": action}), 202


@vms_bp.route("/vms/<vm_id>/tmate", methods=["POST"])
@api_admin_required
def regenerate_tmate(vm_id):
    vm = VM.query.get(vm_id)
    if vm is None:
        return jsonify({"error": "not found"}), 404
    jobs.enqueue_tmate_regenerate(vm_id)
    _log(g.api_user.id, "vm.tmate_regenerate_requested", vm_id)
    return jsonify({"status": "queued"}), 202


@vms_bp.route("/vms/<vm_id>/logs", methods=["GET"])
@api_login_required
def vm_logs(vm_id):
    vm = _get_owned_vm_or_404(vm_id)
    if vm is None:
        return jsonify({"error": "not found"}), 404
    logs = (
        ActivityLog.query.filter_by(target=vm_id)
        .order_by(ActivityLog.created_at.desc())
        .limit(100)
        .all()
    )
    return jsonify(
        [
            {
                "action": l.action,
                "status": l.status,
                "message": l.message,
                "created_at": l.created_at.isoformat(),
            }
            for l in logs
        ]
    )
