from flask import Blueprint

from app.api.health import health_bp
from app.api.vms import vms_bp
from app.api.misc import misc_bp

api_bp = Blueprint("api", __name__, url_prefix="/api")

api_bp.register_blueprint(health_bp)
api_bp.register_blueprint(vms_bp)
api_bp.register_blueprint(misc_bp)
