from flask import Blueprint, jsonify

from app.extensions import db
from app.models import LocalNode, Settings

health_bp = Blueprint("health", __name__)


@health_bp.route("/health")
def health():
    db_ok = True
    try:
        db.session.execute(db.text("SELECT 1"))
    except Exception:
        db_ok = False

    node = LocalNode.query.first()
    settings = Settings.query.first()

    engine = settings.container_engine if settings else "unknown"
    if node is None:
        engine_status = "no_local_node"
    elif engine == "docker" and not node.docker_available:
        engine_status = "docker_unavailable"
    elif engine == "lxc" and not node.lxc_available:
        engine_status = "lxc_unavailable"
    else:
        engine_status = "ok"

    return jsonify(
        {
            "status": "ok" if db_ok and node is not None else "degraded",
            "database": "ok" if db_ok else "error",
            "local_node": node.status if node else "missing",
            "engine": engine,
            "engine_status": engine_status,
        }
    )
