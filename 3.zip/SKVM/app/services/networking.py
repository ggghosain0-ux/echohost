"""
Real port allocation for exposing container SSH ports on the host
(spec section 30). Ports are checked against both the database (already
reserved by other VMs) and an actual socket bind test, so two VMs can never
collide.
"""
import socket

from flask import current_app

from app.models import VM


class PortAllocationError(Exception):
    pass


def _port_is_bindable(port: int) -> bool:
    for family, addr in ((socket.AF_INET, "0.0.0.0"), (socket.AF_INET6, "::")):
        try:
            s = socket.socket(family, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((addr, port))
            s.close()
        except OSError:
            return False
        except Exception:
            continue
    return True


def allocate_port() -> int:
    start = current_app.config["SSH_PORT_RANGE_START"]
    end = current_app.config["SSH_PORT_RANGE_END"]

    reserved = {row[0] for row in VM.query.with_entities(VM.ssh_port).filter(VM.ssh_port.isnot(None))}

    for port in range(start, end + 1):
        if port in reserved:
            continue
        if _port_is_bindable(port):
            return port

    raise PortAllocationError("No free SSH ports available in the configured range.")


def release_port(port: int):
    # Ports are released implicitly once the owning VM row's ssh_port is cleared
    # and the container process that held the mapping is torn down. Nothing to
    # do here beyond documenting the contract; kept as an explicit function so
    # callers have one place to hook additional cleanup (e.g. firewall rules).
    return True
