"""
Background provisioning worker (spec section 35).

Creating a real container can take minutes (image pulls, apt-get, tmate
bootstrap). We never block the HTTP request thread for this: VM creation
requests enqueue a job here and return immediately with status PENDING; a
dedicated worker thread performs the actual provisioning and persists real
state transitions the UI can poll (spec sections 36-38).

This uses a simple in-process queue rather than Celery/Redis to keep the
project runnable with zero extra infrastructure out of the box. The
interface (`enqueue_provision`, `enqueue_delete`) is small enough to swap
for Celery/RQ later without touching callers.
"""
import queue
import threading
import traceback

from app.extensions import db
from app.models import VM, VMState, ActivityLog
from app.services.provisioning import get_provider, ProvisioningError

_job_queue = queue.Queue()
_worker_thread = None
_flask_app = None


def init_app(app):
    """Call once from the application factory."""
    global _flask_app, _worker_thread
    _flask_app = app
    if _worker_thread is None or not _worker_thread.is_alive():
        _worker_thread = threading.Thread(target=_worker_loop, daemon=True, name="skvm-provisioner")
        _worker_thread.start()


def enqueue_provision(vm_id, password_plain=None):
    # The plaintext password is passed through the queue message itself
    # (never persisted to the database -- only its argon2 hash is stored on
    # the VM row) because the worker thread fetches its own fresh VM object
    # from the DB and would not see a transient attribute set on the
    # request-thread's object instance.
    _job_queue.put(("provision", vm_id, password_plain))


def enqueue_lifecycle(vm_id, action):
    assert action in ("start", "stop", "restart", "delete")
    _job_queue.put((action, vm_id, None))


def enqueue_tmate_regenerate(vm_id):
    _job_queue.put(("tmate_regenerate", vm_id, None))


def _log(user_id, action, target, status, message):
    entry = ActivityLog(user_id=user_id, action=action, target=target, status=status, message=message)
    db.session.add(entry)
    db.session.commit()


def _set_state(vm: VM, state: str, error=None):
    vm.status = state
    vm.last_error = error
    db.session.commit()


def _worker_loop():
    while True:
        job_type, vm_id, extra = _job_queue.get()
        try:
            with _flask_app.app_context():
                if job_type == "provision":
                    _run_provision(vm_id, extra)
                elif job_type in ("start", "stop", "restart"):
                    _run_lifecycle(vm_id, job_type)
                elif job_type == "delete":
                    _run_delete(vm_id)
                elif job_type == "tmate_regenerate":
                    _run_tmate_regenerate(vm_id)
        except Exception:
            # Never let the worker thread die; log and move on.
            traceback.print_exc()
        finally:
            _job_queue.task_done()


def _run_provision(vm_id, password_plain):
    vm = VM.query.get(vm_id)
    if vm is None:
        return

    provider = get_provider(vm.engine)
    pending_password = password_plain

    def progress(msg):
        # Kept as a lightweight console log; UI polls `status` for real state.
        print(f"[provision:{vm.id}] {msg}")

    try:
        _set_state(vm, VMState.VALIDATING)
        provider.verify_available()

        _set_state(vm, VMState.CREATING)
        vm.password_plain = pending_password  # keep plaintext in memory only, for this job
        container_id = provider.create(vm, progress_cb=progress)
        vm.container_id = container_id
        db.session.commit()

        _set_state(vm, VMState.INSTALLING_OS)
        # Image/template installation happened as part of create(); nothing
        # further required here beyond recording the state transition.

        _set_state(vm, VMState.STARTING)
        provider.start(vm)

        _set_state(vm, VMState.CONFIGURING)
        provider.configure_resources(vm)
        ip = provider.get_ip(vm)
        if ip:
            vm.ip_address = ip
            db.session.commit()

        from app.services.networking import allocate_port

        vm.ssh_port = allocate_port()
        db.session.commit()

        _set_state(vm, VMState.INSTALLING_SSH)
        vm.password_plain = pending_password
        provider.install_ssh(vm)

        _set_state(vm, VMState.INSTALLING_TMATE)
        tmate_ssh = provider.install_tmate(vm)
        vm.tmate_ssh = tmate_ssh
        vm.tmate_status = "active"
        db.session.commit()

        _set_state(vm, VMState.READY)
        _log(vm.owner_id, "vm.provisioned", vm.id, "ok", f"VM '{vm.name}' provisioned successfully")

    except ProvisioningError as exc:
        _set_state(vm, VMState.FAILED, error=str(exc))
        _log(vm.owner_id, "vm.provision_failed", vm.id, "error", str(exc))
        _cleanup_after_failure(provider, vm)
    except Exception as exc:  # unexpected bug, still surface honestly
        _set_state(vm, VMState.FAILED, error=f"Internal error: {exc}")
        _log(vm.owner_id, "vm.provision_failed", vm.id, "error", str(exc))
        _cleanup_after_failure(provider, vm)
    finally:
        if hasattr(vm, "password_plain"):
            try:
                delattr(vm, "password_plain")
            except Exception:
                vm.password_plain = None


def _cleanup_after_failure(provider, vm):
    """Spec 38: never leave an unknown orphan container behind on failure."""
    if not vm.container_id:
        return
    try:
        provider.delete(vm)
        vm.container_id = None
        db.session.commit()
    except Exception:
        # If cleanup itself fails, leave the VM clearly marked FAILED with the
        # container id retained so an admin can investigate manually rather
        # than silently losing track of it.
        pass


def _run_lifecycle(vm_id, action):
    vm = VM.query.get(vm_id)
    if vm is None:
        return
    provider = get_provider(vm.engine)
    try:
        getattr(provider, action)(vm)
        vm.status = VMState.RUNNING if action in ("start", "restart") else VMState.STOPPED
        vm.last_error = None
        db.session.commit()
        _log(vm.owner_id, f"vm.{action}", vm.id, "ok", f"VM '{vm.name}' {action} succeeded")
    except ProvisioningError as exc:
        vm.last_error = str(exc)
        db.session.commit()
        _log(vm.owner_id, f"vm.{action}", vm.id, "error", str(exc))


def _run_delete(vm_id):
    vm = VM.query.get(vm_id)
    if vm is None:
        return
    provider = get_provider(vm.engine)
    vm.status = VMState.DELETING
    db.session.commit()
    try:
        if vm.container_id:
            provider.delete(vm)
        vm.status = VMState.DELETED
        vm.container_id = None
        vm.tmate_ssh = None
        vm.tmate_status = None
        db.session.commit()
        _log(vm.owner_id, "vm.deleted", vm.id, "ok", f"VM '{vm.name}' deleted")
        db.session.delete(vm)
        db.session.commit()
    except ProvisioningError as exc:
        vm.status = VMState.FAILED
        vm.last_error = f"Deletion failed: {exc}"
        db.session.commit()
        _log(vm.owner_id, "vm.delete_failed", vm.id, "error", str(exc))


def _run_tmate_regenerate(vm_id):
    vm = VM.query.get(vm_id)
    if vm is None:
        return
    provider = get_provider(vm.engine)
    try:
        try:
            provider.execute(vm, ["pkill", "-f", "tmate"], timeout=15)
        except ProvisioningError:
            pass
        ssh_line = provider.install_tmate(vm)
        vm.tmate_ssh = ssh_line
        vm.tmate_status = "active"
        vm.last_error = None
        db.session.commit()
        _log(vm.owner_id, "vm.tmate_regenerated", vm.id, "ok", "tmate session regenerated")
    except ProvisioningError as exc:
        vm.tmate_status = "expired"
        vm.last_error = str(exc)
        db.session.commit()
        _log(vm.owner_id, "vm.tmate_regenerate_failed", vm.id, "error", str(exc))
