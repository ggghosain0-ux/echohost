"""
Central validation for anything that ends up in a container name, shell
argv, or filesystem path. Nothing derived from user input is ever passed to
a shell string; these validators exist so callers can trust the values
before handing them to subprocess/Docker SDK argv lists (spec section 32).
"""
import re

from app.models import OS_CATALOG

NAME_RE = re.compile(r"^[a-z][a-z0-9-]{1,62}$")
USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
HOSTNAME_RE = re.compile(r"^[a-zA-Z0-9-]{1,63}$")


class ValidationError(Exception):
    pass


def validate_vm_name(name: str) -> str:
    name = (name or "").strip().lower()
    if not NAME_RE.match(name):
        raise ValidationError(
            "VM name must be lowercase alphanumeric/hyphen, start with a letter, 2-63 chars."
        )
    return name


def validate_username(username: str) -> str:
    username = (username or "").strip().lower()
    if not USERNAME_RE.match(username):
        raise ValidationError("Username must be a valid POSIX username.")
    if username in ("root", "daemon", "bin", "sys", "admin"):
        raise ValidationError("That username is reserved.")
    return username


def validate_hostname(hostname: str, fallback: str) -> str:
    hostname = (hostname or "").strip()
    if not hostname:
        return fallback
    if not HOSTNAME_RE.match(hostname):
        raise ValidationError("Hostname may only contain letters, digits and hyphens.")
    return hostname


def validate_os_key(os_key: str) -> str:
    if os_key not in OS_CATALOG:
        raise ValidationError(f"Unsupported operating system: {os_key}")
    return os_key


def validate_engine(engine: str) -> str:
    engine = (engine or "").strip().lower()
    if engine not in ("docker", "lxc"):
        raise ValidationError("Engine must be 'docker' or 'lxc'.")
    return engine


def validate_int_range(value, minimum, maximum, field):
    try:
        value = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field} must be an integer.")
    if value < minimum or value > maximum:
        raise ValidationError(f"{field} must be between {minimum} and {maximum}.")
    return value


def validate_password(password: str) -> str:
    if not password or len(password) < 8:
        raise ValidationError("Password must be at least 8 characters.")
    return password
