"""
Real Docker provisioning backend. Every method here performs an actual
Docker Engine API call via the official `docker` SDK. Nothing is simulated.
"""
import io
import tarfile
import time

from app.models import OS_CATALOG
from app.services.provisioning.base import ProvisioningError, ProvisioningProvider

CONTAINER_LABEL = "skvm.managed"


def _client():
    import docker

    try:
        return docker.from_env(timeout=15)
    except Exception as exc:  # pragma: no cover - environment dependent
        raise ProvisioningError(f"Could not connect to the Docker daemon: {exc}")


class DockerProvider(ProvisioningProvider):
    engine_name = "docker"

    def verify_available(self):
        client = _client()
        try:
            client.ping()
        except Exception as exc:
            raise ProvisioningError(f"Docker daemon is not reachable: {exc}")

    # ---------------------------------------------------------------- create
    def create(self, vm, progress_cb=None):
        client = _client()
        os_def = OS_CATALOG[vm.os_key]
        image = os_def["docker_image"]

        def report(msg):
            if progress_cb:
                progress_cb(msg)

        report(f"Pulling image {image}")
        try:
            client.images.pull(image)
        except Exception as exc:
            raise ProvisioningError(f"Failed to pull image '{image}': {exc}")

        report("Creating container")
        mem_limit = f"{vm.ram_mb}m"
        # nano_cpus: cpu count -> billionths of a CPU
        nano_cpus = int(vm.cpu * 1_000_000_000)

        container_name = f"skvm-{vm.id}"
        try:
            container = client.containers.create(
                image=image,
                name=container_name,
                hostname=vm.hostname or vm.name,
                command=["sleep", "infinity"],
                detach=True,
                tty=True,
                mem_limit=mem_limit,
                nano_cpus=nano_cpus,
                ports={"22/tcp": None},  # dynamic host port assigned at start time
                labels={CONTAINER_LABEL: "true", "skvm.vm_id": vm.id},
                storage_opt=self._storage_opt(vm),
            )
        except Exception as exc:
            # storage_opt is only supported on certain storage drivers (overlay2+xfs).
            # Retry without it rather than failing the whole provision, but say so.
            if vm.disk_gb:
                report(
                    "Host storage driver does not support per-container disk quotas; "
                    "continuing without enforced disk limit."
                )
            try:
                container = client.containers.create(
                    image=image,
                    name=container_name,
                    hostname=vm.hostname or vm.name,
                    command=["sleep", "infinity"],
                    detach=True,
                    tty=True,
                    mem_limit=mem_limit,
                    nano_cpus=nano_cpus,
                    ports={"22/tcp": None},
                    labels={CONTAINER_LABEL: "true", "skvm.vm_id": vm.id},
                )
            except Exception as exc2:
                raise ProvisioningError(f"Failed to create container: {exc2}")

        return container.id

    def _storage_opt(self, vm):
        if vm.disk_gb:
            return {"size": f"{vm.disk_gb}G"}
        return None

    # --------------------------------------------------------------- control
    def start(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.start()
        except Exception as exc:
            raise ProvisioningError(f"Failed to start container: {exc}")

    def stop(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.stop(timeout=15)
        except Exception as exc:
            raise ProvisioningError(f"Failed to stop container: {exc}")

    def restart(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.restart(timeout=15)
        except Exception as exc:
            raise ProvisioningError(f"Failed to restart container: {exc}")

    def delete(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.remove(force=True)
        except Exception as exc:
            msg = str(exc).lower()
            if "no such container" in msg or "404" in msg:
                return  # already gone
            raise ProvisioningError(f"Failed to delete container: {exc}")

    def status(self, vm):
        if not vm.container_id:
            return "missing"
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.reload()
            state = container.status  # created, running, exited, paused, dead
            if state == "running":
                return "running"
            if state in ("exited", "created", "paused", "dead"):
                return "stopped"
            return "error"
        except Exception as exc:
            msg = str(exc).lower()
            if "no such container" in msg or "404" in msg:
                return "missing"
            return "error"

    # ------------------------------------------------------------- execution
    def execute(self, vm, command: list, timeout=60):
        if not isinstance(command, (list, tuple)):
            raise ProvisioningError("command must be an argv list, not a string")
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            result = container.exec_run(command, demux=True)
            stdout, stderr = result.output
            return {
                "exit_code": result.exit_code,
                "stdout": (stdout or b"").decode("utf-8", "replace"),
                "stderr": (stderr or b"").decode("utf-8", "replace"),
            }
        except Exception as exc:
            raise ProvisioningError(f"exec failed: {exc}")

    def _exec_with_stdin(self, vm, command: list, stdin_data: bytes):
        """Low level exec with piped stdin, used for chpasswd."""
        client = _client()
        api = client.api
        container = client.containers.get(vm.container_id)
        exec_id = api.exec_create(container.id, cmd=command, stdin=True, tty=False)["Id"]
        sock = api.exec_start(exec_id, socket=True, tty=False)
        try:
            sock._sock.sendall(stdin_data)
            sock._sock.shutdown(1)  # SHUT_WR
        finally:
            sock.close()
        # Give the process a moment to consume stdin and exit.
        time.sleep(0.5)
        info = api.exec_inspect(exec_id)
        return info.get("ExitCode")

    def get_ip(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.reload()
            networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
            for net in networks.values():
                if net.get("IPAddress"):
                    return net["IPAddress"]
            return container.attrs.get("NetworkSettings", {}).get("IPAddress") or None
        except Exception:
            return None

    def configure_resources(self, vm):
        client = _client()
        try:
            container = client.containers.get(vm.container_id)
            container.update(
                mem_limit=f"{vm.ram_mb}m",
                nano_cpus=int(vm.cpu * 1_000_000_000),
            )
        except Exception as exc:
            raise ProvisioningError(f"Failed to apply resource limits: {exc}")

    # ------------------------------------------------------------- software
    def install_ssh(self, vm):
        steps = [
            (["apt-get", "update"], "apt-get update"),
            (
                ["apt-get", "install", "-y", "openssh-server", "sudo", "curl"],
                "install openssh-server",
            ),
            (["mkdir", "-p", "/run/sshd"], "prepare sshd runtime dir"),
            (["useradd", "-m", "-s", "/bin/bash", vm.username], "create user"),
            (["usermod", "-aG", "sudo", vm.username], "grant sudo"),
        ]
        for cmd, desc in steps:
            res = self.execute(vm, cmd, timeout=180)
            if res["exit_code"] not in (0, None):
                # useradd returns non-zero if user already exists on a re-run; tolerate that one.
                if cmd[0] == "useradd" and "already exists" in (res["stderr"] + res["stdout"]):
                    continue
                raise ProvisioningError(f"Step '{desc}' failed: {res['stderr'] or res['stdout']}")

        # Set the account password without ever building a shell string.
        exit_code = self._exec_with_stdin(
            vm, ["chpasswd"], f"{vm.username}:{vm.password_plain}\n".encode()
        )
        if exit_code not in (0, None):
            raise ProvisioningError("Failed to set account password via chpasswd")

        start_res = self.execute(
            vm, ["bash", "-c", "service ssh start || /usr/sbin/sshd"], timeout=60
        )
        # bash -c here uses a fixed literal script with no user input, so this
        # is not a command-injection risk (contrast with concatenating user input).
        check = self.execute(vm, ["pgrep", "-x", "sshd"], timeout=30)
        if check["exit_code"] != 0:
            raise ProvisioningError(
                f"sshd did not start: {start_res['stderr'] or start_res['stdout']}"
            )
        return True

    def install_tmate(self, vm):
        install = self.execute(vm, ["apt-get", "install", "-y", "tmate"], timeout=180)
        if install["exit_code"] not in (0, None):
            raise ProvisioningError(f"Failed to install tmate: {install['stderr']}")

        sock_path = "/tmp/skvm-tmate.sock"
        self.execute(vm, ["rm", "-f", sock_path], timeout=15)

        new_session = self.execute(
            vm, ["tmate", "-S", sock_path, "new-session", "-d"], timeout=30
        )
        if new_session["exit_code"] not in (0, None):
            raise ProvisioningError(f"Failed to start tmate session: {new_session['stderr']}")

        wait_ready = self.execute(
            vm, ["tmate", "-S", sock_path, "wait", "tmate-ready"], timeout=60
        )
        if wait_ready["exit_code"] not in (0, None):
            raise ProvisioningError(f"tmate session did not become ready: {wait_ready['stderr']}")

        display = self.execute(
            vm, ["tmate", "-S", sock_path, "display", "-p", "#{tmate_ssh}"], timeout=30
        )
        ssh_line = display["stdout"].strip()
        if display["exit_code"] not in (0, None) or not ssh_line.startswith("ssh "):
            raise ProvisioningError(
                f"Could not retrieve tmate session string: {display['stderr'] or display['stdout']}"
            )

        vm.tmate_socket_path = sock_path
        return ssh_line
