"""
Common interface both DockerProvider and LXCProvider implement (spec section 3).
The rest of the app (routes, API, background jobs) only ever talks to this
interface, never to Docker or LXC directly, so the UI/API layer does not need
to know which engine backs a given VM.
"""
from abc import ABC, abstractmethod


class ProvisioningError(Exception):
    """Raised when a real provisioning step genuinely fails."""


class ProvisioningProvider(ABC):
    engine_name = "base"

    @abstractmethod
    def verify_available(self):
        """Raise ProvisioningError if this engine is not usable on this host."""

    @abstractmethod
    def create(self, vm, progress_cb=None):
        """Create the underlying container/instance for `vm`. Returns backend id."""

    @abstractmethod
    def start(self, vm):
        ...

    @abstractmethod
    def stop(self, vm):
        ...

    @abstractmethod
    def restart(self, vm):
        ...

    @abstractmethod
    def delete(self, vm):
        ...

    @abstractmethod
    def status(self, vm):
        """Return one of: running, stopped, missing, error."""

    @abstractmethod
    def execute(self, vm, command: list, timeout=60):
        """Run `command` (argv list, never a shell string) inside the workload."""

    @abstractmethod
    def get_ip(self, vm):
        ...

    @abstractmethod
    def configure_resources(self, vm):
        """Apply cpu/ram/disk limits to the already-created workload."""

    @abstractmethod
    def install_ssh(self, vm):
        ...

    @abstractmethod
    def install_tmate(self, vm):
        """Install + start a real tmate session inside the workload and
        return the actual `ssh <session>` connection string."""
