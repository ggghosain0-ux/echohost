from argon2.exceptions import VerifyMismatchError, InvalidHashError

from app.extensions import password_hasher


def hash_password(plain: str) -> str:
    return password_hasher.hash(plain)


def verify_password(hash_: str, plain: str) -> bool:
    if not hash_:
        return False
    try:
        return password_hasher.verify(hash_, plain)
    except (VerifyMismatchError, InvalidHashError):
        return False
    except Exception:
        return False
