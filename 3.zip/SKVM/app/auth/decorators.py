from functools import wraps

from flask import abort, request, jsonify
from flask_login import current_user


def admin_required(view):
    """Enforced server-side, not just hidden in the UI (spec section 11)."""

    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.path.startswith("/api/"):
                return jsonify({"error": "unauthorized"}), 401
            abort(401)
        if not current_user.is_admin:
            if request.path.startswith("/api/"):
                return jsonify({"error": "forbidden"}), 403
            abort(403)
        return view(*args, **kwargs)

    return wrapped


def login_required_json(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({"error": "unauthorized"}), 401
        return view(*args, **kwargs)

    return wrapped
