from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user

from app.extensions import db, limiter
from app.models import User, Settings, ActivityLog
from app.auth.utils import hash_password, verify_password
from app.auth.google_oauth import oauth, google_configured, register_google_client

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


def _log(user_id, action, status, message=""):
    db.session.add(ActivityLog(user_id=user_id, action=action, status=status, message=message))
    db.session.commit()


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def login():
    settings = Settings.query.first()
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        user = User.query.filter_by(email=email).first()
        if user and verify_password(user.password_hash, password):
            login_user(user)
            _log(user.id, "user.login", "ok")
            return redirect(url_for("admin.dashboard" if user.is_admin else "user.dashboard"))
        _log(None, "user.login", "error", f"failed login for {email}")
        flash("Invalid email or password.", "error")
    return render_template(
        "login.html", settings=settings, google_enabled=google_configured()
    )


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def register():
    settings = Settings.query.first()
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""

        if not email or "@" not in email:
            flash("Please provide a valid email.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        elif User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
        else:
            user = User(email=email, password_hash=hash_password(password), role="user")
            db.session.add(user)
            db.session.commit()
            _log(user.id, "user.register", "ok")
            login_user(user)
            return redirect(url_for("user.dashboard"))
    return render_template(
        "register.html", settings=settings, google_enabled=google_configured()
    )


@auth_bp.route("/logout")
@login_required
def logout():
    _log(current_user.id, "user.logout", "ok")
    logout_user()
    return redirect(url_for("public.starter"))


@auth_bp.route("/google/login")
def google_login():
    if not google_configured():
        flash("Google authentication is not configured.", "error")
        return redirect(url_for("auth.login"))
    register_google_client(current_app)
    redirect_uri = Settings.query.first().google_redirect_uri
    return oauth.google.authorize_redirect(redirect_uri)


@auth_bp.route("/google/callback")
def google_callback():
    if not google_configured():
        flash("Google authentication is not configured.", "error")
        return redirect(url_for("auth.login"))
    register_google_client(current_app)
    try:
        token = oauth.google.authorize_access_token()
        userinfo = token.get("userinfo") or oauth.google.userinfo()
    except Exception as exc:
        flash(f"Google authentication failed: {exc}", "error")
        return redirect(url_for("auth.login"))

    google_id = userinfo.get("sub")
    email = (userinfo.get("email") or "").lower()
    if not google_id or not email:
        flash("Google did not return the required profile information.", "error")
        return redirect(url_for("auth.login"))

    user = User.query.filter_by(google_id=google_id).first()
    if user is None:
        user = User.query.filter_by(email=email).first()
        if user is None:
            user = User(email=email, google_id=google_id, role="user")
            db.session.add(user)
        else:
            user.google_id = google_id
        db.session.commit()

    login_user(user)
    _log(user.id, "user.login_google", "ok")
    return redirect(url_for("admin.dashboard" if user.is_admin else "user.dashboard"))
