#!/usr/bin/env bash
#
# SKVM universal installer.
#
# Works on:
#   - A real VPS / bare-metal Linux host with systemd      -> installs+starts a systemd service
#   - CodeSandbox / GitHub Codespaces / Gitpod / any devcontainer without systemd
#                                                             -> starts SKVM directly in the background
#
# In every case it:
#   1. Detects the environment and distro.
#   2. Installs Python + (on real hosts) Docker/LXC.
#   3. Creates a virtualenv and installs requirements.txt.
#   4. Creates .env (generating a real random SECRET_KEY) on first run, and
#      ALWAYS pins DATABASE_URL to an absolute path so SQLite never breaks
#      because of a changed working directory / sudo su / different shell.
#   5. Initializes the database, bootstraps the default admin, syncs the
#      local node -- all idempotent.
#   6. Starts SKVM the best way available on this host.
#
# Re-run-safe: never deletes the database, VMs/containers, or settings.
#
set -euo pipefail

INSTALL_DIR_DEFAULT="/opt/skvm"
SERVICE_NAME="skvm"
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { echo -e "\033[1;34m[skvm]\033[0m $*"; }
warn() { echo -e "\033[1;33m[skvm][warn]\033[0m $*"; }
err()  { echo -e "\033[1;31m[skvm][error]\033[0m $*" >&2; }

# --------------------------------------------------------- environment kind
ENVIRONMENT_KIND="vps_or_local_linux"
HAS_SYSTEMD="no"
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  HAS_SYSTEMD="yes"
fi

if [[ -n "${CODESANDBOX_SSE:-}" || -f /.codesandbox || -n "${CODESANDBOX_HOST:-}" ]]; then
  ENVIRONMENT_KIND="codesandbox"
elif [[ -n "${CODESPACES:-}" ]]; then
  ENVIRONMENT_KIND="github_codespaces"
elif [[ -n "${GITPOD_WORKSPACE_ID:-}" ]]; then
  ENVIRONMENT_KIND="gitpod"
elif [[ "${HAS_SYSTEMD}" == "no" && -f /.dockerenv ]]; then
  ENVIRONMENT_KIND="restricted_container"
fi

IS_ROOT="no"
[[ "${EUID}" -eq 0 ]] && IS_ROOT="yes"

log "Environment: ${ENVIRONMENT_KIND}  |  systemd available: ${HAS_SYSTEMD}  |  running as root: ${IS_ROOT}"

if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" && "${IS_ROOT}" == "no" ]]; then
  err "On a VPS/bare-metal host, please run this as root: sudo ./install.sh"
  exit 1
fi

# ----------------------------------------------------- choose install path
if [[ "${HAS_SYSTEMD}" == "yes" && "${IS_ROOT}" == "yes" ]]; then
  INSTALL_DIR="${INSTALL_DIR_DEFAULT}"
  USE_SYSTEMD="yes"
else
  INSTALL_DIR="${REPO_DIR}"
  USE_SYSTEMD="no"
  if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
    warn "systemd not detected -- falling back to a direct background process instead of a service."
  fi
fi
log "Install directory: ${INSTALL_DIR}"
log "Startup method: $( [[ ${USE_SYSTEMD} == yes ]] && echo 'systemd service' || echo 'background process (nohup)' )"

# --------------------------------------------------------------- distro info
DISTRO="unknown"
if [[ -f /etc/os-release ]]; then
  . /etc/os-release
  DISTRO="${ID:-unknown} ${VERSION_ID:-}"
fi
log "Distro: ${DISTRO}  Arch: $(uname -m)"

# ------------------------------------------------------------- dependencies
if [[ "${IS_ROOT}" == "yes" ]]; then
  log "Installing system dependencies..."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y python3 python3-venv python3-pip curl git ca-certificates gnupg lsb-release || \
      warn "Some base packages failed to install."
    if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
      apt-get install -y lxc lxc-templates bridge-utils uidmap || \
        warn "LXC packages failed to install; the LXC engine won't be usable until you install them manually."
    fi
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip curl git || warn "Some base packages failed to install."
    [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]] && \
      (dnf install -y lxc lxc-templates bridge-utils || warn "LXC packages failed to install.")
  else
    warn "Unsupported/unknown package manager -- ensure python3, pip, and (optionally) lxc are installed."
  fi
else
  log "Not running as root -- skipping system package installation (expected in CodeSandbox/Codespaces)."
  if ! command -v python3 >/dev/null 2>&1; then
    err "python3 was not found and this script cannot install it without root."
    err "Switch to a Python-capable template/devcontainer, or install python3 manually, then re-run."
    exit 1
  fi
fi

# ------------------------------------------------------------------- Docker
if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" && "${IS_ROOT}" == "yes" ]]; then
  if ! command -v docker >/dev/null 2>&1; then
    log "Docker not found. Attempting install via get.docker.com ..."
    if curl -fsSL https://get.docker.com -o /tmp/get-docker.sh 2>/dev/null; then
      sh /tmp/get-docker.sh || warn "Docker installation script failed; install Docker manually if you plan to use the Docker engine."
      systemctl enable --now docker 2>/dev/null || true
    else
      warn "Could not reach get.docker.com (no network egress?). Skipping Docker auto-install."
    fi
  else
    log "Docker already installed."
  fi
fi

DOCKER_OK="no"; command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && DOCKER_OK="yes"
LXC_OK="no"; command -v lxc-create >/dev/null 2>&1 && LXC_OK="yes"
if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Neither a reachable Docker daemon nor LXC tooling was detected on this host."
  warn "SKVM will install and run, but real VM provisioning will fail with a real,"
  warn "honest error until this runs somewhere with Docker or LXC available."
fi

# ---------------------------------------------------------------- app files
if [[ "${INSTALL_DIR}" != "${REPO_DIR}" ]]; then
  log "Copying application into ${INSTALL_DIR} ..."
  mkdir -p "${INSTALL_DIR}"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude 'data' --exclude 'logs' --exclude '.git' --exclude 'venv' \
      "${REPO_DIR}/" "${INSTALL_DIR}/"
  else
    cp -r "${REPO_DIR}/." "${INSTALL_DIR}/"
  fi
fi

# ---------------------------------------------------------- data/logs dirs
# Created with permissive-enough mode so a later run under a different user
# (e.g. after `sudo su` vs. a plain shell) doesn't silently fail to open the
# SQLite file with a confusing "unable to open database file" error.
mkdir -p "${INSTALL_DIR}/data" "${INSTALL_DIR}/logs"
chmod 0777 "${INSTALL_DIR}/data" "${INSTALL_DIR}/logs" 2>/dev/null || true
cd "${INSTALL_DIR}"

# --------------------------------------------------------------- virtualenv
if [[ ! -d venv ]]; then
  log "Creating Python virtual environment..."
  python3 -m venv venv
fi
log "Installing Python dependencies (this can take a minute)..."
./venv/bin/pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt

# ------------------------------------------------------------- environment
# IMPORTANT: DATABASE_URL is always pinned to an ABSOLUTE path. A relative
# "sqlite:///data/skvm.db" only works if the process is later launched from
# exactly this directory -- true right after this script runs, but not
# guaranteed for every future shell, `sudo su`, cron job, or service
# definition that starts the app. Using an absolute path here removes that
# entire class of "unable to open database file" failures permanently.
ABS_DB_PATH="${INSTALL_DIR}/data/skvm.db"
ABS_DATABASE_URL="sqlite:///${ABS_DB_PATH}"

if [[ ! -f .env ]]; then
  log "Creating .env from .env.example (first install)..."
  cp .env.example .env
  SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i.bak "s#SECRET_KEY=.*#SECRET_KEY=${SECRET}#" .env && rm -f .env.bak
  # .env.example ships DATABASE_URL commented out (config.py's safe absolute
  # default is normally enough) -- but pin it explicitly here too, so the
  # value actually in use is always visible and correct in .env itself.
  if grep -qE '^[#[:space:]]*DATABASE_URL=' .env; then
    sed -i.bak "s#^[#[:space:]]*DATABASE_URL=.*#DATABASE_URL=${ABS_DATABASE_URL}#" .env && rm -f .env.bak
  else
    echo "DATABASE_URL=${ABS_DATABASE_URL}" >> .env
  fi
else
  log ".env already exists -- leaving your existing configuration untouched, except:"
  # Self-heal a relative sqlite:// path left over from an older install so
  # existing installs pick up the same fix without having to delete .env.
  if grep -qE '^DATABASE_URL=sqlite:///[^/]' .env 2>/dev/null; then
    warn "  .env has a relative sqlite:// DATABASE_URL -- rewriting it to an absolute path"
    warn "  (${ABS_DATABASE_URL}) to prevent 'unable to open database file' errors."
    sed -i.bak "s#^DATABASE_URL=sqlite:///.*#DATABASE_URL=${ABS_DATABASE_URL}#" .env && rm -f .env.bak
  fi
fi

# --------------------------------------------------------- permission check
if [[ ! -w "${INSTALL_DIR}/data" ]]; then
  err "The data directory (${INSTALL_DIR}/data) is not writable by the current user."
  err "Fix ownership/permissions, e.g.: chmod 0777 '${INSTALL_DIR}/data'"
  exit 1
fi

# ------------------------------------------------------- database & bootstrap
log "Initializing database (idempotent; existing data is preserved)..."
if ! ./venv/bin/python -c "
from app import create_app
app = create_app()
print('Database ready. Local node synced. Bootstrap admin ensured if none existed.')
"; then
  err "Database initialization failed. Common causes:"
  err "  - the 'data' directory isn't writable by this user (see permission check above)"
  err "  - DATABASE_URL in .env points somewhere invalid -- current value:"
  grep '^DATABASE_URL=' .env || true
  exit 1
fi

PORT=$(grep -E '^APP_PORT=' .env | cut -d= -f2)
PORT="${PORT:-8000}"

# ------------------------------------------------------------------- start
if [[ "${USE_SYSTEMD}" == "yes" ]]; then
  log "Installing systemd service..."
  sed "s#/opt/skvm#${INSTALL_DIR}#g" "${INSTALL_DIR}/scripts/skvm.service" > /etc/systemd/system/${SERVICE_NAME}.service
  systemctl daemon-reload
  systemctl enable ${SERVICE_NAME}
  systemctl restart ${SERVICE_NAME}
  sleep 2
  systemctl --no-pager status ${SERVICE_NAME} || true
else
  log "Starting SKVM as a background process (no systemd available/permitted here)..."
  if [[ -f skvm.pid ]] && kill -0 "$(cat skvm.pid)" 2>/dev/null; then
    log "An existing SKVM process is already running (pid $(cat skvm.pid)); restarting it."
    kill "$(cat skvm.pid)" 2>/dev/null || true
    sleep 1
  fi
  nohup ./venv/bin/python run.py > logs/skvm.out 2>&1 &
  echo $! > skvm.pid
  sleep 2
  if kill -0 "$(cat skvm.pid)" 2>/dev/null; then
    log "SKVM is running (pid $(cat skvm.pid))."
  else
    err "SKVM did not stay running. Last 40 log lines:"
    tail -n 40 logs/skvm.out || true
    exit 1
  fi
fi

# ----------------------------------------------------------------- summary
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
IP="${IP:-127.0.0.1}"

echo
log "SKVM installation complete."
if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
  log "Panel URL: http://${IP}:${PORT}"
elif [[ "${ENVIRONMENT_KIND}" == "codesandbox" ]]; then
  log "Local URL: http://localhost:${PORT} -- open the 'Ports' tab in CodeSandbox and click port ${PORT} for your public preview URL."
elif [[ "${ENVIRONMENT_KIND}" == "github_codespaces" ]]; then
  log "Local URL: http://localhost:${PORT} -- check the 'Ports' panel in Codespaces for the forwarded URL (set visibility as needed)."
else
  log "Local URL: http://localhost:${PORT}"
fi
log "Database file: ${ABS_DB_PATH}"
log "Bootstrap admin: admin@gmail.com / admin  (change this immediately after first login)"
if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Reminder: real container provisioning is not available in this environment."
fi
echo
if [[ "${USE_SYSTEMD}" == "yes" ]]; then
  log "Manage the service with: systemctl {status|start|stop|restart} ${SERVICE_NAME}"
  log "Logs: journalctl -u ${SERVICE_NAME} -f"
else
  log "Manage the process manually (no systemctl here):"
  log "  Stop:    kill \$(cat ${INSTALL_DIR}/skvm.pid)"
  log "  Restart: ./install.sh   (re-run-safe, keeps existing data)"
  log "  Logs:    tail -f ${INSTALL_DIR}/logs/skvm.out"
fi
