#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-4455}"
DATA_DIR="${ECHO_DATA_DIR:-$PWD/echo-host-data}"

echo "=== ECHO HOST • CodeSandbox Installer ==="
if ! command -v node >/dev/null 2>&1; then echo "Node.js 20+ is required."; exit 1; fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then echo "Node.js 20+ required. Found $(node -v)"; exit 1; fi
printf "Admin email: "
read -r ADMIN_EMAIL
while :; do
  printf "Admin password (min 10 chars): "
  read -rs ADMIN_PASSWORD; echo
  [ "${#ADMIN_PASSWORD}" -ge 10 ] && break
  echo "Password must be at least 10 characters."
done
export PORT DATA_DIR ADMIN_EMAIL ADMIN_PASSWORD ECHO_DATA_DIR="$DATA_DIR"

echo "[1/4] Installing panel dependencies..."
(cd apps/panel && npm install --omit=dev)

echo "[2/4] Preparing data directory..."
mkdir -p "$DATA_DIR"

echo "[3/4] Creating admin account in the database..."
# Start temporarily so bootstrap can be completed without any browser prompt.
ECHO_DATA_DIR="$DATA_DIR" PORT="$PORT" node apps/panel/server.js > "$DATA_DIR/panel.log" 2>&1 &
PID=$!
cleanup(){ kill "$PID" 2>/dev/null || true; }
trap cleanup EXIT
for i in $(seq 1 40); do curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1 && break; sleep .25; done
curl -fsS -X POST "http://127.0.0.1:$PORT/api/auth/bootstrap" \
  -H 'content-type: application/json' \
  --data-binary "$(node -e 'console.log(JSON.stringify({email:process.env.ADMIN_EMAIL,password:process.env.ADMIN_PASSWORD}))')" >/dev/null || true

echo "[4/4] Starting ECHO HOST on port $PORT..."
kill "$PID" 2>/dev/null || true
sleep .5
nohup env ECHO_DATA_DIR="$DATA_DIR" PORT="$PORT" node apps/panel/server.js > "$DATA_DIR/panel.log" 2>&1 &
NEWPID=$!
echo "$NEWPID" > "$DATA_DIR/panel.pid"
sleep 1
if ! curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null; then
  echo "Panel failed to start. Log: $DATA_DIR/panel.log"; exit 1
fi

echo
echo "ECHO HOST is running."
echo "Dashboard: http://localhost:$PORT/"
echo "Health:    http://localhost:$PORT/api/health"
echo "CodeSandbox: open the PORTS panel and expose port $PORT."
echo "Log: $DATA_DIR/panel.log"
