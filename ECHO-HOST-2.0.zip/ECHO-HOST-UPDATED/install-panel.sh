#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-4455}"
DATA_DIR="${ECHO_DATA_DIR:-/opt/echo-host/data}"
SERVICE_NAME="echo-host-panel"

echo "=== ECHO HOST • Ubuntu/Debian VPS Installer ==="
if [ "$(id -u)" -ne 0 ]; then echo "Run as root: sudo bash install-panel.sh"; exit 1; fi
if ! command -v node >/dev/null 2>&1; then echo "Node.js 20+ is required. Install it first."; exit 1; fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then echo "Node.js 20+ required. Found $(node -v)"; exit 1; fi
printf "Admin email: "
read -r ADMIN_EMAIL
while :; do
  printf "Admin password (min 10 chars): "
  read -rs ADMIN_PASSWORD; echo
  [ "${#ADMIN_PASSWORD}" -ge 10 ] && break
  echo "Password must be at least 10 characters."
done

install -d -m 0750 /opt/echo-host
cp -a . /opt/echo-host/source
cd /opt/echo-host/source
npm install --omit=dev --prefix apps/panel
install -d -m 0750 "$DATA_DIR"
cat > /etc/systemd/system/$SERVICE_NAME.service <<UNIT
[Unit]
Description=ECHO HOST Panel
After=network.target
[Service]
Type=simple
WorkingDirectory=/opt/echo-host/source
Environment=NODE_ENV=production
Environment=PORT=$PORT
Environment=ECHO_DATA_DIR=$DATA_DIR
ExecStart=/usr/bin/node apps/panel/server.js
Restart=always
RestartSec=3
User=root
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now "$SERVICE_NAME"
for i in $(seq 1 40); do curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1 && break; sleep .25; done
curl -fsS -X POST "http://127.0.0.1:$PORT/api/auth/bootstrap" \
  -H 'content-type: application/json' \
  --data-binary "$(node -e 'console.log(JSON.stringify({email:process.env.ADMIN_EMAIL,password:process.env.ADMIN_PASSWORD}))')" >/dev/null || true
systemctl restart "$SERVICE_NAME"
echo
echo "ECHO HOST installed and running on port $PORT."
echo "Open: http://SERVER_IP:$PORT/"
