#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PANEL=""; TOKEN=""; PORT="7788"
while [ $# -gt 0 ]; do case "$1" in --panel) PANEL="$2"; shift 2;; --token) TOKEN="$2"; shift 2;; --port) PORT="$2"; shift 2;; *) echo "Unknown argument: $1"; exit 1;; esac; done
if [ -z "$PANEL" ] || [ -z "$TOKEN" ]; then echo "Usage: sudo bash install-node.sh --panel http://PANEL_IP:4455 --token NODE_TOKEN [--port 7788]"; exit 1; fi
if [ "$(id -u)" -ne 0 ]; then echo "Run as root."; exit 1; fi
if ! command -v node >/dev/null 2>&1; then echo "Node.js 20+ required."; exit 1; fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"; [ "$NODE_MAJOR" -ge 20 ] || { echo "Node.js 20+ required."; exit 1; }
install -d -m 0750 /opt/echo-host-node
cp -a apps/agent /opt/echo-host-node/agent
cd /opt/echo-host-node/agent
npm install --omit=dev
cat > /etc/systemd/system/echo-host-node.service <<UNIT
[Unit]
Description=ECHO HOST Node Agent
After=network.target docker.service
Wants=docker.service
[Service]
Type=simple
WorkingDirectory=/opt/echo-host-node/agent
Environment=PANEL_URL=$PANEL
Environment=NODE_TOKEN=$TOKEN
Environment=PORT=$PORT
ExecStart=/usr/bin/node agent.js
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now echo-host-node
curl -fsS "http://127.0.0.1:$PORT/health" || true
echo "ECHO HOST node agent installed on port $PORT."
