# ECHO HOST 2.0

ECHO HOST is a multi-service hosting control-panel codebase with a CodeSandbox installer and an Ubuntu/Debian VPS installer.

## Services
- Minecraft hosting
- Website hosting
- Bot hosting
- VPS control-plane entries
- Nodes, allocations, backups, schedules, tunnels, files, users, activity and settings pages

## CodeSandbox
```bash
chmod +x install-codesandbox.sh
./install-codesandbox.sh
```
The installer asks for the admin email/password **in the terminal**. It does not use a browser prompt for first-time admin creation. Expose port `4455` in CodeSandbox.

## Ubuntu/Debian VPS
Install Node.js 20+ first, then:
```bash
sudo bash install-panel.sh
```
The installer asks for the admin credentials in the terminal and creates a systemd service.

## Node
```bash
sudo bash install-node.sh --panel http://PANEL_IP:4455 --token NODE_TOKEN
```

## Important
This repository provides a functional control-plane foundation and UI, not a guarantee that every infrastructure integration is production-ready. Real Minecraft/container lifecycle, KVM/Proxmox VPS provisioning, SFTP/file transfers, backups, DNS/SSL and tunnel-provider APIs require their corresponding node/provider credentials and integration testing.
